import "dotenv/config";
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import bcrypt from "bcryptjs";
import {
  users, categories, products, coupons, blogPosts, settings,
} from "../src/db/schema";
import { sql } from "drizzle-orm";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool);

const img = (id: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800`;

async function main() {
  const existing = await db.select({ c: sql<number>`count(*)::int` }).from(categories);
  if ((existing[0]?.c ?? 0) > 0) {
    console.log("Database already seeded. Skipping.");
    await pool.end();
    return;
  }

  console.log("Seeding database...");

  // ---- Admin user ----
  const passwordHash = await bcrypt.hash("Admin@12345", 10);
  await db.insert(users).values({
    name: "Store Admin",
    email: "sigmaboy25800@gmail.com",
    passwordHash,
    phone: "03228586255",
    role: "admin",
  }).onConflictDoNothing();

  // ---- Categories ----
  const catDefs = [
    { name: "2 Piece Suits", slug: "2-piece-suits", description: "Elegant unstitched and ready-to-wear 2 piece suits.", image: img(25185000), sortOrder: 1 },
    { name: "3 Piece Suits", slug: "3-piece-suits", description: "Complete 3 piece suits with dupatta and trousers.", image: img(25184999), sortOrder: 2 },
    { name: "Lawn", slug: "lawn", description: "Breathable premium lawn collections for every season.", image: img(20690516), sortOrder: 3 },
    { name: "Arabic Lawn", slug: "arabic-lawn", description: "Soft, luxurious Arabic lawn fabric collections.", image: img(20629032), sortOrder: 4 },
    { name: "Printed", slug: "printed", description: "Vibrant printed designs with modern patterns.", image: img(25288427), sortOrder: 5 },
    { name: "Embroidered", slug: "embroidered", description: "Intricate embroidered pieces crafted with care.", image: img(36325969), sortOrder: 6 },
    { name: "Dupattas", slug: "dupattas", description: "Beautiful dupattas to complete every outfit.", image: img(26970930), sortOrder: 7 },
    { name: "Trousers", slug: "trousers", description: "Comfortable, stylish trousers in premium fabrics.", image: img(19281311), sortOrder: 8 },
  ];
  const cats = await db.insert(categories).values(catDefs).returning();
  const catId = (slug: string) => cats.find((c) => c.slug === slug)!.id;

  // ---- Products ----
  const sizesStd = ["S", "M", "L", "XL"];
  const unstitched = ["Unstitched"];
  const prods = [
    {
      name: "Emerald Luxe Embroidered 3 Piece Suit", slug: "emerald-luxe-embroidered-3-piece-suit", sku: "CSD-3P-001",
      description: "A statement 3 piece suit featuring rich emerald tones with intricate thread embroidery on the shirt front, paired with a printed chiffon dupatta and dyed trousers. Perfect for festive occasions and formal gatherings.",
      fabric: "Premium Lawn (Shirt) • Chiffon (Dupatta) • Cambric (Trouser)", care: "Gentle machine wash cold. Do not bleach. Iron on medium heat.",
      specifications: [{ label: "Pieces", value: "3 (Shirt, Dupatta, Trouser)" }, { label: "Shirt Length", value: "2.5 meters" }, { label: "Dupatta", value: "2.5 meters chiffon" }, { label: "Trouser", value: "2.5 meters cambric" }],
      price: 6490, oldPrice: 8200, stock: 24, categoryId: catId("3-piece-suits"), sizes: unstitched, colors: ["Emerald", "Teal"],
      tags: ["3 piece", "embroidered", "festive", "lawn"], images: [img(36325969), img(25184952), img(27603286)],
      imageAlt: "Emerald green embroidered 3 piece suit with dupatta", isFeatured: true, isBestSeller: true, onSale: true, salesCount: 148,
      seoTitle: "Emerald Luxe Embroidered 3 Piece Suit | CS Digital Worker", seoDescription: "Shop the Emerald Luxe embroidered 3 piece suit with chiffon dupatta. Premium lawn fabric, nationwide delivery and cash on delivery available.",
    },
    {
      name: "Sapphire Blue Embroidered Shalwar Kameez", slug: "sapphire-blue-embroidered-shalwar-kameez", sku: "CSD-3P-002",
      description: "Deep sapphire blue shalwar kameez with colorful resham embroidery and a soft matching scarf. A timeless silhouette designed for elegance and everyday comfort.",
      fabric: "Cotton Lawn with Resham Embroidery", care: "Hand wash recommended. Dry in shade.",
      specifications: [{ label: "Pieces", value: "3" }, { label: "Embroidery", value: "Resham thread work" }],
      price: 5890, oldPrice: 6900, stock: 18, categoryId: catId("3-piece-suits"), sizes: sizesStd, colors: ["Blue", "Navy"],
      tags: ["shalwar kameez", "embroidered", "blue"], images: [img(20777203), img(25184993), img(20690516)],
      imageAlt: "Sapphire blue embroidered shalwar kameez with scarf", isFeatured: true, isNewArrival: true, onSale: true, salesCount: 96,
    },
    {
      name: "Lavender Dream Embroidered 2 Piece", slug: "lavender-dream-embroidered-2-piece", sku: "CSD-2P-001",
      description: "Soft lavender 2 piece set with delicate floral embroidery on the neckline and sleeves. Lightweight and graceful — ideal for daytime events.",
      fabric: "Premium Lawn", care: "Machine wash gentle cycle. Iron inside out.",
      specifications: [{ label: "Pieces", value: "2 (Shirt, Trouser)" }],
      price: 4290, oldPrice: 5200, stock: 30, categoryId: catId("2-piece-suits"), sizes: sizesStd, colors: ["Lavender", "Purple"],
      tags: ["2 piece", "embroidered", "lavender"], images: [img(36104974), img(36552686), img(25184991)],
      imageAlt: "Lavender embroidered 2 piece suit", isFeatured: true, isNewArrival: true, onSale: true, salesCount: 82,
    },
    {
      name: "Royal Plum Formal Embroidered Suit", slug: "royal-plum-formal-embroidered-suit", sku: "CSD-3P-003",
      description: "A regal plum-toned formal suit with dense embroidery, designed for weddings and special evenings. Crafted with premium fabric and finished with fine detailing.",
      fabric: "Jacquard Lawn with Zari Accents", care: "Dry clean recommended.",
      specifications: [{ label: "Pieces", value: "3" }, { label: "Occasion", value: "Formal / Wedding" }],
      price: 8990, oldPrice: 11500, stock: 12, categoryId: catId("embroidered"), sizes: unstitched, colors: ["Plum", "Purple"],
      tags: ["formal", "embroidered", "wedding"], images: [img(36552686), img(36104974), img(39299427)],
      imageAlt: "Royal plum formal embroidered suit", isBestSeller: true, onSale: true, salesCount: 121,
    },
    {
      name: "Pearl Grey Classic Suit with Scarf", slug: "pearl-grey-classic-suit-with-scarf", sku: "CSD-2P-002",
      description: "Understated elegance in pearl grey with tonal embroidery and a flowing matching scarf. A versatile piece that pairs beautifully with minimal accessories.",
      fabric: "Cotton Cambric", care: "Machine wash cold with like colors.",
      specifications: [{ label: "Pieces", value: "2 + Scarf" }],
      price: 4790, oldPrice: null, stock: 26, categoryId: catId("2-piece-suits"), sizes: sizesStd, colors: ["Grey", "Silver"],
      tags: ["2 piece", "classic", "grey"], images: [img(25185000), img(25184999)],
      imageAlt: "Pearl grey classic suit with matching scarf", isFeatured: true, salesCount: 64,
    },
    {
      name: "Olive Garden Embroidered Lawn Suit", slug: "olive-garden-embroidered-lawn-suit", sku: "CSD-LW-001",
      description: "Earthy olive lawn suit with botanical embroidery — breathable, soft and perfect for warm days while keeping a refined look.",
      fabric: "Super Fine Lawn", care: "Machine wash gentle. Do not wring.",
      specifications: [{ label: "Pieces", value: "3" }, { label: "Season", value: "Summer" }],
      price: 5490, oldPrice: 6400, stock: 20, categoryId: catId("lawn"), sizes: unstitched, colors: ["Olive", "Green"],
      tags: ["lawn", "summer", "embroidered"], images: [img(25184952), img(36325969)],
      imageAlt: "Olive green embroidered lawn suit", isNewArrival: true, onSale: true, salesCount: 58,
    },
    {
      name: "Arabian Nights Soft Lawn Collection Suit", slug: "arabian-nights-soft-lawn-suit", sku: "CSD-AL-001",
      description: "From our Arabic lawn line — an ultra-soft, flowing suit with subtle sheen and graceful drape, inspired by Middle-Eastern silhouettes.",
      fabric: "Arabic Lawn (Extra Soft Finish)", care: "Hand wash or gentle cycle.",
      specifications: [{ label: "Pieces", value: "3" }, { label: "Finish", value: "Silk-touch soft" }],
      price: 6890, oldPrice: null, stock: 15, categoryId: catId("arabic-lawn"), sizes: unstitched, colors: ["Ivory", "Gold"],
      tags: ["arabic lawn", "soft", "premium"], images: [img(39299427), img(26970930)],
      imageAlt: "Arabic lawn premium soft suit", isFeatured: true, isNewArrival: true, salesCount: 41,
    },
    {
      name: "Vibrant Fiesta Printed Lawn 2 Piece", slug: "vibrant-fiesta-printed-lawn-2-piece", sku: "CSD-PR-001",
      description: "Playful, vibrant prints on breathable lawn — a cheerful everyday outfit that keeps you cool and stylish.",
      fabric: "Printed Lawn", care: "Machine wash cold. Wash dark colors separately.",
      specifications: [{ label: "Pieces", value: "2" }],
      price: 3290, oldPrice: 3990, stock: 40, categoryId: catId("printed"), sizes: sizesStd, colors: ["Multi", "Yellow"],
      tags: ["printed", "casual", "lawn"], images: [img(25288427), img(12067199)],
      imageAlt: "Vibrant printed lawn 2 piece suit", isBestSeller: true, onSale: true, salesCount: 173,
    },
    {
      name: "Heritage Blue Printed Kameez Set", slug: "heritage-blue-printed-kameez-set", sku: "CSD-PR-002",
      description: "Traditional block-print inspired patterns in serene blue tones. A comfortable set that celebrates heritage craft with a modern cut.",
      fabric: "Cotton Lawn", care: "Machine wash gentle cycle.",
      specifications: [{ label: "Pieces", value: "2" }],
      price: 3690, oldPrice: null, stock: 22, categoryId: catId("printed"), sizes: sizesStd, colors: ["Blue", "White"],
      tags: ["printed", "traditional", "blue"], images: [img(20690516), img(20777203)],
      imageAlt: "Heritage blue printed kameez set", salesCount: 37,
    },
    {
      name: "Rosewood Vibrant Dupatta", slug: "rosewood-vibrant-dupatta", sku: "CSD-DP-001",
      description: "A luxurious statement dupatta in rich rosewood tones with delicate border detailing — the perfect finishing touch for any outfit.",
      fabric: "Chiffon with Woven Border", care: "Hand wash only. Iron on low heat.",
      specifications: [{ label: "Length", value: "2.5 meters" }, { label: "Width", value: "1 meter" }],
      price: 1890, oldPrice: 2400, stock: 50, categoryId: catId("dupattas"), sizes: ["One Size"], colors: ["Rosewood", "Red"],
      tags: ["dupatta", "chiffon", "accessory"], images: [img(26970930), img(27603286)],
      imageAlt: "Rosewood vibrant chiffon dupatta", onSale: true, isBestSeller: true, salesCount: 205,
    },
    {
      name: "Golden Hour Silk-Touch Dupatta", slug: "golden-hour-silk-touch-dupatta", sku: "CSD-DP-002",
      description: "Silk-touch dupatta that catches the light beautifully — drapes effortlessly and elevates simple outfits instantly.",
      fabric: "Silk-Touch Polyester Blend", care: "Hand wash. Do not tumble dry.",
      specifications: [{ label: "Length", value: "2.5 meters" }],
      price: 1590, oldPrice: null, stock: 3, categoryId: catId("dupattas"), sizes: ["One Size"], colors: ["Gold", "Yellow"],
      tags: ["dupatta", "gold"], images: [img(12067199), img(26970930)],
      imageAlt: "Golden silk-touch dupatta", isNewArrival: true, salesCount: 29,
    },
    {
      name: "Classic Cambric Straight Trousers", slug: "classic-cambric-straight-trousers", sku: "CSD-TR-001",
      description: "Wardrobe-essential straight-cut trousers in premium cambric cotton. Pre-shrunk, comfortable and built to last.",
      fabric: "Cambric Cotton", care: "Machine wash. Tumble dry low.",
      specifications: [{ label: "Cut", value: "Straight" }, { label: "Waist", value: "Elasticated with drawstring" }],
      price: 1990, oldPrice: 2490, stock: 60, categoryId: catId("trousers"), sizes: sizesStd, colors: ["White", "Black", "Beige"],
      tags: ["trousers", "basics", "cotton"], images: [img(19281311), img(25184991)],
      imageAlt: "Classic cambric straight trousers", onSale: true, salesCount: 88,
    },
    {
      name: "Midnight Sky Embroidered Kurta Trouser Set", slug: "midnight-sky-embroidered-kurta-trouser-set", sku: "CSD-2P-003",
      description: "Elegant kurta and trouser set with celestial embroidery motifs — refined enough for evenings, comfortable enough for all day.",
      fabric: "Premium Viscose Blend", care: "Gentle wash. Iron on reverse.",
      specifications: [{ label: "Pieces", value: "2" }],
      price: 5190, oldPrice: null, stock: 16, categoryId: catId("2-piece-suits"), sizes: sizesStd, colors: ["Navy", "Black"],
      tags: ["kurta", "embroidered", "evening"], images: [img(19281311), img(25184999)],
      imageAlt: "Midnight embroidered kurta trouser set", isNewArrival: true, salesCount: 22,
    },
    {
      name: "Blush Petal Embroidered Luxury Suit", slug: "blush-petal-embroidered-luxury-suit", sku: "CSD-EM-001",
      description: "Our signature luxury piece with dense floral embroidery, sequin highlights and premium finishing throughout — a true showstopper.",
      fabric: "Luxury Lawn with Sequin Embroidery", care: "Dry clean only.",
      specifications: [{ label: "Pieces", value: "3" }, { label: "Occasion", value: "Luxury / Formal" }],
      price: 9490, oldPrice: 12900, stock: 8, categoryId: catId("embroidered"), sizes: unstitched, colors: ["Pink", "Blush"],
      tags: ["luxury", "embroidered", "formal"], images: [img(25184999), img(27603286), img(36104974)],
      imageAlt: "Blush petal embroidered luxury suit", isFeatured: true, isBestSeller: true, onSale: true, salesCount: 67,
    },
    {
      name: "Artisan Handwoven Textile Gift Set", slug: "artisan-handwoven-textile-gift-set", sku: "CSD-GF-001",
      description: "A curated gift set of artisan textiles — beautifully folded, ready to gift. Celebrate craft with this thoughtfully assembled collection.",
      fabric: "Mixed Artisan Weaves", care: "See individual item labels.",
      specifications: [{ label: "Contents", value: "Assorted textile pieces" }],
      price: 4990, oldPrice: null, stock: 0, categoryId: catId("dupattas"), sizes: ["One Size"], colors: ["Multi"],
      tags: ["gift", "artisan", "textile"], images: [img(5656671)],
      imageAlt: "Artisan handwoven textile gift set", salesCount: 15,
    },
    {
      name: "Serene Sage Arabic Lawn 3 Piece", slug: "serene-sage-arabic-lawn-3-piece", sku: "CSD-AL-002",
      description: "Calming sage tones on ultra-soft Arabic lawn with tonal embroidery — grace and comfort in one timeless outfit.",
      fabric: "Arabic Lawn", care: "Gentle machine wash. Dry in shade.",
      specifications: [{ label: "Pieces", value: "3" }],
      price: 6290, oldPrice: 7500, stock: 14, categoryId: catId("arabic-lawn"), sizes: unstitched, colors: ["Sage", "Green"],
      tags: ["arabic lawn", "3 piece", "sage"], images: [img(20629032), img(25184952)],
      imageAlt: "Serene sage Arabic lawn 3 piece suit", isNewArrival: true, onSale: true, salesCount: 33,
    },
  ];
  await db.insert(products).values(prods);

  // ---- Coupons ----
  await db.insert(coupons).values([
    { code: "WELCOME10", type: "percent", value: 10, minOrder: 3000, maxDiscount: 1500, isActive: true },
    { code: "SAVE500", type: "fixed", value: 500, minOrder: 8000, isActive: true },
  ]);

  // ---- Blog posts ----
  const post = (title: string, slug: string, category: string, tags: string[], image: string, imageAlt: string, excerpt: string, paragraphs: string[]) => ({
    title, slug, category, tags, image, imageAlt, excerpt,
    content: paragraphs.join("\n\n"),
    seoTitle: `${title} | CS Digital Worker Blog`,
    seoDescription: excerpt,
  });

  await db.insert(blogPosts).values([
    post(
      "How to Choose the Perfect Lawn Suit for Summer", "how-to-choose-perfect-lawn-suit-summer", "Shopping Guides",
      ["lawn", "summer", "buying guide"], img(20690516), "Woman wearing a blue lawn suit",
      "A practical guide to fabric weight, prints, embroidery and fit so you pick a lawn suit you will actually love wearing all summer.",
      [
        "Lawn is the fabric of Pakistani summers — lightweight, breathable and endlessly versatile. But with hundreds of collections launching every season, choosing the right suit can feel overwhelming. This guide breaks the decision into four simple checks.",
        "## 1. Check the fabric weight\nGenuine premium lawn feels soft and slightly crisp, never plasticky. If you shop online, look for product pages that state the fabric composition clearly, like we do on every CS Digital Worker listing.",
        "## 2. Match prints to occasions\nBold, saturated prints are wonderful for daytime events, while tonal or pastel prints work better for the office. Embroidered fronts elevate a suit for evening wear without needing heavy accessories.",
        "## 3. Confirm the piece count\nA 2 piece typically includes a shirt and trouser, while a 3 piece adds a dupatta. Always check what is included — our product specifications list every piece and its length.",
        "## 4. Read the care instructions\nLawn keeps its color for years when washed gently in cold water. We publish care instructions on every product so your outfit stays beautiful season after season.",
        "Ready to refresh your summer wardrobe? Browse our lawn collection and enjoy cash on delivery across Pakistan.",
      ]
    ),
    post(
      "SEO Basics Every Online Store Owner Should Know", "seo-basics-every-online-store-owner-should-know", "SEO",
      ["seo", "online business", "google"], img(5656671), "Organized colorful products representing an online store catalog",
      "Learn the fundamentals of e-commerce SEO — titles, descriptions, structured data and internal linking — explained in plain language.",
      [
        "Search engine optimization is the most sustainable source of free traffic for any online store. The fundamentals are simpler than most agencies make them sound.",
        "## Write unique titles and descriptions\nEvery product and category page should have its own descriptive title tag and meta description. Duplicate titles confuse search engines and cost you clicks.",
        "## Use structured data\nProduct schema helps Google show your price, availability and ratings directly in search results. Modern platforms can generate this automatically.",
        "## Build a logical internal structure\nHome → Category → Product with breadcrumbs at each level helps both users and crawlers understand your catalog.",
        "## Publish helpful content\nA blog that genuinely answers customer questions builds topical authority and captures long-tail searches — exactly what you are reading right now.",
        "At CS Digital Worker we apply these principles across our own store, and we offer SEO services for businesses that want expert help.",
      ]
    ),
    post(
      "5 AI Tools That Save Small Businesses Hours Every Week", "5-ai-tools-that-save-small-businesses-hours", "AI Tools",
      ["ai", "productivity", "tools"], img(12067199), "Creative professional representing modern digital work",
      "From writing product descriptions to answering customer questions, these categories of AI tools deliver real time savings for small teams.",
      [
        "Artificial intelligence has moved from hype to genuinely useful. For small business owners, the biggest wins come from automating repetitive work.",
        "## 1. Writing assistants\nDrafting product descriptions, emails and social captions is dramatically faster with an AI writing assistant — just always review and personalize the output.",
        "## 2. Image editing tools\nBackground removal and photo cleanup that used to require a designer now takes seconds.",
        "## 3. Customer support chat\nAI-assisted chat can answer common questions instantly, while complex queries still route to a human — like our WhatsApp support line.",
        "## 4. Analytics summarizers\nInstead of staring at dashboards, modern tools can summarize what changed in your store traffic and sales this week.",
        "## 5. Inventory forecasting\nEven simple AI-powered forecasting helps you reorder bestsellers before they run out.",
        "Want help implementing AI in your business? CS Digital Worker offers digital services — get in touch through our contact page.",
      ]
    ),
    post(
      "Cash on Delivery vs Online Payments: What Pakistani Shoppers Prefer", "cod-vs-online-payments-pakistan", "E-Commerce",
      ["payments", "cod", "pakistan"], img(25288427), "Confident shopper representing modern Pakistani e-commerce",
      "Why cash on delivery still dominates Pakistani e-commerce, and how stores can build the trust needed for digital payments.",
      [
        "Cash on delivery remains the most popular payment method in Pakistani e-commerce. Understanding why helps both shoppers and store owners.",
        "## Trust comes first\nCOD lets customers verify their order exists before paying. New stores especially benefit from offering it, which is why CS Digital Worker supports COD nationwide.",
        "## The rise of bank transfers\nDirect bank transfer is increasingly common for higher-value orders, offering a paper trail for both sides.",
        "## What builds payment confidence\nClear return policies, real contact information, and responsive support (like a WhatsApp line) all make customers comfortable paying online.",
        "## The future\nAs local payment gateways mature, expect more stores to add card and wallet payments. Our platform is already prepared for online gateway integration when the time is right.",
      ]
    ),
    post(
      "Caring for Embroidered Outfits: A Complete Guide", "caring-for-embroidered-outfits-guide", "Fashion",
      ["embroidery", "care", "fashion"], img(36325969), "Detailed embroidered green outfit",
      "Embroidered outfits are an investment. These washing, storage and ironing tips keep threadwork and sequins looking new for years.",
      [
        "Beautiful embroidery deserves careful handling. With a few simple habits, your embroidered suits will look pristine for years.",
        "## Washing\nAlways turn embroidered garments inside out and wash by hand or on the gentlest cycle in cold water. Never wring the fabric — press water out gently.",
        "## Drying\nDry flat in shade. Direct sunlight fades colored threads faster than the base fabric, creating an uneven look.",
        "## Ironing\nIron on the reverse side with a pressing cloth over dense embroidery. Steam from a distance for sequined areas.",
        "## Storage\nFold with tissue paper between embroidered surfaces, or hang on padded hangers. Avoid plastic covers which trap humidity.",
        "Every embroidered product at CS Digital Worker includes specific care instructions on its product page.",
      ]
    ),
    post(
      "Starting an Online Business in 2025: A Realistic Roadmap", "starting-online-business-realistic-roadmap", "Online Business",
      ["startup", "digital marketing", "guide"], img(27603286), "Elegant product presentation representing online retail",
      "Skip the get-rich-quick noise. Here is a realistic, step-by-step roadmap for launching a sustainable online business.",
      [
        "Starting an online business is more accessible than ever, but sustainable success follows a predictable path.",
        "## Step 1: Validate before you build\nTalk to potential customers and pre-sell if possible. A small waiting list beats months of building in the dark.",
        "## Step 2: Start with one channel\nMaster one acquisition channel — organic social, SEO, or ads — before spreading thin across all of them.",
        "## Step 3: Set up proper infrastructure\nA real website with product management, order tracking and analytics beats DM-based selling as soon as you have consistent orders.",
        "## Step 4: Systematize customer service\nFast, honest responses turn first buyers into repeat customers. Publish clear shipping and return policies.",
        "## Step 5: Reinvest in what works\nTrack every rupee. Double down on products and channels with proven demand.",
        "CS Digital Worker offers website, SEO and digital marketing services for businesses ready to level up — reach out via WhatsApp or our contact form.",
      ]
    ),
  ]);

  // ---- Settings ----
  const defaults: Record<string, string> = {
    announcement: "Free shipping on orders over Rs. 5,000 — Use code WELCOME10 for 10% off your first order!",
    announcementEnabled: "1",
    shippingFlatRate: "250",
    freeShippingThreshold: "5000",
  };
  for (const [key, value] of Object.entries(defaults)) {
    await db.insert(settings).values({ key, value }).onConflictDoNothing();
  }

  console.log("Seed complete.");
  await pool.end();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
