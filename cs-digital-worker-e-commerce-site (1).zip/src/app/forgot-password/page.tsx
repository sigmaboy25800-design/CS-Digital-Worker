"use client";

import Link from "next/link";
import { useState } from "react";
import { Spinner } from "@/components/ui";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [resetUrl, setResetUrl] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/forgot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (res.ok) {
        setMessage(data.message);
        setResetUrl(data.resetUrl ?? null);
      } else setError(data.error);
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container-x py-14 max-w-md">
      <h1 className="font-display text-3xl font-bold text-slate-900 text-center">Forgot Password</h1>
      <p className="text-slate-500 text-center mt-2 mb-8">Enter your email and we&apos;ll generate a secure reset link.</p>
      {message ? (
        <div className="card p-6 text-center space-y-4">
          <p className="text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-sm">{message}</p>
          {resetUrl && (
            <div className="text-sm text-slate-600">
              <p className="mb-3">Email delivery is not configured on this environment yet, so use your secure one-time link below (valid for 1 hour):</p>
              <Link href={resetUrl} className="btn-primary btn-md">Reset My Password</Link>
            </div>
          )}
          <Link href="/login" className="block text-sm text-brand-700 hover:underline">Back to Sign In</Link>
        </div>
      ) : (
        <form onSubmit={submit} className="card p-6 space-y-4">
          <div>
            <label htmlFor="email" className="label">Email</label>
            <input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="input" autoComplete="email" />
          </div>
          {error && <p className="text-sm text-rose-600" role="alert">{error}</p>}
          <button type="submit" disabled={loading} className="btn-primary btn-lg w-full">
            {loading ? <Spinner /> : "Generate Reset Link"}
          </button>
          <p className="text-sm text-center">
            <Link href="/login" className="text-brand-700 hover:underline">Back to Sign In</Link>
          </p>
        </form>
      )}
    </div>
  );
}
