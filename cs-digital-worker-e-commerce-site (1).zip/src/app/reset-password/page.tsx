"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { Spinner } from "@/components/ui";

function ResetInner() {
  const token = useSearchParams().get("token") ?? "";
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirm) { setError("Passwords do not match."); return; }
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/reset", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, password }),
      });
      const data = await res.json();
      if (res.ok) setMessage(data.message);
      else setError(data.error);
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container-x py-14 max-w-md">
      <h1 className="font-display text-3xl font-bold text-slate-900 text-center mb-8">Reset Password</h1>
      {message ? (
        <div className="card p-6 text-center space-y-4">
          <p className="text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-sm">{message}</p>
          <Link href="/login" className="btn-primary btn-md">Sign In</Link>
        </div>
      ) : (
        <form onSubmit={submit} className="card p-6 space-y-4">
          <div>
            <label htmlFor="password" className="label">New Password (min 8 characters)</label>
            <input id="password" type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} className="input" autoComplete="new-password" />
          </div>
          <div>
            <label htmlFor="confirm" className="label">Confirm New Password</label>
            <input id="confirm" type="password" required value={confirm} onChange={(e) => setConfirm(e.target.value)} className="input" autoComplete="new-password" />
          </div>
          {error && <p className="text-sm text-rose-600" role="alert">{error}</p>}
          <button type="submit" disabled={loading} className="btn-primary btn-lg w-full">
            {loading ? <Spinner /> : "Update Password"}
          </button>
        </form>
      )}
    </div>
  );
}

export default function ResetPasswordPage() {
  return (
    <Suspense fallback={<div className="container-x py-16 flex justify-center"><Spinner className="h-8 w-8 text-brand-700" /></div>}>
      <ResetInner />
    </Suspense>
  );
}
