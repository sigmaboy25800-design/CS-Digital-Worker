import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { and, desc, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { categories, products, reviews } from "@/db/schema";
import { getProductBySlug } from "@/lib/shop";
import ProductDetail from "@/components/ProductDetail";
import ReviewSection from "@/components/ReviewSection";
import RecentlyViewed from "@/components/RecentlyViewed";
import ProductCard, { type CardProduct } from "@/components/ProductCard";
import { Breadcrumbs } from "@/components/ui";
import { SITE_URL } from "@/lib/utils";
import type { Product } from "@/db/schema";

export const dynamic = "force-dynamic";

function toCard(p: Product): CardProduct {
  return {
    id: p.id, slug: p.slug, name: p.name, images: p.images ?? [],
    imageAlt: p.imageAlt, price: p.price, oldPrice: p.oldPrice, stock: p.stock,
    ratingAvg: p.ratingAvg, ratingCount: p.ratingCount,
    sizes: p.sizes ?? [], colors: p.colors ?? [], isNewArrival: p.isNewArrival,
  };
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) return { title: "Product Not Found" };
  return {
    title: product.seoTitle ?? product.name,
    description: product.seoDescription ?? product.description?.slice(0, 160),
    alternates: { canonical: `/product/${product.slug}` },
    openGraph: {
      title: product.seoTitle ?? product.name,
      description: product.seoDescription ?? product.description?.slice(0, 160) ?? undefined,
      images: product.images?.slice(0, 1),
      type: "website",
    },
  };
}

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product || !product.isActive) notFound();

  const [category, related, approvedReviews] = await Promise.all([
    product.categoryId
      ? db.select().from(categories).where(eq(categories.id, product.categoryId)).limit(1).then((r) => r[0] ?? null)
      : Promise.resolve(null),
    product.categoryId
      ? db.select().from(products)
          .where(and(eq(products.isActive, true), eq(products.categoryId, product.categoryId), ne(products.id, product.id)))
          .orderBy(desc(products.salesCount)).limit(4)
      : Promise.resolve([]),
    db.select().from(reviews)
      .where(and(eq(reviews.productId, product.id), eq(reviews.status, "approved")))
      .orderBy(desc(reviews.createdAt)).limit(20),
  ]);

  const productSchema = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.name,
    sku: product.sku,
    image: product.images,
    description: product.seoDescription ?? product.description,
    brand: { "@type": "Brand", name: "CS Digital Worker" },
    offers: {
      "@type": "Offer",
      url: `${SITE_URL}/product/${product.slug}`,
      priceCurrency: "PKR",
      price: product.price,
      availability: product.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
      itemCondition: "https://schema.org/NewCondition",
    },
    ...(product.ratingCount > 0
      ? {
          aggregateRating: {
            "@type": "AggregateRating",
            ratingValue: product.ratingAvg.toFixed(1),
            reviewCount: product.ratingCount,
          },
        }
      : {}),
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: SITE_URL },
      { "@type": "ListItem", position: 2, name: "Shop", item: `${SITE_URL}/shop` },
      ...(category ? [{ "@type": "ListItem", position: 3, name: category.name, item: `${SITE_URL}/category/${category.slug}` }] : []),
      { "@type": "ListItem", position: category ? 4 : 3, name: product.name, item: `${SITE_URL}/product/${product.slug}` },
    ],
  };

  return (
    <div className="container-x py-8">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />

      <Breadcrumbs
        items={[
          { label: "Shop", href: "/shop" },
          ...(category ? [{ label: category.name, href: `/category/${category.slug}` }] : []),
          { label: product.name },
        ]}
      />

      <ProductDetail
        product={{
          id: product.id, slug: product.slug, name: product.name, sku: product.sku,
          images: product.images ?? [], imageAlt: product.imageAlt,
          price: product.price, oldPrice: product.oldPrice, stock: product.stock,
          ratingAvg: product.ratingAvg, ratingCount: product.ratingCount,
          sizes: product.sizes ?? [], colors: product.colors ?? [], tags: product.tags ?? [],
          categoryName: category?.name ?? null,
        }}
      />

      {/* Description & Specifications */}
      <div className="mt-12 grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card p-6">
          <h2 className="font-display text-xl font-bold text-slate-900 mb-3">Description</h2>
          <p className="text-slate-600 leading-relaxed">{product.description}</p>
          {product.fabric && (
            <>
              <h3 className="font-display font-bold text-slate-900 mt-5 mb-1.5">Fabric & Material</h3>
              <p className="text-slate-600 text-sm">{product.fabric}</p>
            </>
          )}
          {product.care && (
            <>
              <h3 className="font-display font-bold text-slate-900 mt-5 mb-1.5">Care Instructions</h3>
              <p className="text-slate-600 text-sm">{product.care}</p>
            </>
          )}
        </div>
        <div className="card p-6">
          <h2 className="font-display text-xl font-bold text-slate-900 mb-3">Specifications</h2>
          <dl className="space-y-2.5 text-sm">
            <div className="flex justify-between gap-2 border-b border-slate-100 pb-2">
              <dt className="text-slate-500">SKU</dt>
              <dd className="font-medium text-slate-800">{product.sku}</dd>
            </div>
            {category && (
              <div className="flex justify-between gap-2 border-b border-slate-100 pb-2">
                <dt className="text-slate-500">Category</dt>
                <dd className="font-medium text-slate-800">{category.name}</dd>
              </div>
            )}
            {(product.specifications ?? []).map((s) => (
              <div key={s.label} className="flex justify-between gap-2 border-b border-slate-100 pb-2">
                <dt className="text-slate-500">{s.label}</dt>
                <dd className="font-medium text-slate-800 text-right">{s.value}</dd>
              </div>
            ))}
            {(product.colors ?? []).length > 0 && (
              <div className="flex justify-between gap-2">
                <dt className="text-slate-500">Available Colors</dt>
                <dd className="font-medium text-slate-800 text-right">{(product.colors ?? []).join(", ")}</dd>
              </div>
            )}
          </dl>
        </div>
      </div>

      {/* Reviews */}
      <div className="mt-12">
        <ReviewSection
          productId={product.id}
          initialReviews={approvedReviews.map((r) => ({
            id: r.id, name: r.name, rating: r.rating, title: r.title,
            comment: r.comment, createdAt: r.createdAt.toISOString(),
          }))}
        />
      </div>

      {/* Related */}
      {related.length > 0 && (
        <section className="mt-14" aria-labelledby="related-heading">
          <h2 id="related-heading" className="font-display text-2xl font-bold text-slate-900 mb-5">Related Products</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {related.map((p) => <ProductCard key={p.id} product={toCard(p)} />)}
          </div>
        </section>
      )}

      <RecentlyViewed
        current={{
          productId: product.id, slug: product.slug, name: product.name,
          image: product.images?.[0] ?? "", price: product.price, oldPrice: product.oldPrice,
        }}
      />
    </div>
  );
}
