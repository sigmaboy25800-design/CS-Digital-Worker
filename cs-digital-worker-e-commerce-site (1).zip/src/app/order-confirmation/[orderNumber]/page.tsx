import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { CONTACT, formatDate, formatPrice, STATUS_LABELS } from "@/lib/utils";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Order Confirmation", robots: { index: false } };

export default async function OrderConfirmationPage({
  params,
}: {
  params: Promise<{ orderNumber: string }>;
}) {
  const { orderNumber } = await params;
  const [order] = await db.select().from(orders)
    .where(eq(orders.orderNumber, decodeURIComponent(orderNumber).toUpperCase()))
    .limit(1);
  if (!order) notFound();
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));

  return (
    <div className="container-x py-10 max-w-3xl">
      <div className="text-center mb-8">
        <div className="h-16 w-16 mx-auto rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-3xl" aria-hidden>✓</div>
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900 mt-4">Thank You! Order Confirmed</h1>
        <p className="text-slate-500 mt-2">
          Your order <strong className="text-brand-800">{order.orderNumber}</strong> was placed on {formatDate(order.createdAt)}.
          We&apos;ve sent the details to <strong>{order.email}</strong>.
        </p>
      </div>

      <div className="card overflow-hidden">
        <div className="bg-brand-950 text-white px-6 py-4 flex flex-wrap justify-between gap-2">
          <div>
            <p className="text-xs text-brand-200 uppercase tracking-wide">Order Number</p>
            <p className="font-bold">{order.orderNumber}</p>
          </div>
          <div>
            <p className="text-xs text-brand-200 uppercase tracking-wide">Status</p>
            <p className="font-bold">{STATUS_LABELS[order.status]}</p>
          </div>
          <div>
            <p className="text-xs text-brand-200 uppercase tracking-wide">Payment</p>
            <p className="font-bold">{order.paymentMethod === "cod" ? "Cash on Delivery" : "Bank Transfer"}</p>
          </div>
          <div>
            <p className="text-xs text-brand-200 uppercase tracking-wide">Total</p>
            <p className="font-bold">{formatPrice(order.total)}</p>
          </div>
        </div>
        <div className="p-6">
          <h2 className="font-display font-bold text-lg text-slate-900 mb-3">Items</h2>
          <ul className="divide-y divide-slate-100">
            {items.map((item) => (
              <li key={item.id} className="py-3 flex gap-3 items-center">
                {item.image && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={item.image} alt={item.name} className="h-14 w-11 object-cover rounded" />
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-800">{item.name}</p>
                  <p className="text-xs text-slate-400">{[item.size, item.color].filter(Boolean).join(" / ")} × {item.quantity}</p>
                </div>
                <span className="text-sm font-bold">{formatPrice(item.total)}</span>
              </li>
            ))}
          </ul>
          <dl className="mt-4 space-y-1.5 text-sm border-t border-slate-100 pt-4">
            <div className="flex justify-between"><dt className="text-slate-500">Subtotal</dt><dd>{formatPrice(order.subtotal)}</dd></div>
            {order.discount > 0 && <div className="flex justify-between text-emerald-600"><dt>Discount {order.couponCode ? `(${order.couponCode})` : ""}</dt><dd>−{formatPrice(order.discount)}</dd></div>}
            <div className="flex justify-between"><dt className="text-slate-500">Shipping</dt><dd>{order.shipping === 0 ? "Free" : formatPrice(order.shipping)}</dd></div>
            <div className="flex justify-between font-bold text-base pt-1"><dt>Grand Total</dt><dd className="text-brand-800">{formatPrice(order.total)}</dd></div>
          </dl>
          <div className="mt-5 bg-slate-50 rounded-lg p-4 text-sm">
            <p className="font-semibold text-slate-800 mb-1">Delivery Address</p>
            <p className="text-slate-600">{order.fullName} • {order.phone}</p>
            <p className="text-slate-600">{order.address}, {order.city} {order.postalCode}</p>
          </div>
          {order.paymentMethod === "bank_transfer" && (
            <p className="mt-4 text-sm bg-amber-50 border border-amber-200 text-amber-800 rounded-lg p-3">
              Bank transfer details will be shared with you via WhatsApp/Email shortly to complete your payment.
            </p>
          )}
        </div>
      </div>

      <div className="mt-6 flex flex-wrap justify-center gap-3 no-print">
        <Link href={`/track-order?orderNumber=${order.orderNumber}&email=${encodeURIComponent(order.email)}`} className="btn-primary btn-md">Track Order</Link>
        <Link href="/shop" className="btn-outline btn-md">Continue Shopping</Link>
        <a href={CONTACT.whatsappHref} target="_blank" rel="noopener noreferrer" className="btn btn-md bg-emerald-500 text-white hover:bg-emerald-600">WhatsApp Support</a>
      </div>
      <p className="text-center text-xs text-slate-400 mt-4">
        Need help? Call <a href={CONTACT.phoneHref} className="underline">{CONTACT.phone}</a> or email{" "}
        <a href={CONTACT.emailHref} className="underline">{CONTACT.email}</a>
      </p>
    </div>
  );
}
