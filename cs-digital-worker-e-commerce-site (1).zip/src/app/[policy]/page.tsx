import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Breadcrumbs } from "@/components/ui";
import { CONTACT } from "@/lib/utils";

const POLICIES: Record<string, { title: string; description: string; sections: { h: string; body: string[] }[] }> = {
  "shipping-policy": {
    title: "Shipping Policy",
    description: "Delivery timelines, shipping charges and coverage areas for CS Digital Worker orders across Pakistan.",
    sections: [
      { h: "Delivery Coverage", body: ["We deliver nationwide across Pakistan through trusted courier partners. Remote areas may require 1–2 extra working days."] },
      { h: "Delivery Time", body: ["Orders are dispatched within 1–2 working days of confirmation and typically delivered within 3–7 working days. During sales or public holidays, delivery may take slightly longer."] },
      { h: "Shipping Charges", body: ["A flat shipping fee of Rs. 250 applies to standard orders.", "Orders of Rs. 5,000 or more (after discounts) qualify for FREE shipping automatically."] },
      { h: "Order Tracking", body: ["As soon as your order ships, its status updates in your account and on the Track Order page. Use your order number and checkout email to view live progress at any time."] },
      { h: "Failed Deliveries", body: ["Our courier attempts delivery up to two times. If delivery fails, our team will contact you by phone or WhatsApp to reschedule."] },
    ],
  },
  "return-policy": {
    title: "Return & Refund Policy",
    description: "Our 7-day easy return and refund policy for CS Digital Worker orders — simple, fair and transparent.",
    sections: [
      { h: "7-Day Returns", body: ["You may return any unused, unwashed item in its original packaging within 7 days of delivery. Items with removed tags, signs of use, or perfume/stains cannot be accepted."] },
      { h: "How to Start a Return", body: [`Message us on WhatsApp at ${CONTACT.phone} or email ${CONTACT.email} with your order number and reason. Our team will confirm eligibility and arrange pickup or guide you to the nearest courier drop-off.`] },
      { h: "Refunds", body: ["Once your return passes inspection (1–3 working days after receipt), refunds are issued via bank transfer or as store credit — your choice. COD order refunds are sent by bank transfer."] },
      { h: "Exchanges", body: ["Wrong size or color? We're happy to exchange, subject to stock availability. Exchange shipping is free if the error was ours."] },
      { h: "Damaged or Wrong Items", body: ["If your order arrives damaged, defective or incorrect, contact us within 48 hours with photos. We'll replace it or refund you in full, including shipping."] },
      { h: "Cancellation Policy", body: ["Orders can be cancelled free of charge while their status is Pending or Confirmed — request cancellation from your account or contact support. Once shipped, the standard return process applies."] },
    ],
  },
  "privacy-policy": {
    title: "Privacy Policy",
    description: "How CS Digital Worker collects, uses and protects your personal information.",
    sections: [
      { h: "Information We Collect", body: ["We collect only the information needed to serve you: your name, email, phone, delivery address, order history, and messages you send us. We never ask for unnecessary sensitive information."] },
      { h: "Payment Information", body: ["We do NOT collect or store payment card details. Cash on Delivery requires no payment data, and bank transfers happen directly through your own bank."] },
      { h: "How We Use Your Data", body: ["Your data is used to process orders, deliver products, provide customer support, and — only if you subscribe — send our newsletter. We do not sell or rent your personal information to anyone."] },
      { h: "Cookies & Analytics", body: ["We use essential cookies for your session and cart. If analytics tools (such as Google Analytics) are enabled, they collect anonymized usage statistics to help us improve the store."] },
      { h: "Data Security", body: ["Passwords are stored using strong one-way hashing. Sessions use secure, httpOnly cookies. Access to customer data is restricted to authorized staff only."] },
      { h: "Your Rights", body: [`You may request a copy of your data, correction, or deletion of your account at any time by emailing ${CONTACT.email}.`] },
    ],
  },
  terms: {
    title: "Terms & Conditions",
    description: "The terms and conditions governing your use of the CS Digital Worker website and services.",
    sections: [
      { h: "General", body: ["By using the CS Digital Worker website and placing orders you agree to these terms. We may update them from time to time; the latest version always applies."] },
      { h: "Products & Pricing", body: ["We work hard to display accurate product photos, descriptions and prices. All prices are in Pakistani Rupees (PKR) and include applicable taxes unless stated otherwise. In case of an obvious pricing error, we reserve the right to cancel affected orders with a full refund."] },
      { h: "Orders", body: ["An order is confirmed once you receive an order number. We may contact you to verify details before dispatch. We reserve the right to refuse orders in cases of suspected fraud or repeated failed deliveries."] },
      { h: "Coupons & Promotions", body: ["Coupons are subject to their stated conditions (minimum order, expiry, usage limits) and cannot be exchanged for cash. One coupon per order."] },
      { h: "Intellectual Property", body: ["All content on this website — branding, text, graphics and layout — belongs to CS Digital Worker and may not be copied without permission."] },
      { h: "Affiliate & Advertising Disclosure", body: ["Some blog articles may contain affiliate links or sponsored content in the future. Where present, they will be clearly disclosed. We only recommend products and services we genuinely believe are useful."] },
      { h: "Limitation of Liability", body: ["Our liability for any claim related to an order is limited to the amount you paid for that order."] },
      { h: "Contact", body: [`Questions about these terms? Contact us at ${CONTACT.email} or WhatsApp ${CONTACT.phone}.`] },
    ],
  },
};

export function generateStaticParams() {
  return Object.keys(POLICIES).map((policy) => ({ policy }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ policy: string }>;
}): Promise<Metadata> {
  const { policy } = await params;
  const page = POLICIES[policy];
  if (!page) return { title: "Page Not Found" };
  return {
    title: page.title,
    description: page.description,
    alternates: { canonical: `/${policy}` },
  };
}

export default async function PolicyPage({
  params,
}: {
  params: Promise<{ policy: string }>;
}) {
  const { policy } = await params;
  const page = POLICIES[policy];
  if (!page) notFound();

  return (
    <div className="container-x py-10 max-w-3xl">
      <Breadcrumbs items={[{ label: page.title }]} />
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900 mb-2">{page.title}</h1>
      <p className="text-slate-500 mb-8">{page.description}</p>
      <div className="prose-custom">
        {page.sections.map((s) => (
          <section key={s.h}>
            <h2>{s.h}</h2>
            {s.body.map((p, i) => <p key={i}>{p}</p>)}
          </section>
        ))}
      </div>
      <p className="mt-10 text-sm text-slate-400">Last updated: January 2025 • CS Digital Worker</p>
    </div>
  );
}
