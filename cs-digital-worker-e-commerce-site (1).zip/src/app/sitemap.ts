import type { MetadataRoute } from "next";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { blogPosts, categories, products } from "@/db/schema";
import { SITE_URL } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const staticPages = [
    "", "/shop", "/categories", "/blog", "/about", "/contact", "/faq", "/reviews",
    "/track-order", "/shipping-policy", "/return-policy", "/privacy-policy", "/terms",
  ].map((path) => ({
    url: `${SITE_URL}${path}`,
    changeFrequency: "weekly" as const,
    priority: path === "" ? 1 : 0.7,
  }));

  try {
    const [prods, cats, posts] = await Promise.all([
      db.select({ slug: products.slug, createdAt: products.createdAt }).from(products).where(eq(products.isActive, true)),
      db.select({ slug: categories.slug }).from(categories).where(eq(categories.isActive, true)),
      db.select({ slug: blogPosts.slug, publishedAt: blogPosts.publishedAt }).from(blogPosts).where(eq(blogPosts.isPublished, true)),
    ]);
    return [
      ...staticPages,
      ...cats.map((c) => ({ url: `${SITE_URL}/category/${c.slug}`, changeFrequency: "weekly" as const, priority: 0.8 })),
      ...prods.map((p) => ({ url: `${SITE_URL}/product/${p.slug}`, lastModified: p.createdAt, changeFrequency: "weekly" as const, priority: 0.9 })),
      ...posts.map((b) => ({ url: `${SITE_URL}/blog/${b.slug}`, lastModified: b.publishedAt, changeFrequency: "monthly" as const, priority: 0.6 })),
    ];
  } catch {
    return staticPages;
  }
}
