import Link from "next/link";

export default function NotFound() {
  return (
    <div className="container-x py-20 text-center">
      <p className="font-display text-8xl font-bold text-brand-800/20" aria-hidden>404</p>
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900 mt-4">Page Not Found</h1>
      <p className="text-slate-500 mt-3 max-w-md mx-auto">
        The page you&apos;re looking for doesn&apos;t exist or may have been moved. Let&apos;s get you back to something beautiful.
      </p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Link href="/" className="btn-primary btn-lg">Go Home</Link>
        <Link href="/shop" className="btn-gold btn-lg">Shop Products</Link>
        <Link href="/search" className="btn-outline btn-lg">Search</Link>
      </div>
    </div>
  );
}
