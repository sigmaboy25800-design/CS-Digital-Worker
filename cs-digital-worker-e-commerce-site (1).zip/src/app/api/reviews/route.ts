import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { products, reviews } from "@/db/schema";
import { getSessionUser, rateLimit } from "@/lib/auth";

export async function POST(req: NextRequest) {
  const user = await getSessionUser();
  if (!user)
    return NextResponse.json({ error: "Please sign in to write a review." }, { status: 401 });
  if (!rateLimit(`review:${user.id}`, 5, 60_000))
    return NextResponse.json({ error: "Too many reviews submitted. Please wait." }, { status: 429 });

  const body = await req.json().catch(() => ({}));
  const productId = Number(body.productId);
  const rating = Math.round(Number(body.rating));
  const title = String(body.title ?? "").trim().slice(0, 100);
  const comment = String(body.comment ?? "").trim().slice(0, 2000);

  if (!productId || Number.isNaN(productId))
    return NextResponse.json({ error: "Invalid product." }, { status: 400 });
  if (rating < 1 || rating > 5)
    return NextResponse.json({ error: "Rating must be between 1 and 5." }, { status: 400 });
  if (comment.length < 5)
    return NextResponse.json({ error: "Please write a short review comment." }, { status: 400 });

  const [product] = await db.select().from(products).where(eq(products.id, productId)).limit(1);
  if (!product) return NextResponse.json({ error: "Product not found." }, { status: 404 });

  await db.insert(reviews).values({
    productId,
    userId: user.id,
    name: user.name,
    rating,
    title: title || null,
    comment,
    status: "pending",
  });

  return NextResponse.json({
    message: "Review submitted for moderation. It will appear once approved.",
  });
}
