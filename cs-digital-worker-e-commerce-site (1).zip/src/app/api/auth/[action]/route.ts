import { NextRequest, NextResponse } from "next/server";
import { randomBytes } from "crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users, type SavedAddress } from "@/db/schema";
import {
  createSession, destroySession, getSessionUser, hashPassword,
  rateLimit, sanitizeUser, verifyPassword,
} from "@/lib/auth";
import { isValidEmail } from "@/lib/utils";

function ip(req: NextRequest) {
  return req.headers.get("x-forwarded-for")?.split(",")[0] ?? "local";
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ action: string }> }
) {
  const { action } = await params;
  if (action === "me") {
    const user = await getSessionUser();
    return NextResponse.json({ user: user ? sanitizeUser(user) : null });
  }
  return NextResponse.json({ error: "Not found" }, { status: 404 });
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ action: string }> }
) {
  const { action } = await params;
  let body: Record<string, unknown> = {};
  try {
    body = await req.json();
  } catch {
    /* empty body ok for logout */
  }

  if (action === "register") {
    if (!rateLimit(`register:${ip(req)}`, 5, 60_000))
      return NextResponse.json({ error: "Too many attempts. Please wait a minute." }, { status: 429 });
    const name = String(body.name ?? "").trim();
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    const phone = String(body.phone ?? "").trim();
    if (name.length < 2) return NextResponse.json({ error: "Please enter your full name." }, { status: 400 });
    if (!isValidEmail(email)) return NextResponse.json({ error: "Please enter a valid email address." }, { status: 400 });
    if (password.length < 8) return NextResponse.json({ error: "Password must be at least 8 characters." }, { status: 400 });
    const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (existing.length > 0)
      return NextResponse.json({ error: "An account with this email already exists. Please sign in." }, { status: 409 });
    const passwordHash = await hashPassword(password);
    const [user] = await db.insert(users).values({ name, email, passwordHash, phone, role: "customer" }).returning();
    await createSession(user.id);
    return NextResponse.json({ user: sanitizeUser(user) });
  }

  if (action === "login") {
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    if (!rateLimit(`login:${ip(req)}:${email}`, 8, 60_000))
      return NextResponse.json({ error: "Too many login attempts. Please wait a minute." }, { status: 429 });
    const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (!user || !(await verifyPassword(password, user.passwordHash)))
      return NextResponse.json({ error: "Invalid email or password." }, { status: 401 });
    await createSession(user.id);
    return NextResponse.json({ user: sanitizeUser(user) });
  }

  if (action === "logout") {
    await destroySession();
    return NextResponse.json({ ok: true });
  }

  if (action === "forgot") {
    if (!rateLimit(`forgot:${ip(req)}`, 5, 60_000))
      return NextResponse.json({ error: "Too many attempts. Please wait a minute." }, { status: 429 });
    const email = String(body.email ?? "").trim().toLowerCase();
    if (!isValidEmail(email)) return NextResponse.json({ error: "Please enter a valid email address." }, { status: 400 });
    const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    let resetUrl: string | undefined;
    if (user) {
      const token = randomBytes(32).toString("hex");
      await db.update(users)
        .set({ resetToken: token, resetTokenExpires: new Date(Date.now() + 60 * 60 * 1000) })
        .where(eq(users.id, user.id));
      // NOTE: No SMTP service is configured in this environment, so the secure
      // one-time reset link is returned directly. Connect an email provider to
      // send this link by email instead.
      resetUrl = `/reset-password?token=${token}`;
    }
    return NextResponse.json({
      message: "If an account exists for this email, a password reset link has been generated.",
      resetUrl,
    });
  }

  if (action === "reset") {
    const token = String(body.token ?? "");
    const password = String(body.password ?? "");
    if (password.length < 8) return NextResponse.json({ error: "Password must be at least 8 characters." }, { status: 400 });
    if (!token) return NextResponse.json({ error: "Invalid reset link." }, { status: 400 });
    const [user] = await db.select().from(users).where(eq(users.resetToken, token)).limit(1);
    if (!user || !user.resetTokenExpires || user.resetTokenExpires < new Date())
      return NextResponse.json({ error: "This reset link is invalid or has expired." }, { status: 400 });
    const passwordHash = await hashPassword(password);
    await db.update(users)
      .set({ passwordHash, resetToken: null, resetTokenExpires: null })
      .where(eq(users.id, user.id));
    return NextResponse.json({ message: "Password updated. You can now sign in." });
  }

  return NextResponse.json({ error: "Not found" }, { status: 404 });
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ action: string }> }
) {
  const { action } = await params;
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Please sign in." }, { status: 401 });
  const body = await req.json().catch(() => ({}));

  if (action === "profile") {
    const name = String(body.name ?? user.name).trim();
    const phone = String(body.phone ?? user.phone ?? "").trim();
    const addresses = Array.isArray(body.addresses)
      ? (body.addresses as SavedAddress[]).slice(0, 10).map((a) => ({
          label: String(a.label ?? "Home").slice(0, 50),
          fullName: String(a.fullName ?? "").slice(0, 100),
          phone: String(a.phone ?? "").slice(0, 30),
          address: String(a.address ?? "").slice(0, 300),
          city: String(a.city ?? "").slice(0, 100),
          postalCode: String(a.postalCode ?? "").slice(0, 20),
          isDefault: Boolean(a.isDefault),
        }))
      : user.addresses ?? [];
    if (name.length < 2) return NextResponse.json({ error: "Name is too short." }, { status: 400 });
    const [updated] = await db.update(users)
      .set({ name, phone, addresses })
      .where(eq(users.id, user.id))
      .returning();
    return NextResponse.json({ user: sanitizeUser(updated) });
  }

  if (action === "password") {
    const current = String(body.current ?? "");
    const next = String(body.next ?? "");
    if (next.length < 8) return NextResponse.json({ error: "New password must be at least 8 characters." }, { status: 400 });
    if (!(await verifyPassword(current, user.passwordHash)))
      return NextResponse.json({ error: "Current password is incorrect." }, { status: 400 });
    await db.update(users).set({ passwordHash: await hashPassword(next) }).where(eq(users.id, user.id));
    return NextResponse.json({ message: "Password changed successfully." });
  }

  return NextResponse.json({ error: "Not found" }, { status: 404 });
}
