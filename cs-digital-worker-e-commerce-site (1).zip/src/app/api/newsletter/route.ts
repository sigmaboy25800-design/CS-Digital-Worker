import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { newsletterSubscribers } from "@/db/schema";
import { rateLimit } from "@/lib/auth";
import { isValidEmail } from "@/lib/utils";

export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0] ?? "local";
  if (!rateLimit(`newsletter:${ip}`, 5, 60_000))
    return NextResponse.json({ error: "Too many attempts. Please try again later." }, { status: 429 });
  const body = await req.json().catch(() => ({}));
  const email = String(body.email ?? "").trim().toLowerCase();
  if (!isValidEmail(email))
    return NextResponse.json({ error: "Please enter a valid email address." }, { status: 400 });
  await db.insert(newsletterSubscribers).values({ email }).onConflictDoNothing();
  return NextResponse.json({ message: "You're subscribed! Watch your inbox for offers and updates." });
}
