import { NextRequest, NextResponse } from "next/server";
import { desc, eq, inArray, sql, and } from "drizzle-orm";
import { db } from "@/db";
import { coupons, orderItems, orders, products } from "@/db/schema";
import { getSessionUser, rateLimit } from "@/lib/auth";
import { validateCoupon, getSettings } from "@/lib/shop";
import { generateOrderNumber, isValidEmail } from "@/lib/utils";

// GET: list my orders, or public tracking with ?orderNumber=&email=
export async function GET(req: NextRequest) {
  const orderNumber = req.nextUrl.searchParams.get("orderNumber");
  const email = req.nextUrl.searchParams.get("email");

  if (orderNumber && email) {
    const [order] = await db
      .select()
      .from(orders)
      .where(and(eq(orders.orderNumber, orderNumber.trim().toUpperCase()), eq(orders.email, email.trim().toLowerCase())))
      .limit(1);
    if (!order) return NextResponse.json({ error: "No order found with that order number and email." }, { status: 404 });
    const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
    return NextResponse.json({ order, items });
  }

  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Please sign in." }, { status: 401 });
  const myOrders = await db
    .select()
    .from(orders)
    .where(eq(orders.userId, user.id))
    .orderBy(desc(orders.createdAt));
  return NextResponse.json({ orders: myOrders });
}

// POST: create order (checkout) — prices validated server-side
export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0] ?? "local";
  if (!rateLimit(`order:${ip}`, 10, 60_000))
    return NextResponse.json({ error: "Too many attempts. Please wait a minute." }, { status: 429 });

  const body = await req.json().catch(() => ({}));
  const rawItems = Array.isArray(body.items) ? body.items : [];
  const c = body.customer ?? {};
  const fullName = String(c.fullName ?? "").trim().slice(0, 100);
  const phone = String(c.phone ?? "").trim().slice(0, 30);
  const email = String(c.email ?? "").trim().toLowerCase().slice(0, 200);
  const address = String(c.address ?? "").trim().slice(0, 300);
  const city = String(c.city ?? "").trim().slice(0, 100);
  const postalCode = String(c.postalCode ?? "").trim().slice(0, 20);
  const notes = String(c.notes ?? "").trim().slice(0, 1000);
  const paymentMethod = body.paymentMethod === "bank_transfer" ? "bank_transfer" : "cod";
  const couponCode = String(body.couponCode ?? "").trim();

  if (rawItems.length === 0) return NextResponse.json({ error: "Your cart is empty." }, { status: 400 });
  if (fullName.length < 2) return NextResponse.json({ error: "Please enter your full name." }, { status: 400 });
  if (phone.length < 7) return NextResponse.json({ error: "Please enter a valid phone number." }, { status: 400 });
  if (!isValidEmail(email)) return NextResponse.json({ error: "Please enter a valid email address." }, { status: 400 });
  if (address.length < 5) return NextResponse.json({ error: "Please enter your complete address." }, { status: 400 });
  if (city.length < 2) return NextResponse.json({ error: "Please enter your city." }, { status: 400 });
  if (!body.termsAccepted) return NextResponse.json({ error: "Please accept the Terms & Conditions." }, { status: 400 });

  const ids = rawItems.map((i: { productId: number }) => Number(i.productId)).filter(Boolean);
  const dbProducts = ids.length ? await db.select().from(products).where(inArray(products.id, ids)) : [];

  const lines: { product: typeof dbProducts[number]; qty: number; size?: string; color?: string }[] = [];
  for (const item of rawItems) {
    const product = dbProducts.find((p) => p.id === Number(item.productId));
    if (!product || !product.isActive)
      return NextResponse.json({ error: "One of the products in your cart is no longer available." }, { status: 400 });
    const qty = Math.max(1, Math.min(50, Number(item.qty) || 1));
    if (product.stock < qty)
      return NextResponse.json({ error: `Only ${product.stock} unit(s) of "${product.name}" are in stock.` }, { status: 400 });
    lines.push({
      product, qty,
      size: item.size ? String(item.size).slice(0, 30) : undefined,
      color: item.color ? String(item.color).slice(0, 30) : undefined,
    });
  }

  const subtotal = lines.reduce((s, l) => s + l.product.price * l.qty, 0);

  // Coupon
  let discount = 0;
  let appliedCoupon: string | null = null;
  if (couponCode) {
    const result = await validateCoupon(
      couponCode,
      lines.map((l) => ({ productId: l.product.id, price: l.product.price, qty: l.qty }))
    );
    if (!result.ok) return NextResponse.json({ error: result.error }, { status: 400 });
    discount = result.discount;
    appliedCoupon = result.code;
  }

  // Shipping
  const settings = await getSettings();
  const flat = Number(settings.shippingFlatRate) || 0;
  const threshold = Number(settings.freeShippingThreshold) || 0;
  const shipping = threshold > 0 && subtotal - discount >= threshold ? 0 : flat;
  const total = subtotal - discount + shipping;

  const user = await getSessionUser();
  const orderNumber = generateOrderNumber();

  const [order] = await db.insert(orders).values({
    orderNumber, userId: user?.id ?? null,
    fullName, phone, email, address, city, postalCode, notes,
    paymentMethod, subtotal, shipping, discount,
    couponCode: appliedCoupon, total, status: "pending",
  }).returning();

  await db.insert(orderItems).values(
    lines.map((l) => ({
      orderId: order.id,
      productId: l.product.id,
      name: l.product.name,
      image: l.product.images?.[0] ?? null,
      size: l.size ?? null,
      color: l.color ?? null,
      price: l.product.price,
      quantity: l.qty,
      total: l.product.price * l.qty,
    }))
  );

  // Update stock & sales counters
  for (const l of lines) {
    await db.update(products)
      .set({
        stock: sql`GREATEST(${products.stock} - ${l.qty}, 0)`,
        salesCount: sql`${products.salesCount} + ${l.qty}`,
      })
      .where(eq(products.id, l.product.id));
  }
  if (appliedCoupon) {
    await db.update(coupons)
      .set({ usedCount: sql`${coupons.usedCount} + 1` })
      .where(eq(coupons.code, appliedCoupon));
  }

  return NextResponse.json({ orderNumber: order.orderNumber, total: order.total });
}
