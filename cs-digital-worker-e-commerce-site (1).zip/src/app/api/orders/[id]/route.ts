import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";

async function findOrder(idOrNumber: string) {
  if (/^\d+$/.test(idOrNumber)) {
    const [order] = await db.select().from(orders).where(eq(orders.id, Number(idOrNumber))).limit(1);
    return order ?? null;
  }
  const [order] = await db.select().from(orders).where(eq(orders.orderNumber, idOrNumber.toUpperCase())).limit(1);
  return order ?? null;
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Please sign in." }, { status: 401 });
  const order = await findOrder(id);
  if (!order) return NextResponse.json({ error: "Order not found." }, { status: 404 });
  if (order.userId !== user.id && user.role !== "admin")
    return NextResponse.json({ error: "Not authorized." }, { status: 403 });
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
  return NextResponse.json({ order, items });
}

// PATCH: request cancellation
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Please sign in." }, { status: 401 });
  const order = await findOrder(id);
  if (!order) return NextResponse.json({ error: "Order not found." }, { status: 404 });
  if (order.userId !== user.id && user.role !== "admin")
    return NextResponse.json({ error: "Not authorized." }, { status: 403 });

  const body = await req.json().catch(() => ({}));
  if (body.action === "cancel") {
    if (!["pending", "confirmed"].includes(order.status))
      return NextResponse.json(
        { error: "This order can no longer be cancelled online. Please contact support on WhatsApp: 03228586255." },
        { status: 400 }
      );
    const [updated] = await db.update(orders)
      .set({ cancelRequested: true, updatedAt: new Date() })
      .where(eq(orders.id, order.id))
      .returning();
    return NextResponse.json({
      order: updated,
      message: "Cancellation requested. Our team will confirm shortly.",
    });
  }
  return NextResponse.json({ error: "Unknown action." }, { status: 400 });
}
