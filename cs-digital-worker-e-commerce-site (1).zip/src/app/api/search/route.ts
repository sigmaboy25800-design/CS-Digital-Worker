import { NextRequest, NextResponse } from "next/server";
import { and, eq, ilike, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { products } from "@/db/schema";

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get("q")?.trim() ?? "";
  if (q.length < 2) return NextResponse.json({ results: [] });
  const term = `%${q}%`;
  const rows = await db
    .select({
      name: products.name,
      slug: products.slug,
      images: products.images,
      price: products.price,
    })
    .from(products)
    .where(
      and(
        eq(products.isActive, true),
        or(
          ilike(products.name, term),
          ilike(products.sku, term),
          sql`${products.tags}::text ILIKE ${term}`
        )
      )
    )
    .limit(6);
  return NextResponse.json({
    results: rows.map((r) => ({
      name: r.name,
      slug: r.slug,
      image: r.images?.[0] ?? "",
      price: r.price,
    })),
  });
}
