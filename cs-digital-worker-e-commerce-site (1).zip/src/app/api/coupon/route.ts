import { NextRequest, NextResponse } from "next/server";
import { validateCoupon } from "@/lib/shop";
import { rateLimit } from "@/lib/auth";

export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0] ?? "local";
  if (!rateLimit(`coupon:${ip}`, 15, 60_000))
    return NextResponse.json({ error: "Too many attempts. Please wait." }, { status: 429 });
  const body = await req.json().catch(() => ({}));
  const code = String(body.code ?? "").trim();
  const items = Array.isArray(body.items)
    ? body.items.map((i: { productId: number; price: number; qty: number }) => ({
        productId: Number(i.productId),
        price: Number(i.price),
        qty: Number(i.qty),
      }))
    : [];
  if (!code) return NextResponse.json({ error: "Please enter a coupon code." }, { status: 400 });
  const result = await validateCoupon(code, items);
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json(result);
}
