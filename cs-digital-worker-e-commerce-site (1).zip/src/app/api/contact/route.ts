import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { contactMessages } from "@/db/schema";
import { rateLimit } from "@/lib/auth";
import { isValidEmail } from "@/lib/utils";

export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0] ?? "local";
  if (!rateLimit(`contact:${ip}`, 5, 60_000))
    return NextResponse.json({ error: "Too many messages. Please try again later." }, { status: 429 });
  const body = await req.json().catch(() => ({}));
  const name = String(body.name ?? "").trim().slice(0, 100);
  const email = String(body.email ?? "").trim().toLowerCase().slice(0, 200);
  const phone = String(body.phone ?? "").trim().slice(0, 30);
  const subject = String(body.subject ?? "").trim().slice(0, 200);
  const message = String(body.message ?? "").trim().slice(0, 3000);
  // Honeypot spam protection
  if (body.website) return NextResponse.json({ message: "Thanks!" });
  if (name.length < 2) return NextResponse.json({ error: "Please enter your name." }, { status: 400 });
  if (!isValidEmail(email)) return NextResponse.json({ error: "Please enter a valid email." }, { status: 400 });
  if (message.length < 10) return NextResponse.json({ error: "Message must be at least 10 characters." }, { status: 400 });
  await db.insert(contactMessages).values({ name, email, phone, subject, message });
  return NextResponse.json({ message: "Message received! Our team will reply within 24 hours." });
}
