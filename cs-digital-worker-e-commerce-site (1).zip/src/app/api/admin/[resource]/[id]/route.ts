import { NextRequest, NextResponse } from "next/server";
import { and, avg, count, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  blogPosts, categories, contactMessages, coupons, orderItems, orders, products, reviews,
} from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { ORDER_STATUSES, slugify } from "@/lib/utils";
import { buildProductValues, buildCategoryValues, buildCouponValues, buildBlogValues } from "@/lib/adminFields";

async function recomputeRating(productId: number) {
  const [agg] = await db
    .select({ avg: avg(reviews.rating), cnt: count() })
    .from(reviews)
    .where(and(eq(reviews.productId, productId), eq(reviews.status, "approved")));
  await db.update(products)
    .set({ ratingAvg: Number(agg?.avg ?? 0), ratingCount: Number(agg?.cnt ?? 0) })
    .where(eq(products.id, productId));
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ resource: string; id: string }> }
) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  const { resource, id } = await params;
  const numId = Number(id);

  if (resource === "orders") {
    const [order] = await db.select().from(orders).where(eq(orders.id, numId)).limit(1);
    if (!order) return NextResponse.json({ error: "Not found." }, { status: 404 });
    const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
    return NextResponse.json({ order, items });
  }
  return NextResponse.json({ error: "Not found." }, { status: 404 });
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ resource: string; id: string }> }
) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  const { resource, id } = await params;
  const numId = Number(id);
  if (!Number.isFinite(numId)) return NextResponse.json({ error: "Invalid id." }, { status: 400 });
  const body = await req.json().catch(() => ({}));

  try {
    switch (resource) {
      case "products": {
        const values = buildProductValues(body);
        if (!values.slug && values.name) values.slug = slugify(values.name);
        const [row] = await db.update(products).set(values).where(eq(products.id, numId)).returning();
        return NextResponse.json({ row });
      }
      case "categories": {
        const values = buildCategoryValues(body);
        if (!values.slug && values.name) values.slug = slugify(values.name);
        const [row] = await db.update(categories).set(values).where(eq(categories.id, numId)).returning();
        return NextResponse.json({ row });
      }
      case "coupons": {
        const values = buildCouponValues(body);
        const [row] = await db.update(coupons).set(values).where(eq(coupons.id, numId)).returning();
        return NextResponse.json({ row });
      }
      case "blog": {
        const values = buildBlogValues(body);
        if (!values.slug && values.title) values.slug = slugify(values.title);
        const [row] = await db.update(blogPosts).set(values).where(eq(blogPosts.id, numId)).returning();
        return NextResponse.json({ row });
      }
      case "reviews": {
        const status = String(body.status ?? "");
        if (!["pending", "approved", "rejected"].includes(status))
          return NextResponse.json({ error: "Invalid status." }, { status: 400 });
        const [row] = await db.update(reviews).set({ status }).where(eq(reviews.id, numId)).returning();
        if (row) await recomputeRating(row.productId);
        return NextResponse.json({ row });
      }
      case "orders": {
        const update: Partial<typeof orders.$inferInsert> = { updatedAt: new Date() };
        if (body.status !== undefined) {
          const status = String(body.status);
          if (!(ORDER_STATUSES as readonly string[]).includes(status))
            return NextResponse.json({ error: "Invalid status." }, { status: 400 });
          update.status = status;
          if (["cancelled", "returned"].includes(status)) update.cancelRequested = false;
        }
        const [row] = await db.update(orders).set(update).where(eq(orders.id, numId)).returning();
        return NextResponse.json({ row });
      }
      case "messages": {
        const [row] = await db.update(contactMessages)
          .set({ status: String(body.status ?? "read").slice(0, 20) })
          .where(eq(contactMessages.id, numId)).returning();
        return NextResponse.json({ row });
      }
      default:
        return NextResponse.json({ error: "Cannot update this resource." }, { status: 400 });
    }
  } catch {
    return NextResponse.json({ error: "Could not save. Check for duplicate slug/code." }, { status: 400 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ resource: string; id: string }> }
) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  const { resource, id } = await params;
  const numId = Number(id);

  switch (resource) {
    case "products":
      await db.delete(products).where(eq(products.id, numId));
      return NextResponse.json({ ok: true });
    case "categories":
      await db.delete(categories).where(eq(categories.id, numId));
      return NextResponse.json({ ok: true });
    case "coupons":
      await db.delete(coupons).where(eq(coupons.id, numId));
      return NextResponse.json({ ok: true });
    case "blog":
      await db.delete(blogPosts).where(eq(blogPosts.id, numId));
      return NextResponse.json({ ok: true });
    case "reviews": {
      const [row] = await db.delete(reviews).where(eq(reviews.id, numId)).returning();
      if (row) await recomputeRating(row.productId);
      return NextResponse.json({ ok: true });
    }
    case "messages":
      await db.delete(contactMessages).where(eq(contactMessages.id, numId));
      return NextResponse.json({ ok: true });
    default:
      return NextResponse.json({ error: "Cannot delete this resource." }, { status: 400 });
  }
}
