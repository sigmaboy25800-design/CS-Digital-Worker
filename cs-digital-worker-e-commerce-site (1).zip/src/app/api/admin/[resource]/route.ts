import { NextRequest, NextResponse } from "next/server";
import { desc, asc, eq, ilike, or, sql, and, lte } from "drizzle-orm";
import { db } from "@/db";
import {
  blogPosts, categories, contactMessages, coupons, newsletterSubscribers,
  orders, products, reviews, settings, users,
} from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { slugify } from "@/lib/utils";
import { buildProductValues, buildCategoryValues, buildCouponValues, buildBlogValues } from "@/lib/adminFields";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ resource: string }> }
) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  const { resource } = await params;
  const search = req.nextUrl.searchParams.get("search")?.trim();
  const status = req.nextUrl.searchParams.get("status")?.trim();

  switch (resource) {
    case "stats": {
      const [revenue] = await db.select({ v: sql<number>`COALESCE(SUM(total),0)::int` }).from(orders).where(sql`status NOT IN ('cancelled','returned')`);
      const [orderCount] = await db.select({ v: sql<number>`count(*)::int` }).from(orders);
      const [pendingCount] = await db.select({ v: sql<number>`count(*)::int` }).from(orders).where(eq(orders.status, "pending"));
      const [customerCount] = await db.select({ v: sql<number>`count(*)::int` }).from(users).where(eq(users.role, "customer"));
      const [productCount] = await db.select({ v: sql<number>`count(*)::int` }).from(products);
      const [lowStock] = await db.select({ v: sql<number>`count(*)::int` }).from(products).where(and(lte(products.stock, 5), sql`stock > 0`));
      const [outStock] = await db.select({ v: sql<number>`count(*)::int` }).from(products).where(eq(products.stock, 0));
      const [pendingReviews] = await db.select({ v: sql<number>`count(*)::int` }).from(reviews).where(eq(reviews.status, "pending"));
      const recentOrders = await db.select().from(orders).orderBy(desc(orders.createdAt)).limit(8);
      const bestSellers = await db.select().from(products).orderBy(desc(products.salesCount)).limit(5);
      return NextResponse.json({
        revenue: revenue.v, orders: orderCount.v, pendingOrders: pendingCount.v,
        customers: customerCount.v, products: productCount.v,
        lowStock: lowStock.v, outOfStock: outStock.v, pendingReviews: pendingReviews.v,
        recentOrders, bestSellers,
      });
    }
    case "products": {
      const where = search
        ? or(ilike(products.name, `%${search}%`), ilike(products.sku, `%${search}%`))
        : undefined;
      const rows = await db.select().from(products).where(where).orderBy(desc(products.createdAt)).limit(200);
      return NextResponse.json({ rows });
    }
    case "categories": {
      const rows = await db.select().from(categories).orderBy(asc(categories.sortOrder));
      return NextResponse.json({ rows });
    }
    case "coupons": {
      const rows = await db.select().from(coupons).orderBy(desc(coupons.createdAt));
      return NextResponse.json({ rows });
    }
    case "blog": {
      const rows = await db.select().from(blogPosts).orderBy(desc(blogPosts.publishedAt));
      return NextResponse.json({ rows });
    }
    case "reviews": {
      const where = status ? eq(reviews.status, status) : undefined;
      const rows = await db
        .select({ review: reviews, productName: products.name })
        .from(reviews)
        .innerJoin(products, eq(reviews.productId, products.id))
        .where(where)
        .orderBy(desc(reviews.createdAt))
        .limit(200);
      return NextResponse.json({ rows: rows.map((r) => ({ ...r.review, productName: r.productName })) });
    }
    case "orders": {
      const conditions = [];
      if (status) conditions.push(eq(orders.status, status));
      if (search)
        conditions.push(
          or(
            ilike(orders.orderNumber, `%${search}%`),
            ilike(orders.fullName, `%${search}%`),
            ilike(orders.email, `%${search}%`),
            ilike(orders.phone, `%${search}%`)
          )
        );
      const rows = await db.select().from(orders)
        .where(conditions.length ? and(...conditions) : undefined)
        .orderBy(desc(orders.createdAt)).limit(200);
      return NextResponse.json({ rows });
    }
    case "customers": {
      const where = search
        ? and(eq(users.role, "customer"), or(ilike(users.name, `%${search}%`), ilike(users.email, `%${search}%`)))
        : eq(users.role, "customer");
      const rows = await db
        .select({
          id: users.id, name: users.name, email: users.email, phone: users.phone,
          createdAt: users.createdAt,
          orderCount: sql<number>`(SELECT count(*)::int FROM orders o WHERE o.user_id = ${users.id})`,
          totalSpent: sql<number>`(SELECT COALESCE(SUM(o.total),0)::int FROM orders o WHERE o.user_id = ${users.id} AND o.status NOT IN ('cancelled','returned'))`,
        })
        .from(users)
        .where(where)
        .orderBy(desc(users.createdAt))
        .limit(200);
      return NextResponse.json({ rows });
    }
    case "messages": {
      const rows = await db.select().from(contactMessages).orderBy(desc(contactMessages.createdAt)).limit(200);
      return NextResponse.json({ rows });
    }
    case "subscribers": {
      const rows = await db.select().from(newsletterSubscribers).orderBy(desc(newsletterSubscribers.createdAt)).limit(500);
      return NextResponse.json({ rows });
    }
    case "settings": {
      const rows = await db.select().from(settings);
      const map: Record<string, string> = {};
      for (const r of rows) map[r.key] = r.value;
      return NextResponse.json({ settings: map });
    }
    default:
      return NextResponse.json({ error: "Unknown resource." }, { status: 404 });
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ resource: string }> }
) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  const { resource } = await params;
  const body = await req.json().catch(() => ({}));

  try {
    switch (resource) {
      case "products": {
        const values = buildProductValues(body);
        if (!values.name || !values.price)
          return NextResponse.json({ error: "Name and price are required." }, { status: 400 });
        if (!values.slug) values.slug = slugify(values.name);
        const [row] = await db.insert(products).values(values as typeof products.$inferInsert).returning();
        return NextResponse.json({ row });
      }
      case "categories": {
        const values = buildCategoryValues(body);
        if (!values.name) return NextResponse.json({ error: "Name is required." }, { status: 400 });
        if (!values.slug) values.slug = slugify(values.name);
        const [row] = await db.insert(categories).values(values as typeof categories.$inferInsert).returning();
        return NextResponse.json({ row });
      }
      case "coupons": {
        const values = buildCouponValues(body);
        if (!values.code || !values.value)
          return NextResponse.json({ error: "Code and value are required." }, { status: 400 });
        const [row] = await db.insert(coupons).values(values as typeof coupons.$inferInsert).returning();
        return NextResponse.json({ row });
      }
      case "blog": {
        const values = buildBlogValues(body);
        if (!values.title || !values.content)
          return NextResponse.json({ error: "Title and content are required." }, { status: 400 });
        if (!values.slug) values.slug = slugify(values.title);
        const [row] = await db.insert(blogPosts).values(values as typeof blogPosts.$inferInsert).returning();
        return NextResponse.json({ row });
      }
      case "settings": {
        const entries = Object.entries(body as Record<string, unknown>).slice(0, 100);
        for (const [key, value] of entries) {
          await db.insert(settings)
            .values({ key: String(key).slice(0, 100), value: String(value ?? "").slice(0, 5000) })
            .onConflictDoUpdate({ target: settings.key, set: { value: String(value ?? "").slice(0, 5000) } });
        }
        return NextResponse.json({ ok: true });
      }
      default:
        return NextResponse.json({ error: "Cannot create this resource." }, { status: 400 });
    }
  } catch (e) {
    const msg = e instanceof Error && e.message.includes("duplicate")
      ? "A record with this slug/code already exists."
      : "Could not save. Please check the fields.";
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
