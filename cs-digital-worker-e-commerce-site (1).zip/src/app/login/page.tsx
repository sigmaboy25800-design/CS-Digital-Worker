"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Spinner } from "@/components/ui";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (res.ok) {
        router.push(data.user.role === "admin" ? "/admin" : "/account");
        router.refresh();
      } else {
        setError(data.error);
        setLoading(false);
      }
    } catch {
      setError("Network error. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div className="container-x py-14 max-w-md">
      <h1 className="font-display text-3xl font-bold text-slate-900 text-center">Welcome Back</h1>
      <p className="text-slate-500 text-center mt-2 mb-8">Sign in to your CS Digital Worker account</p>
      <form onSubmit={submit} className="card p-6 space-y-4">
        <div>
          <label htmlFor="email" className="label">Email</label>
          <input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="input" autoComplete="email" />
        </div>
        <div>
          <label htmlFor="password" className="label">Password</label>
          <input id="password" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} className="input" autoComplete="current-password" />
        </div>
        {error && <p className="text-sm text-rose-600 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2" role="alert">{error}</p>}
        <button type="submit" disabled={loading} className="btn-primary btn-lg w-full">
          {loading ? <Spinner /> : "Sign In"}
        </button>
        <div className="flex justify-between text-sm">
          <Link href="/forgot-password" className="text-brand-700 hover:underline">Forgot password?</Link>
          <Link href="/signup" className="text-brand-700 hover:underline font-semibold">Create account</Link>
        </div>
      </form>
      <p className="mt-6 text-xs text-slate-400 text-center">
        Demo admin access: <code className="bg-slate-100 px-1 rounded">sigmaboy25800@gmail.com</code> / <code className="bg-slate-100 px-1 rounded">Admin@12345</code> — change this password from your account after first login.
      </p>
    </div>
  );
}
