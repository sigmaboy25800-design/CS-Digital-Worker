import type { Metadata } from "next";
import { Breadcrumbs } from "@/components/ui";
import { CONTACT } from "@/lib/utils";

export const metadata: Metadata = {
  title: "FAQ — Frequently Asked Questions",
  description: "Answers to common questions about ordering, delivery, payments, returns and account management at CS Digital Worker.",
  alternates: { canonical: "/faq" },
};

const FAQS = [
  { q: "How do I place an order?", a: "Browse our shop, add products to your cart, then proceed to checkout. Fill in your delivery details, choose Cash on Delivery or Bank Transfer, and confirm. You'll instantly receive an order number to track your order." },
  { q: "What payment methods do you accept?", a: "We currently accept Cash on Delivery (COD) nationwide and direct Bank Transfer. Online card payments are coming soon. We never store payment card details." },
  { q: "How long does delivery take?", a: "Orders are typically delivered within 3–7 working days across Pakistan. You can track your order anytime using your order number and email on the Track Order page." },
  { q: "How much is shipping?", a: "Shipping is a flat Rs. 250. Orders of Rs. 5,000 or more ship completely free." },
  { q: "Can I cancel or change my order?", a: "Yes — you can request cancellation from your account while your order is Pending or Confirmed. After it ships, contact us on WhatsApp and we'll do our best to help." },
  { q: "What is your return policy?", a: "We accept returns of unused, unwashed items with original packaging within 7 days of delivery. See our Return & Refund Policy page for full details." },
  { q: "Do I need an account to shop?", a: "No — guest checkout is fully supported. However, an account lets you track orders, save addresses, manage a wishlist and write reviews." },
  { q: "How do I use a coupon code?", a: "Enter your coupon code in the cart page and click Apply. The discount is applied instantly and carried through checkout. Each coupon shows its own minimum-order requirements." },
  { q: "Are the product photos real?", a: "We only publish genuine product imagery and honest descriptions. If anything ever falls short of what you expected, our return policy has you covered." },
  { q: "How can I contact support?", a: `The fastest way is WhatsApp at ${CONTACT.phone}. You can also call the same number or email ${CONTACT.email} — we reply within 24 hours.` },
];

export default function FAQPage() {
  const schema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: FAQS.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: { "@type": "Answer", text: f.a },
    })),
  };

  return (
    <div className="container-x py-10 max-w-3xl">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      <Breadcrumbs items={[{ label: "FAQ" }]} />
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900">Frequently Asked Questions</h1>
      <p className="text-slate-500 mt-2 mb-8">Everything you need to know about shopping with CS Digital Worker.</p>
      <div className="space-y-3">
        {FAQS.map((f) => (
          <details key={f.q} className="card p-5 group">
            <summary className="font-bold text-slate-900 cursor-pointer list-none flex justify-between items-center gap-3">
              {f.q}
              <span className="text-brand-700 transition-transform group-open:rotate-45 text-xl leading-none" aria-hidden>+</span>
            </summary>
            <p className="text-slate-600 text-sm mt-3 leading-relaxed">{f.a}</p>
          </details>
        ))}
      </div>
      <div className="mt-10 card p-6 text-center">
        <p className="font-bold text-slate-900 mb-2">Still have questions?</p>
        <div className="flex flex-wrap justify-center gap-3">
          <a href={CONTACT.whatsappHref} target="_blank" rel="noopener noreferrer" className="btn btn-md bg-emerald-500 text-white hover:bg-emerald-600">WhatsApp Us</a>
          <a href={CONTACT.phoneHref} className="btn-primary btn-md">Call {CONTACT.phone}</a>
          <a href={CONTACT.emailHref} className="btn-outline btn-md">Email Us</a>
        </div>
      </div>
    </div>
  );
}
