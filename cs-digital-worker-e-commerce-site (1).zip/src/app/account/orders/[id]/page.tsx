"use client";

import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Spinner } from "@/components/ui";
import { CONTACT, formatDate, formatPrice, STATUS_COLORS, STATUS_LABELS } from "@/lib/utils";
import type { Order, OrderItem } from "@/db/schema";

export default function AccountOrderPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [data, setData] = useState<{ order: Order; items: OrderItem[] } | null>(null);
  const [error, setError] = useState("");
  const [cancelConfirm, setCancelConfirm] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetch(`/api/orders/${id}`)
      .then(async (r) => {
        const d = await r.json();
        if (r.status === 401) { router.push("/login"); return; }
        if (r.ok) setData(d);
        else setError(d.error);
      })
      .catch(() => setError("Could not load order."));
  }, [id, router]);

  const requestCancel = async () => {
    setCancelling(true);
    const res = await fetch(`/api/orders/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "cancel" }),
    });
    const d = await res.json();
    setCancelling(false);
    setCancelConfirm(false);
    if (res.ok) { setData((prev) => (prev ? { ...prev, order: d.order } : prev)); setMessage(d.message); }
    else setError(d.error);
  };

  if (error && !data) {
    return <div className="container-x py-16 text-center text-rose-600">{error}</div>;
  }
  if (!data) {
    return <div className="container-x py-16 flex justify-center"><Spinner className="h-8 w-8 text-brand-700" /></div>;
  }

  const { order, items } = data;
  const canCancel = ["pending", "confirmed"].includes(order.status) && !order.cancelRequested;

  return (
    <div className="container-x py-8 max-w-3xl">
      <Link href="/account" className="text-sm text-brand-700 hover:underline">← Back to My Account</Link>
      <div className="flex flex-wrap items-center justify-between gap-3 mt-3 mb-6">
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900">Order {order.orderNumber}</h1>
        <span className={`px-3 py-1 rounded-full text-sm font-bold ${STATUS_COLORS[order.status]}`}>{STATUS_LABELS[order.status]}</span>
      </div>

      {message && <p className="mb-4 text-sm text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg p-3">{message}</p>}
      {error && <p className="mb-4 text-sm text-rose-600 bg-rose-50 border border-rose-200 rounded-lg p-3">{error}</p>}
      {order.cancelRequested && (
        <p className="mb-4 text-sm text-amber-800 bg-amber-50 border border-amber-200 rounded-lg p-3">A cancellation request is pending review by our team.</p>
      )}

      <div className="card p-6">
        <p className="text-sm text-slate-500">Placed on {formatDate(order.createdAt)} • Payment: {order.paymentMethod === "cod" ? "Cash on Delivery" : "Bank Transfer"}</p>
        <ul className="divide-y divide-slate-100 mt-4">
          {items.map((item) => (
            <li key={item.id} className="py-3 flex gap-3 items-center">
              {item.image && (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={item.image} alt={item.name} className="h-14 w-11 object-cover rounded" />
              )}
              <div className="flex-1">
                <p className="text-sm font-semibold text-slate-800">{item.name}</p>
                <p className="text-xs text-slate-400">{[item.size, item.color].filter(Boolean).join(" / ")} × {item.quantity}</p>
              </div>
              <span className="text-sm font-bold">{formatPrice(item.total)}</span>
            </li>
          ))}
        </ul>
        <dl className="mt-4 space-y-1.5 text-sm border-t border-slate-100 pt-4">
          <div className="flex justify-between"><dt className="text-slate-500">Subtotal</dt><dd>{formatPrice(order.subtotal)}</dd></div>
          {order.discount > 0 && <div className="flex justify-between text-emerald-600"><dt>Discount</dt><dd>−{formatPrice(order.discount)}</dd></div>}
          <div className="flex justify-between"><dt className="text-slate-500">Shipping</dt><dd>{order.shipping === 0 ? "Free" : formatPrice(order.shipping)}</dd></div>
          <div className="flex justify-between font-bold text-base pt-1"><dt>Total</dt><dd className="text-brand-800">{formatPrice(order.total)}</dd></div>
        </dl>
        <div className="mt-5 bg-slate-50 rounded-lg p-4 text-sm">
          <p className="font-semibold text-slate-800 mb-1">Delivery Address</p>
          <p className="text-slate-600">{order.fullName} • {order.phone}</p>
          <p className="text-slate-600">{order.address}, {order.city} {order.postalCode}</p>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap gap-3">
        <Link href={`/track-order?orderNumber=${order.orderNumber}&email=${encodeURIComponent(order.email)}`} className="btn-primary btn-md">Track Order</Link>
        {canCancel && (
          <button onClick={() => setCancelConfirm(true)} className="btn-danger btn-md">Request Cancellation</button>
        )}
        <a href={CONTACT.whatsappHref} target="_blank" rel="noopener noreferrer" className="btn btn-md bg-emerald-500 text-white hover:bg-emerald-600">Contact Support</a>
      </div>

      {cancelConfirm && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-label="Confirm cancellation">
          <div className="absolute inset-0 bg-black/60" onClick={() => setCancelConfirm(false)} />
          <div className="relative bg-white rounded-2xl p-6 max-w-sm w-full shadow-2xl">
            <h2 className="font-display text-xl font-bold text-slate-900">Cancel this order?</h2>
            <p className="text-sm text-slate-500 mt-2">We&apos;ll submit a cancellation request for order {order.orderNumber}. Our team will confirm it shortly.</p>
            <div className="mt-5 flex gap-3">
              <button onClick={requestCancel} disabled={cancelling} className="btn-danger btn-md flex-1">
                {cancelling ? <Spinner className="h-4 w-4" /> : "Yes, Request Cancel"}
              </button>
              <button onClick={() => setCancelConfirm(false)} className="btn-outline btn-md flex-1">Keep Order</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
