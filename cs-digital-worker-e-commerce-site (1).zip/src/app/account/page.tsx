"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useStore } from "@/components/Providers";
import { Spinner, EmptyState } from "@/components/ui";
import { formatDate, formatPrice, STATUS_COLORS, STATUS_LABELS } from "@/lib/utils";
import type { Order, SavedAddress } from "@/db/schema";

type UserData = {
  id: number; name: string; email: string; phone: string | null;
  role: string; addresses: SavedAddress[];
};

const TABS = ["Dashboard", "Orders", "Addresses", "Profile", "Password"] as const;

export default function AccountPage() {
  const router = useRouter();
  const { wishlist, toast } = useStore();
  const [user, setUser] = useState<UserData | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<(typeof TABS)[number]>("Dashboard");

  useEffect(() => {
    Promise.all([
      fetch("/api/auth/me").then((r) => r.json()),
      fetch("/api/orders").then((r) => (r.ok ? r.json() : { orders: [] })),
    ])
      .then(([me, ord]) => {
        if (!me.user) {
          router.push("/login");
          return;
        }
        setUser(me.user);
        setOrders(ord.orders ?? []);
        setLoading(false);
      })
      .catch(() => router.push("/login"));
  }, [router]);

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  };

  if (loading || !user) {
    return <div className="container-x py-16 flex justify-center"><Spinner className="h-8 w-8 text-brand-700" /></div>;
  }

  const pending = orders.filter((o) => !["delivered", "cancelled", "returned"].includes(o.status)).length;
  const completed = orders.filter((o) => o.status === "delivered").length;

  return (
    <div className="container-x py-8">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h1 className="font-display text-3xl font-bold text-slate-900">My Account</h1>
          <p className="text-slate-500 mt-1">Welcome back, {user.name.split(" ")[0]}!</p>
        </div>
        <div className="flex gap-2">
          {user.role === "admin" && <Link href="/admin" className="btn-gold btn-md">Admin Dashboard</Link>}
          <button onClick={logout} className="btn-outline btn-md">Logout</button>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-2 mb-6" role="tablist" aria-label="Account sections">
        {TABS.map((t) => (
          <button
            key={t}
            role="tab"
            aria-selected={tab === t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold whitespace-nowrap ${tab === t ? "bg-brand-800 text-white" : "bg-white border border-slate-200 text-slate-600 hover:border-brand-600"}`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === "Dashboard" && (
        <div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {[
              { label: "Total Orders", value: orders.length, icon: "📦" },
              { label: "Pending Orders", value: pending, icon: "⏳" },
              { label: "Completed Orders", value: completed, icon: "✅" },
              { label: "Wishlist Items", value: wishlist.length, icon: "❤️" },
            ].map((s) => (
              <div key={s.label} className="card p-5">
                <p className="text-2xl" aria-hidden>{s.icon}</p>
                <p className="text-3xl font-bold text-slate-900 mt-2">{s.value}</p>
                <p className="text-sm text-slate-500">{s.label}</p>
              </div>
            ))}
          </div>
          <h2 className="font-display text-xl font-bold text-slate-900 mb-3">Recent Orders</h2>
          {orders.length === 0 ? (
            <div className="card p-6 text-center text-slate-500 text-sm">
              No orders yet. <Link href="/shop" className="text-brand-700 font-semibold hover:underline">Start shopping →</Link>
            </div>
          ) : (
            <OrderTable orders={orders.slice(0, 5)} />
          )}
        </div>
      )}

      {tab === "Orders" && (
        orders.length === 0 ? (
          <EmptyState icon="📦" title="No orders yet" text="When you place an order it will appear here with live status tracking.">
            <Link href="/shop" className="btn-primary btn-md">Shop Products</Link>
          </EmptyState>
        ) : (
          <OrderTable orders={orders} />
        )
      )}

      {tab === "Addresses" && <AddressManager user={user} onUpdate={setUser} toast={toast} />}
      {tab === "Profile" && <ProfileForm user={user} onUpdate={setUser} toast={toast} />}
      {tab === "Password" && <PasswordForm toast={toast} />}
    </div>
  );
}

function OrderTable({ orders }: { orders: Order[] }) {
  return (
    <div className="card overflow-x-auto">
      <table className="w-full text-sm min-w-[600px]">
        <thead>
          <tr className="border-b border-slate-100 text-left text-xs uppercase tracking-wide text-slate-400">
            <th className="px-4 py-3">Order</th>
            <th className="px-4 py-3">Date</th>
            <th className="px-4 py-3">Status</th>
            <th className="px-4 py-3">Total</th>
            <th className="px-4 py-3"></th>
          </tr>
        </thead>
        <tbody>
          {orders.map((o) => (
            <tr key={o.id} className="border-b border-slate-50 hover:bg-slate-50">
              <td className="px-4 py-3 font-semibold text-slate-800">{o.orderNumber}</td>
              <td className="px-4 py-3 text-slate-500">{formatDate(o.createdAt)}</td>
              <td className="px-4 py-3">
                <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-bold ${STATUS_COLORS[o.status]}`}>
                  {STATUS_LABELS[o.status]}
                </span>
                {o.cancelRequested && <span className="ml-1 text-xs text-amber-600">(cancel requested)</span>}
              </td>
              <td className="px-4 py-3 font-bold text-brand-800">{formatPrice(o.total)}</td>
              <td className="px-4 py-3">
                <Link href={`/account/orders/${o.id}`} className="text-brand-700 font-semibold hover:underline">View</Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function ProfileForm({ user, onUpdate, toast }: { user: UserData; onUpdate: (u: UserData) => void; toast: (m: string, t?: "success" | "error" | "info") => void }) {
  const [name, setName] = useState(user.name);
  const [phone, setPhone] = useState(user.phone ?? "");
  const [saving, setSaving] = useState(false);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const res = await fetch("/api/auth/profile", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, phone, addresses: user.addresses }),
    });
    const data = await res.json();
    setSaving(false);
    if (res.ok) { onUpdate(data.user); toast("Profile updated"); }
    else toast(data.error, "error");
  };

  return (
    <form onSubmit={save} className="card p-6 max-w-lg space-y-4">
      <div>
        <label htmlFor="p-name" className="label">Full Name</label>
        <input id="p-name" value={name} onChange={(e) => setName(e.target.value)} className="input" required />
      </div>
      <div>
        <label className="label">Email</label>
        <input value={user.email} disabled className="input bg-slate-50 text-slate-400" />
        <p className="text-xs text-slate-400 mt-1">Email cannot be changed. Contact support if needed.</p>
      </div>
      <div>
        <label htmlFor="p-phone" className="label">Phone</label>
        <input id="p-phone" value={phone} onChange={(e) => setPhone(e.target.value)} className="input" />
      </div>
      <button type="submit" disabled={saving} className="btn-primary btn-md">{saving ? <Spinner className="h-4 w-4" /> : "Save Changes"}</button>
    </form>
  );
}

function PasswordForm({ toast }: { toast: (m: string, t?: "success" | "error" | "info") => void }) {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [saving, setSaving] = useState(false);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (next !== confirm) { toast("New passwords do not match", "error"); return; }
    setSaving(true);
    const res = await fetch("/api/auth/password", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ current, next }),
    });
    const data = await res.json();
    setSaving(false);
    if (res.ok) { toast(data.message); setCurrent(""); setNext(""); setConfirm(""); }
    else toast(data.error, "error");
  };

  return (
    <form onSubmit={save} className="card p-6 max-w-lg space-y-4">
      <div>
        <label htmlFor="pw-cur" className="label">Current Password</label>
        <input id="pw-cur" type="password" required value={current} onChange={(e) => setCurrent(e.target.value)} className="input" autoComplete="current-password" />
      </div>
      <div>
        <label htmlFor="pw-new" className="label">New Password (min 8 characters)</label>
        <input id="pw-new" type="password" required minLength={8} value={next} onChange={(e) => setNext(e.target.value)} className="input" autoComplete="new-password" />
      </div>
      <div>
        <label htmlFor="pw-con" className="label">Confirm New Password</label>
        <input id="pw-con" type="password" required value={confirm} onChange={(e) => setConfirm(e.target.value)} className="input" autoComplete="new-password" />
      </div>
      <button type="submit" disabled={saving} className="btn-primary btn-md">{saving ? <Spinner className="h-4 w-4" /> : "Change Password"}</button>
    </form>
  );
}

function AddressManager({ user, onUpdate, toast }: { user: UserData; onUpdate: (u: UserData) => void; toast: (m: string, t?: "success" | "error" | "info") => void }) {
  const [form, setForm] = useState<SavedAddress>({ label: "Home", fullName: user.name, phone: user.phone ?? "", address: "", city: "", postalCode: "", isDefault: user.addresses.length === 0 });
  const [saving, setSaving] = useState(false);

  const persist = async (addresses: SavedAddress[]) => {
    setSaving(true);
    const res = await fetch("/api/auth/profile", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: user.name, phone: user.phone, addresses }),
    });
    const data = await res.json();
    setSaving(false);
    if (res.ok) { onUpdate(data.user); toast("Addresses updated"); }
    else toast(data.error, "error");
  };

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    const next = form.isDefault
      ? [...user.addresses.map((a) => ({ ...a, isDefault: false })), form]
      : [...user.addresses, form];
    await persist(next);
    setForm({ label: "Home", fullName: user.name, phone: user.phone ?? "", address: "", city: "", postalCode: "", isDefault: false });
  };

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <div className="space-y-3">
        <h2 className="font-display text-xl font-bold text-slate-900">Saved Addresses</h2>
        {user.addresses.length === 0 && <p className="text-sm text-slate-500 card p-5">No saved addresses yet. Add one to speed up checkout.</p>}
        {user.addresses.map((a, i) => (
          <div key={i} className="card p-5">
            <div className="flex justify-between items-start gap-2">
              <p className="font-bold text-slate-900">{a.label} {a.isDefault && <span className="text-xs font-semibold text-brand-700 bg-brand-50 rounded px-1.5 py-0.5 ml-1">Default</span>}</p>
              <div className="flex gap-2 text-xs">
                {!a.isDefault && (
                  <button onClick={() => persist(user.addresses.map((x, xi) => ({ ...x, isDefault: xi === i })))} className="text-brand-700 underline">Make default</button>
                )}
                <button onClick={() => persist(user.addresses.filter((_, xi) => xi !== i))} className="text-rose-500 underline">Delete</button>
              </div>
            </div>
            <p className="text-sm text-slate-600 mt-1">{a.fullName} • {a.phone}</p>
            <p className="text-sm text-slate-600">{a.address}, {a.city} {a.postalCode}</p>
          </div>
        ))}
      </div>
      <form onSubmit={add} className="card p-6 space-y-3 h-fit">
        <h2 className="font-display text-xl font-bold text-slate-900">Add New Address</h2>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label" htmlFor="a-label">Label</label>
            <input id="a-label" value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} className="input" placeholder="Home / Office" required />
          </div>
          <div>
            <label className="label" htmlFor="a-name">Full Name</label>
            <input id="a-name" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} className="input" required />
          </div>
        </div>
        <div>
          <label className="label" htmlFor="a-phone">Phone</label>
          <input id="a-phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="input" required />
        </div>
        <div>
          <label className="label" htmlFor="a-addr">Complete Address</label>
          <textarea id="a-addr" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="input" rows={2} required />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label" htmlFor="a-city">City</label>
            <input id="a-city" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="input" required />
          </div>
          <div>
            <label className="label" htmlFor="a-postal">Postal Code</label>
            <input id="a-postal" value={form.postalCode} onChange={(e) => setForm({ ...form, postalCode: e.target.value })} className="input" />
          </div>
        </div>
        <label className="flex items-center gap-2 text-sm text-slate-600">
          <input type="checkbox" checked={form.isDefault} onChange={(e) => setForm({ ...form, isDefault: e.target.checked })} className="accent-brand-700" />
          Set as default address
        </label>
        <button type="submit" disabled={saving} className="btn-primary btn-md w-full">{saving ? <Spinner className="h-4 w-4" /> : "Save Address"}</button>
      </form>
    </div>
  );
}
