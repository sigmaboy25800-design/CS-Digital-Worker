"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useStore, lineKey } from "@/components/Providers";
import { EmptyState, Spinner } from "@/components/ui";
import { formatPrice } from "@/lib/utils";

export default function CartPage() {
  const { cart, saved, hydrated, updateQty, removeFromCart, saveForLater, moveToCart, removeSaved, cartSubtotal, toast } = useStore();
  const [couponCode, setCouponCode] = useState("");
  const [coupon, setCoupon] = useState<{ code: string; discount: number; description: string } | null>(null);
  const [couponError, setCouponError] = useState("");
  const [applying, setApplying] = useState(false);

  useEffect(() => {
    try {
      const stored = sessionStorage.getItem("csdw_coupon");
      if (stored) setCoupon(JSON.parse(stored));
    } catch { /* ignore */ }
  }, []);

  // Re-validate stored coupon whenever cart changes
  useEffect(() => {
    if (!hydrated || !coupon) return;
    if (cart.length === 0) {
      setCoupon(null);
      sessionStorage.removeItem("csdw_coupon");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cart.length, hydrated]);

  const applyCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    setApplying(true);
    setCouponError("");
    try {
      const res = await fetch("/api/coupon", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: couponCode,
          items: cart.map((l) => ({ productId: l.productId, price: l.price, qty: l.qty })),
        }),
      });
      const data = await res.json();
      if (res.ok) {
        const c = { code: data.code, discount: data.discount, description: data.description };
        setCoupon(c);
        sessionStorage.setItem("csdw_coupon", JSON.stringify(c));
        setCouponCode("");
        toast(`Coupon ${data.code} applied — ${data.description}`);
      } else {
        setCouponError(data.error);
      }
    } catch {
      setCouponError("Network error. Please try again.");
    } finally {
      setApplying(false);
    }
  };

  const removeCoupon = () => {
    setCoupon(null);
    sessionStorage.removeItem("csdw_coupon");
  };

  if (!hydrated) {
    return (
      <div className="container-x py-16 flex justify-center"><Spinner className="h-8 w-8 text-brand-700" /></div>
    );
  }

  if (cart.length === 0 && saved.length === 0) {
    return (
      <div className="container-x py-8">
        <EmptyState icon="🛒" title="Your cart is empty" text="Looks like you haven't added anything yet. Explore our premium collections and find something you love.">
          <Link href="/shop" className="btn-primary btn-md">Shop Products</Link>
          <Link href="/shop?flag=sale" className="btn-outline btn-md">View Sale</Link>
        </EmptyState>
      </div>
    );
  }

  const discount = coupon ? Math.min(coupon.discount, cartSubtotal) : 0;
  const freeShipping = cartSubtotal - discount >= 5000;

  return (
    <div className="container-x py-8">
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900 mb-8">Shopping Cart</h1>
      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          {cart.map((l) => {
            const key = lineKey(l);
            return (
              <div key={key} className="card p-4 flex gap-4">
                <Link href={`/product/${l.slug}`} className="shrink-0">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={l.image} alt={l.name} className="h-28 w-22 sm:w-24 object-cover rounded-lg" />
                </Link>
                <div className="flex-1 min-w-0">
                  <Link href={`/product/${l.slug}`} className="font-semibold text-slate-800 hover:text-brand-700 line-clamp-2">{l.name}</Link>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {[l.size && `Size: ${l.size}`, l.color && `Color: ${l.color}`].filter(Boolean).join(" • ")}
                  </p>
                  <p className="text-sm font-bold text-brand-800 mt-1">{formatPrice(l.price)} <span className="font-normal text-slate-400">each</span></p>
                  <div className="mt-2 flex flex-wrap items-center gap-3">
                    <div className="inline-flex items-center border border-slate-300 rounded-lg">
                      <button aria-label="Decrease quantity" onClick={() => updateQty(key, l.qty - 1)} className="px-3 py-1.5 text-slate-600 hover:text-brand-800">−</button>
                      <span className="px-2 text-sm font-bold" aria-live="polite">{l.qty}</span>
                      <button aria-label="Increase quantity" onClick={() => updateQty(key, l.qty + 1)} className="px-3 py-1.5 text-slate-600 hover:text-brand-800">+</button>
                    </div>
                    <button onClick={() => saveForLater(key)} className="text-xs font-semibold text-slate-500 hover:text-brand-700 underline">Save for Later</button>
                    <button onClick={() => removeFromCart(key)} className="text-xs font-semibold text-rose-500 hover:text-rose-700 underline">Remove</button>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs text-slate-400">Subtotal</p>
                  <p className="font-bold text-slate-900">{formatPrice(l.price * l.qty)}</p>
                </div>
              </div>
            );
          })}

          {saved.length > 0 && (
            <div className="mt-8">
              <h2 className="font-display text-xl font-bold text-slate-900 mb-3">Saved for Later ({saved.length})</h2>
              <div className="space-y-3">
                {saved.map((l) => {
                  const key = lineKey(l);
                  return (
                    <div key={key} className="card p-4 flex gap-4 items-center">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={l.image} alt={l.name} className="h-16 w-14 object-cover rounded-lg" />
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm text-slate-800 line-clamp-1">{l.name}</p>
                        <p className="text-sm font-bold text-brand-800">{formatPrice(l.price)}</p>
                      </div>
                      <button onClick={() => moveToCart(key)} className="btn-outline btn-sm">Move to Cart</button>
                      <button onClick={() => removeSaved(key)} aria-label="Remove saved item" className="text-rose-500 hover:text-rose-700 text-sm">✕</button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Summary */}
        <div>
          <div className="card p-6 sticky top-24">
            <h2 className="font-display text-xl font-bold text-slate-900 mb-4">Order Summary</h2>

            {coupon ? (
              <div className="flex items-center justify-between bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2 mb-4">
                <p className="text-sm text-emerald-700 font-semibold">✓ {coupon.code} <span className="font-normal">({coupon.description})</span></p>
                <button onClick={removeCoupon} className="text-xs text-rose-500 underline">Remove</button>
              </div>
            ) : (
              <form onSubmit={applyCoupon} className="mb-4">
                <label htmlFor="coupon" className="label">Coupon Code</label>
                <div className="flex gap-2">
                  <input id="coupon" value={couponCode} onChange={(e) => setCouponCode(e.target.value)} placeholder="e.g. WELCOME10" className="input" />
                  <button type="submit" disabled={applying || !couponCode.trim() || cart.length === 0} className="btn-outline btn-md whitespace-nowrap">
                    {applying ? <Spinner className="h-4 w-4" /> : "Apply"}
                  </button>
                </div>
                {couponError && <p className="text-xs text-rose-600 mt-1.5" role="alert">{couponError}</p>}
              </form>
            )}

            <dl className="space-y-2.5 text-sm border-t border-slate-100 pt-4">
              <div className="flex justify-between"><dt className="text-slate-500">Subtotal</dt><dd className="font-semibold">{formatPrice(cartSubtotal)}</dd></div>
              {discount > 0 && (
                <div className="flex justify-between text-emerald-600"><dt>Discount</dt><dd className="font-semibold">−{formatPrice(discount)}</dd></div>
              )}
              <div className="flex justify-between">
                <dt className="text-slate-500">Shipping</dt>
                <dd className="font-semibold">{freeShipping ? <span className="text-emerald-600">Free</span> : formatPrice(250)}</dd>
              </div>
              <div className="flex justify-between border-t border-slate-100 pt-3 text-base">
                <dt className="font-bold text-slate-900">Grand Total</dt>
                <dd className="font-bold text-brand-800">{formatPrice(cartSubtotal - discount + (freeShipping ? 0 : 250))}</dd>
              </div>
            </dl>
            <p className="text-xs text-slate-400 mt-2">Final shipping is confirmed at checkout. Free shipping over Rs. 5,000.</p>

            <div className="mt-5 space-y-2.5">
              <Link href="/checkout" className={`btn-primary btn-lg w-full ${cart.length === 0 ? "pointer-events-none opacity-50" : ""}`}>
                Proceed to Checkout
              </Link>
              <button onClick={() => toast("Cart is up to date", "info")} className="btn-outline btn-md w-full">Update Cart</button>
              <Link href="/shop" className="btn-ghost btn-md w-full">Continue Shopping</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
