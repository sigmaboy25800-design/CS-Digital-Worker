import type { Metadata } from "next";
import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { products, reviews } from "@/db/schema";
import { Breadcrumbs, EmptyState, Stars } from "@/components/ui";
import { formatDate } from "@/lib/utils";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Customer Reviews",
  description: "Read genuine, verified customer reviews of CS Digital Worker products. Every review is written by a real customer and moderated for authenticity.",
  alternates: { canonical: "/reviews" },
};

export default async function ReviewsPage() {
  const rows = await db
    .select({ review: reviews, productName: products.name, productSlug: products.slug, productImage: products.images })
    .from(reviews)
    .innerJoin(products, eq(reviews.productId, products.id))
    .where(eq(reviews.status, "approved"))
    .orderBy(desc(reviews.createdAt))
    .limit(60);

  return (
    <div className="container-x py-10">
      <Breadcrumbs items={[{ label: "Customer Reviews" }]} />
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900">Customer Reviews</h1>
      <p className="text-slate-500 mt-2 mb-8">
        Every review here was written by a genuine customer and moderated for authenticity. We never publish fake reviews.
      </p>

      {rows.length === 0 ? (
        <EmptyState
          icon="⭐"
          title="No reviews published yet"
          text="Our review section shows only genuine customer feedback. Once customers share their experiences, you'll see them here."
        >
          <Link href="/shop" className="btn-primary btn-md">Shop Products</Link>
        </EmptyState>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {rows.map(({ review, productName, productSlug, productImage }) => (
            <article key={review.id} className="card p-5">
              <div className="flex items-center gap-3 mb-3">
                {productImage?.[0] && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={productImage[0]} alt={productName} loading="lazy" className="h-12 w-10 object-cover rounded" />
                )}
                <Link href={`/product/${productSlug}`} className="text-sm font-semibold text-brand-700 hover:underline line-clamp-2">
                  {productName}
                </Link>
              </div>
              <Stars rating={review.rating} />
              {review.title && <p className="font-bold text-slate-900 mt-2">{review.title}</p>}
              <p className="text-sm text-slate-600 mt-1.5">{review.comment}</p>
              <p className="text-xs text-slate-400 mt-3">— {review.name}, {formatDate(review.createdAt)}</p>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
