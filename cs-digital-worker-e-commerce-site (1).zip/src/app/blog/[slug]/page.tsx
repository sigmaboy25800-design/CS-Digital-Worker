import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { and, desc, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { blogPosts } from "@/db/schema";
import { Breadcrumbs } from "@/components/ui";
import { formatDate, SITE_URL } from "@/lib/utils";

export const dynamic = "force-dynamic";

async function getPost(slug: string) {
  const [post] = await db.select().from(blogPosts).where(eq(blogPosts.slug, slug)).limit(1);
  return post ?? null;
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = await getPost(slug);
  if (!post) return { title: "Article Not Found" };
  return {
    title: post.seoTitle ?? post.title,
    description: post.seoDescription ?? post.excerpt ?? undefined,
    alternates: { canonical: `/blog/${post.slug}` },
    openGraph: {
      title: post.title,
      description: post.excerpt ?? undefined,
      type: "article",
      images: post.image ? [post.image] : undefined,
      publishedTime: post.publishedAt.toISOString(),
      authors: [post.author],
    },
  };
}

function renderContent(content: string) {
  return content.split(/\n\n+/).map((block, i) => {
    if (block.startsWith("## ")) {
      const [heading, ...rest] = block.split("\n");
      return (
        <div key={i}>
          <h2>{heading.replace(/^## /, "")}</h2>
          {rest.length > 0 && <p>{rest.join(" ")}</p>}
        </div>
      );
    }
    return <p key={i}>{block}</p>;
  });
}

export default async function BlogPostPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const post = await getPost(slug);
  if (!post || !post.isPublished) notFound();

  const related = await db
    .select()
    .from(blogPosts)
    .where(and(eq(blogPosts.isPublished, true), eq(blogPosts.category, post.category), ne(blogPosts.id, post.id)))
    .orderBy(desc(blogPosts.publishedAt))
    .limit(3);

  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: post.title,
    description: post.excerpt,
    image: post.image ? [post.image] : undefined,
    datePublished: post.publishedAt.toISOString(),
    author: { "@type": "Organization", name: post.author },
    publisher: { "@type": "Organization", name: "CS Digital Worker", logo: { "@type": "ImageObject", url: `${SITE_URL}/favicon.svg` } },
    mainEntityOfPage: `${SITE_URL}/blog/${post.slug}`,
  };

  const shareUrl = `${SITE_URL}/blog/${post.slug}`;

  return (
    <div className="container-x py-10 max-w-3xl">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      <Breadcrumbs items={[{ label: "Blog", href: "/blog" }, { label: post.title }]} />
      <p className="text-xs font-bold uppercase tracking-widest text-brand-700">{post.category}</p>
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900 mt-2">{post.title}</h1>
      <p className="text-sm text-slate-400 mt-3">{formatDate(post.publishedAt)} • by {post.author}</p>

      {post.image && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={post.image} alt={post.imageAlt ?? post.title} className="w-full h-72 sm:h-96 object-cover rounded-2xl mt-6" />
      )}

      <div className="prose-custom mt-8">{renderContent(post.content)}</div>

      {(post.tags ?? []).length > 0 && (
        <p className="mt-6 text-xs text-slate-400">Tags: {(post.tags ?? []).join(" • ")}</p>
      )}

      <div className="mt-8 card p-5 flex flex-wrap items-center gap-3">
        <span className="text-sm font-bold text-slate-800">Share this article:</span>
        <a href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`} target="_blank" rel="noopener noreferrer" className="btn-outline btn-sm">Facebook</a>
        <a href={`https://wa.me/?text=${encodeURIComponent(post.title + " " + shareUrl)}`} target="_blank" rel="noopener noreferrer" className="btn-outline btn-sm">WhatsApp</a>
        <a href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(post.title)}`} target="_blank" rel="noopener noreferrer" className="btn-outline btn-sm">X / Twitter</a>
      </div>

      {related.length > 0 && (
        <section className="mt-12" aria-labelledby="related-posts">
          <h2 id="related-posts" className="font-display text-2xl font-bold text-slate-900 mb-4">Related Articles</h2>
          <div className="grid sm:grid-cols-3 gap-4">
            {related.map((r) => (
              <Link key={r.id} href={`/blog/${r.slug}`} className="card card-hover overflow-hidden">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={r.image ?? "/images/hero.jpg"} alt={r.imageAlt ?? r.title} loading="lazy" className="h-32 w-full object-cover" />
                <div className="p-3">
                  <p className="text-sm font-bold text-slate-900 line-clamp-2 hover:text-brand-700">{r.title}</p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
