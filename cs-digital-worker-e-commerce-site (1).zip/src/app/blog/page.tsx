import type { Metadata } from "next";
import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { blogPosts } from "@/db/schema";
import { Breadcrumbs, EmptyState } from "@/components/ui";
import { formatDate } from "@/lib/utils";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Blog — Guides, Tips & Digital Business Insights",
  description: "The CS Digital Worker blog: shopping guides, fashion care tips, SEO, digital marketing, AI tools and online business insights.",
  alternates: { canonical: "/blog" },
};

const CATEGORIES = ["Digital Marketing", "SEO", "AI Tools", "E-Commerce", "Online Business", "Fashion", "Shopping Guides", "Product Guides", "Tutorials"];

export default async function BlogPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string }>;
}) {
  const { category } = await searchParams;
  const posts = await db
    .select()
    .from(blogPosts)
    .where(eq(blogPosts.isPublished, true))
    .orderBy(desc(blogPosts.publishedAt));
  const filtered = category ? posts.filter((p) => p.category === category) : posts;

  return (
    <div className="container-x py-10">
      <Breadcrumbs items={[{ label: "Blog" }]} />
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900">Our Blog</h1>
      <p className="text-slate-500 mt-2 mb-6">Guides, tips and insights on fashion, e-commerce and digital business.</p>

      <div className="flex gap-2 overflow-x-auto pb-3 mb-8">
        <Link href="/blog" className={`px-3.5 py-1.5 rounded-full text-sm font-semibold whitespace-nowrap ${!category ? "bg-brand-800 text-white" : "bg-white border border-slate-200 text-slate-600 hover:border-brand-600"}`}>
          All
        </Link>
        {CATEGORIES.map((c) => (
          <Link key={c} href={`/blog?category=${encodeURIComponent(c)}`} className={`px-3.5 py-1.5 rounded-full text-sm font-semibold whitespace-nowrap ${category === c ? "bg-brand-800 text-white" : "bg-white border border-slate-200 text-slate-600 hover:border-brand-600"}`}>
            {c}
          </Link>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon="📝" title="No articles in this category yet" text="We're always writing new guides. Check back soon or browse all posts.">
          <Link href="/blog" className="btn-primary btn-md">All Articles</Link>
        </EmptyState>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((post) => (
            <article key={post.id} className="card card-hover overflow-hidden flex flex-col">
              <Link href={`/blog/${post.slug}`}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={post.image ?? "/images/hero.jpg"} alt={post.imageAlt ?? post.title} loading="lazy" className="h-52 w-full object-cover" />
              </Link>
              <div className="p-5 flex flex-col flex-1">
                <p className="text-xs font-bold uppercase tracking-wide text-brand-700">{post.category}</p>
                <Link href={`/blog/${post.slug}`}>
                  <h2 className="font-display font-bold text-lg text-slate-900 mt-1.5 hover:text-brand-700 line-clamp-2">{post.title}</h2>
                </Link>
                <p className="text-sm text-slate-500 mt-2 line-clamp-3 flex-1">{post.excerpt}</p>
                <p className="text-xs text-slate-400 mt-4">{formatDate(post.publishedAt)} • {post.author}</p>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
