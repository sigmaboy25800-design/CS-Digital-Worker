"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useStore } from "@/components/Providers";
import { EmptyState, Spinner } from "@/components/ui";
import { formatPrice } from "@/lib/utils";
import type { SavedAddress } from "@/db/schema";

export default function CheckoutPage() {
  const router = useRouter();
  const { cart, hydrated, cartSubtotal, clearCart } = useStore();
  const [form, setForm] = useState({ fullName: "", phone: "", email: "", address: "", city: "", postalCode: "", notes: "" });
  const [paymentMethod, setPaymentMethod] = useState<"cod" | "bank_transfer">("cod");
  const [terms, setTerms] = useState(false);
  const [coupon, setCoupon] = useState<{ code: string; discount: number; description: string } | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [addresses, setAddresses] = useState<SavedAddress[]>([]);

  useEffect(() => {
    try {
      const stored = sessionStorage.getItem("csdw_coupon");
      if (stored) setCoupon(JSON.parse(stored));
    } catch { /* ignore */ }
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => {
        if (d.user) {
          setForm((f) => ({ ...f, fullName: d.user.name ?? "", email: d.user.email ?? "", phone: d.user.phone ?? "" }));
          const addrs: SavedAddress[] = d.user.addresses ?? [];
          setAddresses(addrs);
          const def = addrs.find((a) => a.isDefault) ?? addrs[0];
          if (def) {
            setForm((f) => ({
              ...f,
              fullName: def.fullName || f.fullName,
              phone: def.phone || f.phone,
              address: def.address, city: def.city, postalCode: def.postalCode,
            }));
          }
        }
      })
      .catch(() => {});
  }, []);

  const set = (key: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  const discount = coupon ? Math.min(coupon.discount, cartSubtotal) : 0;
  const freeShipping = cartSubtotal - discount >= 5000;
  const shipping = freeShipping ? 0 : 250;
  const total = cartSubtotal - discount + shipping;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: cart.map((l) => ({ productId: l.productId, qty: l.qty, size: l.size, color: l.color })),
          customer: form,
          paymentMethod,
          couponCode: coupon?.code,
          termsAccepted: terms,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        clearCart();
        sessionStorage.removeItem("csdw_coupon");
        router.push(`/order-confirmation/${data.orderNumber}`);
      } else {
        setError(data.error ?? "Could not place order.");
        setSubmitting(false);
      }
    } catch {
      setError("Network error. Please try again.");
      setSubmitting(false);
    }
  };

  if (!hydrated) {
    return <div className="container-x py-16 flex justify-center"><Spinner className="h-8 w-8 text-brand-700" /></div>;
  }

  if (cart.length === 0) {
    return (
      <div className="container-x py-8">
        <EmptyState icon="🛒" title="Nothing to check out" text="Your cart is empty. Add some products before proceeding to checkout.">
          <Link href="/shop" className="btn-primary btn-md">Shop Products</Link>
        </EmptyState>
      </div>
    );
  }

  return (
    <div className="container-x py-8">
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900 mb-8">Checkout</h1>
      <form onSubmit={submit} className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <section className="card p-6" aria-labelledby="shipping-heading">
            <h2 id="shipping-heading" className="font-display text-xl font-bold text-slate-900 mb-4">Shipping Details</h2>
            {addresses.length > 0 && (
              <div className="mb-4">
                <p className="label">Use a saved address</p>
                <div className="flex flex-wrap gap-2">
                  {addresses.map((a, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setForm((f) => ({ ...f, fullName: a.fullName || f.fullName, phone: a.phone || f.phone, address: a.address, city: a.city, postalCode: a.postalCode }))}
                      className="px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold text-slate-600 hover:border-brand-600"
                    >
                      {a.label}: {a.city}
                    </button>
                  ))}
                </div>
              </div>
            )}
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="fullName" className="label">Full Name *</label>
                <input id="fullName" required value={form.fullName} onChange={set("fullName")} className="input" autoComplete="name" />
              </div>
              <div>
                <label htmlFor="phone" className="label">Phone *</label>
                <input id="phone" required type="tel" value={form.phone} onChange={set("phone")} className="input" autoComplete="tel" placeholder="03XXXXXXXXX" />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="email" className="label">Email *</label>
                <input id="email" required type="email" value={form.email} onChange={set("email")} className="input" autoComplete="email" />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="address" className="label">Complete Address *</label>
                <textarea id="address" required value={form.address} onChange={set("address")} rows={2} className="input" autoComplete="street-address" placeholder="House #, street, area" />
              </div>
              <div>
                <label htmlFor="city" className="label">City *</label>
                <input id="city" required value={form.city} onChange={set("city")} className="input" autoComplete="address-level2" />
              </div>
              <div>
                <label htmlFor="postalCode" className="label">Postal Code</label>
                <input id="postalCode" value={form.postalCode} onChange={set("postalCode")} className="input" autoComplete="postal-code" />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="notes" className="label">Order Notes (optional)</label>
                <textarea id="notes" value={form.notes} onChange={set("notes")} rows={2} className="input" placeholder="Any special instructions for delivery" />
              </div>
            </div>
          </section>

          <section className="card p-6" aria-labelledby="payment-heading">
            <h2 id="payment-heading" className="font-display text-xl font-bold text-slate-900 mb-4">Payment Method</h2>
            <div className="space-y-3">
              <label className={`flex items-start gap-3 border rounded-xl p-4 cursor-pointer ${paymentMethod === "cod" ? "border-brand-700 bg-brand-50" : "border-slate-200"}`}>
                <input type="radio" name="payment" checked={paymentMethod === "cod"} onChange={() => setPaymentMethod("cod")} className="mt-1 accent-brand-700" />
                <span>
                  <span className="font-bold text-slate-900 block">Cash on Delivery</span>
                  <span className="text-sm text-slate-500">Pay in cash when your order arrives at your doorstep.</span>
                </span>
              </label>
              <label className={`flex items-start gap-3 border rounded-xl p-4 cursor-pointer ${paymentMethod === "bank_transfer" ? "border-brand-700 bg-brand-50" : "border-slate-200"}`}>
                <input type="radio" name="payment" checked={paymentMethod === "bank_transfer"} onChange={() => setPaymentMethod("bank_transfer")} className="mt-1 accent-brand-700" />
                <span>
                  <span className="font-bold text-slate-900 block">Bank Transfer</span>
                  <span className="text-sm text-slate-500">Bank details will be shared via WhatsApp/Email after order confirmation.</span>
                </span>
              </label>
              <div className="flex items-start gap-3 border border-dashed border-slate-200 rounded-xl p-4 opacity-70">
                <span className="mt-0.5" aria-hidden>💳</span>
                <span>
                  <span className="font-bold text-slate-700 block">Online Payment (Coming Soon)</span>
                  <span className="text-sm text-slate-500">Card and wallet payments will be available soon. We never store card details.</span>
                </span>
              </div>
            </div>
          </section>
        </div>

        {/* Summary */}
        <div>
          <div className="card p-6 sticky top-24">
            <h2 className="font-display text-xl font-bold text-slate-900 mb-4">Your Order</h2>
            <ul className="space-y-3 max-h-64 overflow-auto pr-1">
              {cart.map((l, i) => (
                <li key={i} className="flex gap-3 items-center">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={l.image} alt={l.name} className="h-14 w-11 object-cover rounded" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-slate-800 line-clamp-1">{l.name}</p>
                    <p className="text-xs text-slate-400">{[l.size, l.color].filter(Boolean).join(" / ")} × {l.qty}</p>
                  </div>
                  <span className="text-xs font-bold text-slate-800">{formatPrice(l.price * l.qty)}</span>
                </li>
              ))}
            </ul>
            <dl className="space-y-2.5 text-sm border-t border-slate-100 pt-4 mt-4">
              <div className="flex justify-between"><dt className="text-slate-500">Subtotal</dt><dd className="font-semibold">{formatPrice(cartSubtotal)}</dd></div>
              {discount > 0 && coupon && (
                <div className="flex justify-between text-emerald-600"><dt>Coupon ({coupon.code})</dt><dd className="font-semibold">−{formatPrice(discount)}</dd></div>
              )}
              <div className="flex justify-between"><dt className="text-slate-500">Shipping</dt><dd className="font-semibold">{shipping === 0 ? <span className="text-emerald-600">Free</span> : formatPrice(shipping)}</dd></div>
              <div className="flex justify-between border-t border-slate-100 pt-3 text-base">
                <dt className="font-bold text-slate-900">Total</dt>
                <dd className="font-bold text-brand-800">{formatPrice(total)}</dd>
              </div>
            </dl>

            <label className="flex items-start gap-2 mt-5 text-xs text-slate-600 cursor-pointer">
              <input type="checkbox" required checked={terms} onChange={(e) => setTerms(e.target.checked)} className="mt-0.5 accent-brand-700" />
              <span>
                I agree to the <Link href="/terms" className="text-brand-700 underline">Terms & Conditions</Link>,{" "}
                <Link href="/return-policy" className="text-brand-700 underline">Return Policy</Link> and{" "}
                <Link href="/privacy-policy" className="text-brand-700 underline">Privacy Policy</Link>. My data is used only to process this order.
              </span>
            </label>

            {error && <p className="mt-3 text-sm text-rose-600 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2" role="alert">{error}</p>}

            <button type="submit" disabled={submitting || !terms} className="btn-gold btn-lg w-full mt-4">
              {submitting ? <Spinner /> : `Place Order — ${formatPrice(total)}`}
            </button>
            <p className="text-xs text-slate-400 text-center mt-3">🔒 Secure checkout. We never store payment card details.</p>
          </div>
        </div>
      </form>
    </div>
  );
}
