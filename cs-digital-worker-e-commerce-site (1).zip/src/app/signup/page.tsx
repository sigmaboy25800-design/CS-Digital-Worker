"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Spinner } from "@/components/ui";

export default function SignupPage() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "", confirm: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const set = (key: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.password !== form.confirm) {
      setError("Passwords do not match.");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (res.ok) {
        router.push("/account");
        router.refresh();
      } else {
        setError(data.error);
        setLoading(false);
      }
    } catch {
      setError("Network error. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div className="container-x py-14 max-w-md">
      <h1 className="font-display text-3xl font-bold text-slate-900 text-center">Create Account</h1>
      <p className="text-slate-500 text-center mt-2 mb-8">Join CS Digital Worker for faster checkout & order tracking</p>
      <form onSubmit={submit} className="card p-6 space-y-4">
        <div>
          <label htmlFor="name" className="label">Full Name</label>
          <input id="name" required value={form.name} onChange={set("name")} className="input" autoComplete="name" />
        </div>
        <div>
          <label htmlFor="email" className="label">Email</label>
          <input id="email" type="email" required value={form.email} onChange={set("email")} className="input" autoComplete="email" />
        </div>
        <div>
          <label htmlFor="phone" className="label">Phone (optional)</label>
          <input id="phone" type="tel" value={form.phone} onChange={set("phone")} className="input" autoComplete="tel" placeholder="03XXXXXXXXX" />
        </div>
        <div>
          <label htmlFor="password" className="label">Password (min 8 characters)</label>
          <input id="password" type="password" required minLength={8} value={form.password} onChange={set("password")} className="input" autoComplete="new-password" />
        </div>
        <div>
          <label htmlFor="confirm" className="label">Confirm Password</label>
          <input id="confirm" type="password" required value={form.confirm} onChange={set("confirm")} className="input" autoComplete="new-password" />
        </div>
        {error && <p className="text-sm text-rose-600 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2" role="alert">{error}</p>}
        <button type="submit" disabled={loading} className="btn-primary btn-lg w-full">
          {loading ? <Spinner /> : "Create Account"}
        </button>
        <p className="text-sm text-center text-slate-500">
          Already have an account? <Link href="/login" className="text-brand-700 font-semibold hover:underline">Sign in</Link>
        </p>
        <p className="text-xs text-slate-400 text-center">
          By creating an account you agree to our <Link href="/terms" className="underline">Terms</Link> and <Link href="/privacy-policy" className="underline">Privacy Policy</Link>.
        </p>
      </form>
    </div>
  );
}
