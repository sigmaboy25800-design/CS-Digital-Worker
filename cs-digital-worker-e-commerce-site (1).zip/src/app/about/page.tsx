import type { Metadata } from "next";
import Link from "next/link";
import { Breadcrumbs } from "@/components/ui";
import { CONTACT } from "@/lib/utils";

export const metadata: Metadata = {
  title: "About Us",
  description: "CS Digital Worker is a premium e-commerce and digital business platform from Pakistan, offering quality fashion products plus SEO, digital marketing and website services.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <div className="container-x py-10 max-w-4xl">
      <Breadcrumbs items={[{ label: "About Us" }]} />
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900">About CS Digital Worker</h1>
      <p className="text-slate-500 mt-2 mb-8">Premium fashion commerce, built on trust and digital excellence.</p>

      <div className="prose-custom">
        <p>
          <strong>CS Digital Worker</strong> is a Pakistani e-commerce and digital business platform focused on
          delivering premium fashion — 2 &amp; 3 piece suits, lawn, Arabic lawn, printed and embroidered collections,
          dupattas and trousers — with honest pricing, transparent policies and dependable nationwide delivery.
        </p>
        <h2>Our Mission</h2>
        <p>
          To make premium-quality fashion accessible across Pakistan through a secure, modern online shopping
          experience — backed by real customer support on WhatsApp, phone and email.
        </p>
        <h2>What We Stand For</h2>
        <ul>
          <li><strong>Quality first:</strong> every product is checked before dispatch.</li>
          <li><strong>Honest business:</strong> real photos, real prices, real reviews — never fake claims.</li>
          <li><strong>Customer care:</strong> quick responses and easy returns within 7 days.</li>
          <li><strong>Secure shopping:</strong> your data is protected and we never store card details.</li>
        </ul>
        <h2>Beyond the Store — Digital Services</h2>
        <p>
          CS Digital Worker is also a digital services brand. We help businesses grow online with
          <strong> SEO services, digital marketing, website development, e-commerce setup and AI-powered solutions</strong>.
          If you want your own business to succeed online, our team can help — reach out through our{" "}
          <Link href="/contact">contact page</Link>.
        </p>
        <h2>Get in Touch</h2>
        <ul>
          <li>Phone / WhatsApp: <a href={CONTACT.phoneHref}>{CONTACT.phone}</a></li>
          <li>Email: <a href={CONTACT.emailHref}>{CONTACT.email}</a></li>
        </ul>
      </div>

      <div className="mt-10 grid sm:grid-cols-3 gap-4">
        <Link href="/shop" className="btn-primary btn-lg">Shop Collection</Link>
        <a href={CONTACT.whatsappHref} target="_blank" rel="noopener noreferrer" className="btn btn-lg bg-emerald-500 text-white hover:bg-emerald-600">WhatsApp Us</a>
        <Link href="/contact" className="btn-outline btn-lg">Contact Us</Link>
      </div>
    </div>
  );
}
