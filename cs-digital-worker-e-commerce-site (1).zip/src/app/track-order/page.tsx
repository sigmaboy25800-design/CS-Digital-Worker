"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Spinner } from "@/components/ui";
import { CONTACT, formatDate, formatPrice, ORDER_STATUSES, STATUS_LABELS } from "@/lib/utils";
import type { Order, OrderItem } from "@/db/schema";

const TRACK_STEPS = ["pending", "confirmed", "processing", "shipped", "out_for_delivery", "delivered"];

function TrackOrderInner() {
  const sp = useSearchParams();
  const [orderNumber, setOrderNumber] = useState(sp.get("orderNumber") ?? "");
  const [email, setEmail] = useState(sp.get("email") ?? "");
  const [result, setResult] = useState<{ order: Order; items: OrderItem[] } | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const lookup = async (on: string, em: string) => {
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const res = await fetch(`/api/orders?orderNumber=${encodeURIComponent(on)}&email=${encodeURIComponent(em)}`);
      const data = await res.json();
      if (res.ok) setResult(data);
      else setError(data.error ?? "Order not found.");
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const on = sp.get("orderNumber");
    const em = sp.get("email");
    if (on && em) lookup(on, em);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const stepIndex = result ? TRACK_STEPS.indexOf(result.order.status) : -1;
  const isCancelled = result && ["cancelled", "returned"].includes(result.order.status);

  return (
    <div className="container-x py-10 max-w-3xl">
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900 text-center">Track Your Order</h1>
      <p className="text-slate-500 text-center mt-2 mb-8">Enter your order number and the email used at checkout.</p>

      <form
        onSubmit={(e) => { e.preventDefault(); lookup(orderNumber.trim(), email.trim()); }}
        className="card p-6 grid sm:grid-cols-[1fr_1fr_auto] gap-3"
      >
        <div>
          <label htmlFor="on" className="label">Order Number</label>
          <input id="on" required value={orderNumber} onChange={(e) => setOrderNumber(e.target.value)} placeholder="CSD-XXXXXXX" className="input" />
        </div>
        <div>
          <label htmlFor="em" className="label">Email</label>
          <input id="em" required type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="input" />
        </div>
        <div className="flex items-end">
          <button type="submit" disabled={loading} className="btn-primary btn-md w-full">
            {loading ? <Spinner className="h-4 w-4" /> : "Track"}
          </button>
        </div>
      </form>

      {error && <p className="mt-4 text-sm text-rose-600 bg-rose-50 border border-rose-200 rounded-lg p-3 text-center" role="alert">{error}</p>}

      {result && (
        <div className="card mt-6 p-6">
          <div className="flex flex-wrap justify-between gap-3 mb-6">
            <div>
              <p className="text-xs text-slate-400">Order</p>
              <p className="font-bold text-slate-900">{result.order.orderNumber}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400">Placed</p>
              <p className="font-bold text-slate-900">{formatDate(result.order.createdAt)}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400">Total</p>
              <p className="font-bold text-brand-800">{formatPrice(result.order.total)}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400">Status</p>
              <p className="font-bold text-slate-900">{STATUS_LABELS[result.order.status]}</p>
            </div>
          </div>

          {isCancelled ? (
            <p className="bg-rose-50 border border-rose-200 text-rose-700 rounded-lg p-4 text-sm font-semibold text-center">
              This order was {STATUS_LABELS[result.order.status].toLowerCase()}.
            </p>
          ) : (
            <ol className="relative flex flex-col sm:flex-row gap-4 sm:gap-0 sm:justify-between" aria-label="Order progress">
              {TRACK_STEPS.map((step, i) => {
                const done = i <= stepIndex;
                return (
                  <li key={step} className="flex sm:flex-col items-center gap-2 sm:flex-1 relative">
                    {i < TRACK_STEPS.length - 1 && (
                      <span className={`hidden sm:block absolute top-4 left-1/2 w-full h-0.5 ${i < stepIndex ? "bg-brand-700" : "bg-slate-200"}`} aria-hidden />
                    )}
                    <span className={`relative z-10 h-8 w-8 rounded-full inline-flex items-center justify-center text-xs font-bold ${done ? "bg-brand-700 text-white" : "bg-slate-200 text-slate-500"}`}>
                      {done ? "✓" : i + 1}
                    </span>
                    <span className={`text-xs font-semibold text-center ${done ? "text-brand-800" : "text-slate-400"}`}>
                      {STATUS_LABELS[step]}
                    </span>
                  </li>
                );
              })}
            </ol>
          )}

          {result.order.cancelRequested && !isCancelled && (
            <p className="mt-4 text-sm bg-amber-50 border border-amber-200 text-amber-800 rounded-lg p-3">
              A cancellation request is pending for this order.
            </p>
          )}

          <h2 className="font-display font-bold text-lg text-slate-900 mt-6 mb-2">Items</h2>
          <ul className="divide-y divide-slate-100">
            {result.items.map((item) => (
              <li key={item.id} className="py-2.5 flex justify-between gap-3 text-sm">
                <span className="text-slate-700">{item.name} {[item.size, item.color].filter(Boolean).join("/") && `(${[item.size, item.color].filter(Boolean).join(", ")})`} × {item.quantity}</span>
                <span className="font-semibold">{formatPrice(item.total)}</span>
              </li>
            ))}
          </ul>

          <p className="mt-5 text-xs text-slate-400 text-center">
            Questions about this order? <a href={CONTACT.whatsappHref} target="_blank" rel="noopener noreferrer" className="text-brand-700 underline">WhatsApp {CONTACT.phone}</a> or email <a href={CONTACT.emailHref} className="text-brand-700 underline">{CONTACT.email}</a>
          </p>
        </div>
      )}
    </div>
  );
}

export default function TrackOrderPage() {
  return (
    <Suspense fallback={<div className="container-x py-16 flex justify-center"><Spinner className="h-8 w-8 text-brand-700" /></div>}>
      <TrackOrderInner />
    </Suspense>
  );
}
