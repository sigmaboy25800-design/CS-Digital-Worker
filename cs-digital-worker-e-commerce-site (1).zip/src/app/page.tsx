import Link from "next/link";
import Image from "next/image";
import { desc, eq, and } from "drizzle-orm";
import { db } from "@/db";
import { blogPosts, products, reviews } from "@/db/schema";
import { getActiveCategories, getSettings } from "@/lib/shop";
import ProductCard, { type CardProduct } from "@/components/ProductCard";
import NewsletterForm from "@/components/NewsletterForm";
import { SectionHeading, Stars } from "@/components/ui";
import { formatDate } from "@/lib/utils";
import type { Product } from "@/db/schema";

export const dynamic = "force-dynamic";

function toCard(p: Product): CardProduct {
  return {
    id: p.id, slug: p.slug, name: p.name, images: p.images ?? [],
    imageAlt: p.imageAlt, price: p.price, oldPrice: p.oldPrice, stock: p.stock,
    ratingAvg: p.ratingAvg, ratingCount: p.ratingCount,
    sizes: p.sizes ?? [], colors: p.colors ?? [], isNewArrival: p.isNewArrival,
  };
}

const WHY_US = [
  { icon: "✨", title: "Quality Products", text: "Every item is carefully checked before dispatch so you receive exactly what you ordered." },
  { icon: "🔒", title: "Secure Shopping", text: "Your data stays protected with secure sessions and privacy-first checkout." },
  { icon: "🛒", title: "Easy Ordering", text: "Order in minutes with cash on delivery — no card required." },
  { icon: "💬", title: "Customer Support", text: "Real humans on WhatsApp, phone and email, ready to help with any question." },
  { icon: "🚚", title: "Fast Delivery", text: "Quick nationwide delivery with live order tracking at every step." },
  { icon: "🤝", title: "Trusted Service", text: "Transparent policies, honest pricing and a straightforward return process." },
];

export default async function HomePage() {
  const [settings, categories, featured, newArrivals, bestSellers, saleItems, latestReviews, posts] =
    await Promise.all([
      getSettings(),
      getActiveCategories(),
      db.select().from(products).where(and(eq(products.isActive, true), eq(products.isFeatured, true))).orderBy(desc(products.createdAt)).limit(8),
      db.select().from(products).where(and(eq(products.isActive, true), eq(products.isNewArrival, true))).orderBy(desc(products.createdAt)).limit(4),
      db.select().from(products).where(and(eq(products.isActive, true), eq(products.isBestSeller, true))).orderBy(desc(products.salesCount)).limit(4),
      db.select().from(products).where(and(eq(products.isActive, true), eq(products.onSale, true))).orderBy(desc(products.createdAt)).limit(4),
      db.select({ review: reviews, productName: products.name, productSlug: products.slug })
        .from(reviews).innerJoin(products, eq(reviews.productId, products.id))
        .where(eq(reviews.status, "approved")).orderBy(desc(reviews.createdAt)).limit(3),
      db.select().from(blogPosts).where(eq(blogPosts.isPublished, true)).orderBy(desc(blogPosts.publishedAt)).limit(3),
    ]);

  return (
    <div>
      {/* Hero */}
      <section className="relative bg-brand-950 text-white overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/images/hero.jpg"
            alt="Premium fashion collection by CS Digital Worker"
            fill
            priority
            className="object-cover opacity-40"
            sizes="100vw"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-brand-950 via-brand-950/80 to-transparent" />
        </div>
        <div className="container-x relative py-20 sm:py-28 lg:py-36 max-w-7xl">
          <div className="max-w-2xl">
            <p className="inline-block bg-gold-500/20 text-gold-400 text-xs sm:text-sm font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-4">
              Premium Collections 2025
            </p>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight">
              {settings.heroHeading}
            </h1>
            <p className="mt-5 text-base sm:text-lg text-slate-200 leading-relaxed max-w-xl">
              {settings.heroSubheading}
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/shop" className="btn-gold btn-lg">Shop Now</Link>
              <Link href="/categories" className="btn btn-lg border-2 border-white/60 text-white hover:bg-white hover:text-brand-950">
                Explore Collections
              </Link>
            </div>
            <div className="mt-10 flex flex-wrap gap-x-8 gap-y-2 text-sm text-slate-300">
              <span>✓ Cash on Delivery</span>
              <span>✓ Nationwide Shipping</span>
              <span>✓ Easy Returns</span>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="container-x py-14" aria-labelledby="categories-heading">
        <SectionHeading title="Shop by Category" subtitle="Explore our curated collections" href="/categories" />
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
          {categories.slice(0, 8).map((c) => (
            <Link key={c.id} href={`/category/${c.slug}`} className="group relative rounded-xl overflow-hidden aspect-[4/5] card-hover shadow-sm">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={c.image ?? "/images/hero.jpg"} alt={c.name} loading="lazy" className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
              <span className="absolute bottom-3 left-3 right-3 text-white font-display font-bold text-sm sm:text-base">
                {c.name}
              </span>
            </Link>
          ))}
          <Link href="/shop?flag=new" className="group relative rounded-xl overflow-hidden aspect-[4/5] card-hover bg-gradient-to-br from-brand-700 to-brand-950 flex items-center justify-center">
            <span className="text-white font-display font-bold text-lg text-center px-2">New<br />Arrivals →</span>
          </Link>
          <Link href="/shop?flag=sale" className="group relative rounded-xl overflow-hidden aspect-[4/5] card-hover bg-gradient-to-br from-rose-500 to-rose-800 flex items-center justify-center">
            <span className="text-white font-display font-bold text-lg text-center px-2">Sale<br />Up to 30% →</span>
          </Link>
        </div>
      </section>

      {/* Featured */}
      <section className="container-x py-10" aria-labelledby="featured-heading">
        <SectionHeading title="Featured Products" subtitle="Handpicked pieces our team loves" href="/shop?flag=featured" />
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {featured.map((p) => <ProductCard key={p.id} product={toCard(p)} />)}
        </div>
      </section>

      {/* New arrivals */}
      <section className="bg-white py-14 border-y border-slate-100">
        <div className="container-x">
          <SectionHeading title="New Arrivals" subtitle="Fresh styles just landed" href="/shop?flag=new" />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {newArrivals.map((p) => <ProductCard key={p.id} product={toCard(p)} />)}
          </div>
        </div>
      </section>

      {/* Best sellers */}
      <section className="container-x py-14">
        <SectionHeading title="Best Sellers" subtitle="Customer favorites, ordered again and again" href="/shop?flag=bestseller" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          {bestSellers.map((p) => <ProductCard key={p.id} product={toCard(p)} />)}
        </div>
      </section>

      {/* Sale */}
      <section className="bg-gradient-to-br from-brand-950 to-brand-900 py-14">
        <div className="container-x">
          <div className="flex items-end justify-between gap-4 mb-6">
            <div>
              <h2 className="font-display text-2xl sm:text-3xl font-bold text-white">Special Offers</h2>
              <p className="text-brand-200 mt-1 text-sm sm:text-base">Limited-time deals — grab them before they&apos;re gone</p>
            </div>
            <Link href="/shop?flag=sale" className="text-sm font-semibold text-gold-400 hover:text-gold-500 whitespace-nowrap">View all →</Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {saleItems.map((p) => <ProductCard key={p.id} product={toCard(p)} />)}
          </div>
        </div>
      </section>

      {/* Why choose us */}
      <section className="container-x py-16" aria-labelledby="why-heading">
        <h2 id="why-heading" className="font-display text-2xl sm:text-3xl font-bold text-slate-900 text-center">Why Choose CS Digital Worker</h2>
        <p className="text-slate-500 text-center mt-2 mb-10 max-w-2xl mx-auto">A shopping experience built on quality, transparency and genuine customer care.</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {WHY_US.map((w) => (
            <div key={w.title} className="card card-hover p-6">
              <div className="text-3xl mb-3" aria-hidden="true">{w.icon}</div>
              <h3 className="font-display font-bold text-lg text-slate-900 mb-1.5">{w.title}</h3>
              <p className="text-sm text-slate-500 leading-relaxed">{w.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Reviews */}
      <section className="bg-white py-14 border-y border-slate-100" aria-labelledby="reviews-heading">
        <div className="container-x">
          <SectionHeading title="What Our Customers Say" subtitle="Genuine reviews from verified shoppers" href="/reviews" />
          {latestReviews.length === 0 ? (
            <div className="card p-8 text-center">
              <p className="text-slate-500">
                No customer reviews yet — be the first!{" "}
                <Link href="/shop" className="text-brand-700 font-semibold hover:underline">Shop a product</Link>{" "}
                and share your experience after delivery.
              </p>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {latestReviews.map(({ review, productName, productSlug }) => (
                <blockquote key={review.id} className="card p-6">
                  <Stars rating={review.rating} />
                  {review.title && <p className="font-bold text-slate-900 mt-2">{review.title}</p>}
                  <p className="text-sm text-slate-600 mt-1.5 line-clamp-4">{review.comment}</p>
                  <footer className="mt-3 text-xs text-slate-400">
                    {review.name} • on{" "}
                    <Link href={`/product/${productSlug}`} className="text-brand-700 hover:underline">{productName}</Link>
                  </footer>
                </blockquote>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Blog preview */}
      <section className="container-x py-14" aria-labelledby="blog-heading">
        <SectionHeading title="From Our Blog" subtitle="Guides, tips and insights on fashion & digital business" href="/blog" />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {posts.map((post) => (
            <article key={post.id} className="card card-hover overflow-hidden">
              <Link href={`/blog/${post.slug}`}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={post.image ?? "/images/hero.jpg"} alt={post.imageAlt ?? post.title} loading="lazy" className="h-48 w-full object-cover" />
              </Link>
              <div className="p-5">
                <p className="text-xs font-bold uppercase tracking-wide text-brand-700">{post.category}</p>
                <Link href={`/blog/${post.slug}`}>
                  <h3 className="font-display font-bold text-lg text-slate-900 mt-1.5 hover:text-brand-700 line-clamp-2">{post.title}</h3>
                </Link>
                <p className="text-sm text-slate-500 mt-2 line-clamp-2">{post.excerpt}</p>
                <p className="text-xs text-slate-400 mt-3">{formatDate(post.publishedAt)} • {post.author}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Newsletter */}
      <section className="bg-brand-900 py-14">
        <div className="container-x max-w-2xl text-center">
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-white">Join Our Newsletter</h2>
          <p className="text-brand-200 mt-2 mb-6">Get early access to new collections, exclusive offers and helpful guides — straight to your inbox.</p>
          <NewsletterForm />
        </div>
      </section>
    </div>
  );
}
