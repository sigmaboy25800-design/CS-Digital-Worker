"use client";

import Link from "next/link";
import { useStore } from "@/components/Providers";
import { EmptyState, Spinner } from "@/components/ui";
import { formatPrice } from "@/lib/utils";

export default function WishlistPage() {
  const { wishlist, hydrated, toggleWishlist, addToCart } = useStore();

  if (!hydrated) {
    return <div className="container-x py-16 flex justify-center"><Spinner className="h-8 w-8 text-brand-700" /></div>;
  }

  if (wishlist.length === 0) {
    return (
      <div className="container-x py-8">
        <EmptyState icon="❤" title="Your wishlist is empty" text="Save your favorite pieces here so you never lose track of them. Tap the heart icon on any product to add it.">
          <Link href="/shop" className="btn-primary btn-md">Discover Products</Link>
          <Link href="/shop?flag=new" className="btn-outline btn-md">New Arrivals</Link>
        </EmptyState>
      </div>
    );
  }

  return (
    <div className="container-x py-8">
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900 mb-2">My Wishlist</h1>
      <p className="text-slate-500 mb-8">{wishlist.length} saved item{wishlist.length > 1 ? "s" : ""}</p>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
        {wishlist.map((item) => (
          <div key={item.productId} className="card card-hover overflow-hidden flex flex-col">
            <Link href={`/product/${item.slug}`} className="relative aspect-[3/4] bg-slate-100">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={item.image} alt={item.name} loading="lazy" className="h-full w-full object-cover" />
            </Link>
            <div className="p-3.5 flex flex-col gap-2 flex-1">
              <Link href={`/product/${item.slug}`} className="text-sm font-semibold text-slate-800 hover:text-brand-700 line-clamp-2">{item.name}</Link>
              <p className="font-bold text-brand-800">{formatPrice(item.price)}</p>
              <button
                onClick={() => addToCart({ productId: item.productId, slug: item.slug, name: item.name, image: item.image, price: item.price, oldPrice: item.oldPrice, qty: 1, stock: 99 })}
                className="btn-primary btn-sm w-full mt-auto"
              >
                Add to Cart
              </button>
              <button onClick={() => toggleWishlist(item)} className="text-xs text-rose-500 hover:text-rose-700 underline">
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
