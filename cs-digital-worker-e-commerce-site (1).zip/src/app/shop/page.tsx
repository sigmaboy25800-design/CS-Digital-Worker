import type { Metadata } from "next";
import ShopListing, { type ShopSearchParams } from "@/components/ShopListing";
import { Breadcrumbs } from "@/components/ui";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Shop All Products",
  description:
    "Browse the full CS Digital Worker collection — 2 & 3 piece suits, lawn, embroidered, printed, dupattas and trousers. Filter by price, size, color and more.",
  alternates: { canonical: "/shop" },
};

const FLAG_TITLES: Record<string, { title: string; subtitle: string }> = {
  new: { title: "New Arrivals", subtitle: "The latest additions to our collection" },
  bestseller: { title: "Best Sellers", subtitle: "Most loved products by our customers" },
  sale: { title: "Sale & Special Offers", subtitle: "Limited-time deals with real discounts" },
  featured: { title: "Featured Products", subtitle: "Handpicked pieces our team recommends" },
};

export default async function ShopPage({
  searchParams,
}: {
  searchParams: Promise<ShopSearchParams>;
}) {
  const sp = await searchParams;
  const flag = typeof sp.flag === "string" ? sp.flag : undefined;
  const heading = flag && FLAG_TITLES[flag] ? FLAG_TITLES[flag] : { title: "Shop All Products", subtitle: "Premium fashion, honest prices, nationwide delivery" };

  return (
    <div className="container-x py-8">
      <Breadcrumbs items={[{ label: heading.title }]} />
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900">{heading.title}</h1>
      <p className="text-slate-500 mt-1.5 mb-8">{heading.subtitle}</p>
      <ShopListing searchParams={sp} basePath="/shop" />
    </div>
  );
}
