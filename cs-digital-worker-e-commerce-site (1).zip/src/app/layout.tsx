import type { Metadata } from "next";
import type { ReactNode } from "react";
import Script from "next/script";
import "./globals.css";
import Providers from "@/components/Providers";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { getSettings, getActiveCategories } from "@/lib/shop";
import { CONTACT, SITE_URL, SOCIALS } from "@/lib/utils";

export async function generateMetadata(): Promise<Metadata> {
  const settings = await getSettings();
  return {
    metadataBase: new URL(SITE_URL),
    title: {
      default: settings.seoTitle,
      template: "%s | CS Digital Worker",
    },
    description: settings.seoDescription,
    icons: { icon: "/favicon.svg" },
    openGraph: {
      siteName: "CS Digital Worker",
      title: settings.seoTitle,
      description: settings.seoDescription,
      type: "website",
      images: ["/images/hero.jpg"],
    },
    twitter: { card: "summary_large_image" },
    verification: settings.googleSiteVerification
      ? { google: settings.googleSiteVerification }
      : undefined,
    alternates: { canonical: "/" },
  };
}

export default async function RootLayout({ children }: { children: ReactNode }) {
  const [settings, categories] = await Promise.all([getSettings(), getActiveCategories()]);
  const announcement =
    settings.announcementEnabled === "1" && settings.announcement ? settings.announcement : null;

  const orgSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "CS Digital Worker",
    url: SITE_URL,
    logo: `${SITE_URL}/favicon.svg`,
    email: CONTACT.email,
    telephone: CONTACT.phone,
    sameAs: [SOCIALS.facebook, SOCIALS.tiktok, SOCIALS.instagram],
    contactPoint: {
      "@type": "ContactPoint",
      telephone: CONTACT.phone,
      contactType: "customer service",
      email: CONTACT.email,
    },
  };

  return (
    <html lang="en">
      <body className="bg-slate-50 text-slate-900 antialiased min-h-screen flex flex-col">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(orgSchema) }}
        />
        {settings.ga4Id && (
          <>
            <Script src={`https://www.googletagmanager.com/gtag/js?id=${settings.ga4Id}`} strategy="afterInteractive" />
            <Script id="ga4" strategy="afterInteractive">
              {`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${settings.ga4Id}');`}
            </Script>
          </>
        )}
        {settings.gtmId && (
          <Script id="gtm" strategy="afterInteractive">
            {`(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','${settings.gtmId}');`}
          </Script>
        )}
        {settings.metaPixelId && (
          <Script id="meta-pixel" strategy="afterInteractive">
            {`!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','${settings.metaPixelId}');fbq('track','PageView');`}
          </Script>
        )}
        <Providers>
          <Header
            categories={categories.map((c) => ({ name: c.name, slug: c.slug }))}
            announcement={announcement}
          />
          <main id="main-content" className="flex-1">{children}</main>
          <Footer
            categories={categories.map((c) => ({ name: c.name, slug: c.slug }))}
            settings={settings}
          />
          {/* WhatsApp floating button */}
          <a
            href={CONTACT.whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Chat with us on WhatsApp"
            className="no-print fixed bottom-5 right-5 z-[70] h-14 w-14 rounded-full bg-emerald-500 hover:bg-emerald-600 shadow-lg hover:shadow-xl inline-flex items-center justify-center transition-all hover:scale-105"
          >
            <svg width="30" height="30" viewBox="0 0 24 24" fill="#fff" aria-hidden="true">
              <path d="M12 2a10 10 0 00-8.6 15.1L2 22l5-1.3A10 10 0 1012 2zm0 18.2c-1.6 0-3.1-.4-4.4-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1112 20.2zm4.6-6.1c-.3-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1-.2.3-.6.8-.8 1-.1.2-.3.2-.5.1-.3-.1-1.1-.4-2-1.2-.7-.7-1.2-1.5-1.4-1.7-.1-.3 0-.4.1-.5l.4-.5c.1-.2.2-.3.3-.5.1-.2 0-.4 0-.5l-.8-1.9c-.2-.5-.4-.4-.6-.4h-.5c-.2 0-.5.1-.7.3-.2.3-.9.9-.9 2.1 0 1.3.9 2.5 1 2.6.1.2 1.8 2.8 4.3 3.9.6.3 1.1.4 1.5.5.6.2 1.2.2 1.6.1.5-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.1-1.2 0-.1-.2-.2-.5-.3z" />
            </svg>
          </a>
        </Providers>
      </body>
    </html>
  );
}
