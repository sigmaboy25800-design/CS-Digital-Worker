import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { categories } from "@/db/schema";
import ShopListing, { type ShopSearchParams } from "@/components/ShopListing";
import { Breadcrumbs } from "@/components/ui";
import { SITE_URL } from "@/lib/utils";

export const dynamic = "force-dynamic";

async function getCategory(slug: string) {
  const rows = await db.select().from(categories).where(eq(categories.slug, slug)).limit(1);
  return rows[0] ?? null;
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const category = await getCategory(slug);
  if (!category) return { title: "Category Not Found" };
  return {
    title: `${category.name} — Shop Online`,
    description: category.description ?? `Shop ${category.name} at CS Digital Worker. Premium quality, cash on delivery and fast nationwide shipping.`,
    alternates: { canonical: `/category/${category.slug}` },
    openGraph: { title: category.name, description: category.description ?? undefined, images: category.image ? [category.image] : undefined },
  };
}

export default async function CategoryPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<ShopSearchParams>;
}) {
  const [{ slug }, sp] = await Promise.all([params, searchParams]);
  const category = await getCategory(slug);
  if (!category || !category.isActive) notFound();

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: SITE_URL },
      { "@type": "ListItem", position: 2, name: "Categories", item: `${SITE_URL}/categories` },
      { "@type": "ListItem", position: 3, name: category.name, item: `${SITE_URL}/category/${category.slug}` },
    ],
  };

  return (
    <div className="container-x py-8">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <Breadcrumbs items={[{ label: "Categories", href: "/categories" }, { label: category.name }]} />
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900">{category.name}</h1>
      {category.description && <p className="text-slate-500 mt-1.5 mb-8 max-w-2xl">{category.description}</p>}
      <div className="mt-6">
        <ShopListing searchParams={sp} basePath={`/category/${category.slug}`} fixedCategory={category.slug} />
      </div>
    </div>
  );
}
