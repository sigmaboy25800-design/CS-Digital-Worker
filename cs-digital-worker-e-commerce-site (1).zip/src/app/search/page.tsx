import type { Metadata } from "next";
import ShopListing, { type ShopSearchParams } from "@/components/ShopListing";
import { Breadcrumbs } from "@/components/ui";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Search Results",
  robots: { index: false },
};

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<ShopSearchParams>;
}) {
  const sp = await searchParams;
  const q = typeof sp.q === "string" ? sp.q : "";

  return (
    <div className="container-x py-8">
      <Breadcrumbs items={[{ label: "Search" }]} />
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900">
        {q ? <>Search results for &ldquo;{q}&rdquo;</> : "Search Products"}
      </h1>
      <p className="text-slate-500 mt-1.5 mb-8">
        {q ? "Here's what we found in our collection." : "Use the search icon in the header to find products."}
      </p>
      <ShopListing searchParams={sp} basePath="/search" />
    </div>
  );
}
