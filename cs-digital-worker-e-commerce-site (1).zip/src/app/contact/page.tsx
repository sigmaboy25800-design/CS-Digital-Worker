"use client";

import { useState } from "react";
import { Breadcrumbs, Spinner } from "@/components/ui";
import { CONTACT, SOCIALS } from "@/lib/utils";

export default function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", subject: "", message: "", website: "" });
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [feedback, setFeedback] = useState("");

  const set = (key: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("loading");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (res.ok) { setStatus("done"); setFeedback(data.message); }
      else { setStatus("error"); setFeedback(data.error); }
    } catch {
      setStatus("error");
      setFeedback("Network error. Please try again.");
    }
  };

  return (
    <div className="container-x py-10">
      <Breadcrumbs items={[{ label: "Contact Us" }]} />
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900">Contact Us</h1>
      <p className="text-slate-500 mt-2 mb-8">We usually reply within 24 hours — WhatsApp is the fastest way to reach us.</p>

      <div className="grid lg:grid-cols-2 gap-8">
        <div className="space-y-4">
          <a href={CONTACT.phoneHref} className="card card-hover p-5 flex items-center gap-4">
            <span className="h-12 w-12 rounded-xl bg-brand-50 text-2xl flex items-center justify-center" aria-hidden>📞</span>
            <div>
              <p className="font-bold text-slate-900">Call Us</p>
              <p className="text-sm text-brand-700 font-semibold">{CONTACT.phone}</p>
            </div>
          </a>
          <a href={CONTACT.whatsappHref} target="_blank" rel="noopener noreferrer" className="card card-hover p-5 flex items-center gap-4">
            <span className="h-12 w-12 rounded-xl bg-emerald-50 text-2xl flex items-center justify-center" aria-hidden>💬</span>
            <div>
              <p className="font-bold text-slate-900">WhatsApp Us</p>
              <p className="text-sm text-emerald-600 font-semibold">{CONTACT.phone} — chat now</p>
            </div>
          </a>
          <a href={CONTACT.emailHref} className="card card-hover p-5 flex items-center gap-4">
            <span className="h-12 w-12 rounded-xl bg-gold-500/10 text-2xl flex items-center justify-center" aria-hidden>✉️</span>
            <div>
              <p className="font-bold text-slate-900">Email Us</p>
              <p className="text-sm text-brand-700 font-semibold break-all">{CONTACT.email}</p>
            </div>
          </a>
          <div className="card p-5">
            <p className="font-bold text-slate-900 mb-3">Follow Us</p>
            <div className="flex flex-wrap gap-3 text-sm font-semibold">
              <a href={SOCIALS.facebook} target="_blank" rel="noopener noreferrer" className="text-brand-700 hover:underline">Facebook ↗</a>
              <a href={SOCIALS.tiktok} target="_blank" rel="noopener noreferrer" className="text-brand-700 hover:underline">TikTok ↗</a>
              <a href={SOCIALS.instagram} target="_blank" rel="noopener noreferrer" className="text-brand-700 hover:underline">Instagram ↗</a>
            </div>
          </div>
          <div className="card p-5 text-sm text-slate-500">
            <p className="font-bold text-slate-900 mb-1">Support Hours</p>
            <p>Monday – Saturday: 10:00 AM – 8:00 PM (PKT)</p>
            <p>Order tracking is available 24/7 on the <a href="/track-order" className="text-brand-700 underline">Track Order</a> page.</p>
          </div>
        </div>

        <div>
          {status === "done" ? (
            <div className="card p-8 text-center">
              <p className="text-5xl mb-3" aria-hidden>✅</p>
              <h2 className="font-display text-xl font-bold text-slate-900 mb-2">Message Sent!</h2>
              <p className="text-slate-500">{feedback}</p>
            </div>
          ) : (
            <form onSubmit={submit} className="card p-6 space-y-4">
              <h2 className="font-display text-xl font-bold text-slate-900">Send a Message</h2>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="c-name" className="label">Name *</label>
                  <input id="c-name" required value={form.name} onChange={set("name")} className="input" />
                </div>
                <div>
                  <label htmlFor="c-email" className="label">Email *</label>
                  <input id="c-email" type="email" required value={form.email} onChange={set("email")} className="input" />
                </div>
                <div>
                  <label htmlFor="c-phone" className="label">Phone</label>
                  <input id="c-phone" type="tel" value={form.phone} onChange={set("phone")} className="input" />
                </div>
                <div>
                  <label htmlFor="c-subject" className="label">Subject</label>
                  <input id="c-subject" value={form.subject} onChange={set("subject")} className="input" placeholder="Order help, product question…" />
                </div>
              </div>
              {/* Honeypot — hidden from humans */}
              <input type="text" value={form.website} onChange={set("website")} className="hidden" tabIndex={-1} autoComplete="off" aria-hidden="true" />
              <div>
                <label htmlFor="c-message" className="label">Message *</label>
                <textarea id="c-message" required rows={5} value={form.message} onChange={set("message")} className="input" />
              </div>
              {status === "error" && <p className="text-sm text-rose-600" role="alert">{feedback}</p>}
              <button type="submit" disabled={status === "loading"} className="btn-primary btn-lg w-full">
                {status === "loading" ? <Spinner /> : "Send Message"}
              </button>
              <p className="text-xs text-slate-400">Your details are used only to respond to your inquiry. See our Privacy Policy.</p>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
