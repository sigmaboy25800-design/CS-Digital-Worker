import type { Metadata } from "next";
import Link from "next/link";
import { getActiveCategories } from "@/lib/shop";
import { Breadcrumbs } from "@/components/ui";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "All Categories",
  description: "Explore all product categories at CS Digital Worker — 2 & 3 piece suits, lawn, Arabic lawn, printed, embroidered, dupattas and trousers.",
  alternates: { canonical: "/categories" },
};

export default async function CategoriesPage() {
  const categories = await getActiveCategories();

  return (
    <div className="container-x py-8">
      <Breadcrumbs items={[{ label: "Categories" }]} />
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900">All Categories</h1>
      <p className="text-slate-500 mt-1.5 mb-8">Find exactly what you&apos;re looking for in our curated collections.</p>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
        {categories.map((c) => (
          <Link key={c.id} href={`/category/${c.slug}`} className="group card card-hover overflow-hidden">
            <div className="relative aspect-[4/3] overflow-hidden bg-slate-100">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={c.image ?? "/images/hero.jpg"} alt={c.name} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
            </div>
            <div className="p-4">
              <h2 className="font-display font-bold text-slate-900 group-hover:text-brand-700">{c.name}</h2>
              {c.description && <p className="text-xs text-slate-500 mt-1 line-clamp-2">{c.description}</p>}
            </div>
          </Link>
        ))}
        <Link href="/shop?flag=new" className="group card card-hover overflow-hidden bg-gradient-to-br from-brand-700 to-brand-950 flex items-center justify-center min-h-40">
          <span className="text-white font-display font-bold text-xl text-center p-4">New Arrivals →</span>
        </Link>
        <Link href="/shop?flag=sale" className="group card card-hover overflow-hidden bg-gradient-to-br from-rose-500 to-rose-800 flex items-center justify-center min-h-40">
          <span className="text-white font-display font-bold text-xl text-center p-4">Sale →</span>
        </Link>
      </div>
    </div>
  );
}
