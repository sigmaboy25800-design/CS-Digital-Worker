"use client";

import { useParams, useSearchParams } from "next/navigation";
import { Suspense, useCallback, useEffect, useMemo, useState } from "react";
import { useStore } from "@/components/Providers";
import { Spinner } from "@/components/ui";
import { formatDate, formatPrice, ORDER_STATUSES, STATUS_COLORS, STATUS_LABELS } from "@/lib/utils";

/* eslint-disable @typescript-eslint/no-explicit-any */
type Row = Record<string, any>;
type Field = {
  name: string; label: string;
  type?: "text" | "number" | "textarea" | "checkbox" | "select" | "csv" | "lines" | "date" | "specs";
  options?: { value: string; label: string }[];
  optionsFrom?: "categories";
  placeholder?: string;
  half?: boolean;
};

const BLOG_CATEGORIES = ["Digital Marketing", "SEO", "AI Tools", "E-Commerce", "Online Business", "Fashion", "Shopping Guides", "Product Guides", "Tutorials"];

const CONFIG: Record<string, {
  title: string; canCreate: boolean; canEdit: boolean; canDelete: boolean; searchable?: boolean;
  columns: { key: string; label: string; render?: (r: Row) => React.ReactNode }[];
  fields?: Field[];
}> = {
  products: {
    title: "Products", canCreate: true, canEdit: true, canDelete: true, searchable: true,
    columns: [
      { key: "image", label: "", render: (r) => r.images?.[0] ? <img src={r.images[0]} alt="" className="h-12 w-9 object-cover rounded" /> : null },
      { key: "name", label: "Name" },
      { key: "sku", label: "SKU" },
      { key: "price", label: "Price", render: (r) => formatPrice(r.price) },
      { key: "stock", label: "Stock", render: (r) => <span className={r.stock === 0 ? "text-rose-600 font-bold" : r.stock <= 5 ? "text-amber-600 font-bold" : ""}>{r.stock}</span> },
      { key: "flags", label: "Flags", render: (r) => [r.isFeatured && "Featured", r.isNewArrival && "New", r.isBestSeller && "Best", r.onSale && "Sale", !r.isActive && "Hidden"].filter(Boolean).join(", ") },
    ],
    fields: [
      { name: "name", label: "Name" },
      { name: "slug", label: "Slug (auto if blank)", half: true },
      { name: "sku", label: "SKU", half: true },
      { name: "price", label: "Price (Rs.)", type: "number", half: true },
      { name: "oldPrice", label: "Old Price (Rs.)", type: "number", half: true },
      { name: "stock", label: "Stock", type: "number", half: true },
      { name: "categoryId", label: "Category", type: "select", optionsFrom: "categories", half: true },
      { name: "sizes", label: "Sizes (comma separated)", type: "csv", half: true },
      { name: "colors", label: "Colors (comma separated)", type: "csv", half: true },
      { name: "tags", label: "Tags (comma separated)", type: "csv" },
      { name: "images", label: "Image URLs (one per line)", type: "lines" },
      { name: "imageAlt", label: "Image ALT text" },
      { name: "description", label: "Description", type: "textarea" },
      { name: "specifications", label: "Specifications (one per line, Label: Value)", type: "specs" },
      { name: "fabric", label: "Fabric / Material", half: true },
      { name: "care", label: "Care Instructions", half: true },
      { name: "seoTitle", label: "SEO Title", half: true },
      { name: "seoDescription", label: "SEO Meta Description", half: true },
      { name: "isFeatured", label: "Featured", type: "checkbox", half: true },
      { name: "isNewArrival", label: "New Arrival", type: "checkbox", half: true },
      { name: "isBestSeller", label: "Best Seller", type: "checkbox", half: true },
      { name: "onSale", label: "On Sale", type: "checkbox", half: true },
      { name: "isActive", label: "Active (visible in store)", type: "checkbox", half: true },
    ],
  },
  categories: {
    title: "Categories", canCreate: true, canEdit: true, canDelete: true,
    columns: [
      { key: "sortOrder", label: "#" },
      { key: "name", label: "Name" },
      { key: "slug", label: "Slug" },
      { key: "isActive", label: "Active", render: (r) => (r.isActive ? "✓" : "✕") },
    ],
    fields: [
      { name: "name", label: "Name", half: true },
      { name: "slug", label: "Slug (auto if blank)", half: true },
      { name: "description", label: "Description", type: "textarea" },
      { name: "image", label: "Image URL" },
      { name: "sortOrder", label: "Sort Order (for reordering)", type: "number", half: true },
      { name: "isActive", label: "Active", type: "checkbox", half: true },
    ],
  },
  coupons: {
    title: "Coupons", canCreate: true, canEdit: true, canDelete: true,
    columns: [
      { key: "code", label: "Code" },
      { key: "type", label: "Type", render: (r) => (r.type === "percent" ? `${r.value}% off` : `Rs. ${r.value} off`) },
      { key: "minOrder", label: "Min Order", render: (r) => formatPrice(r.minOrder) },
      { key: "usedCount", label: "Used", render: (r) => `${r.usedCount}${r.usageLimit ? `/${r.usageLimit}` : ""}` },
      { key: "expiresAt", label: "Expires", render: (r) => (r.expiresAt ? formatDate(r.expiresAt) : "Never") },
      { key: "isActive", label: "Active", render: (r) => (r.isActive ? "✓" : "✕") },
    ],
    fields: [
      { name: "code", label: "Coupon Code", half: true },
      { name: "type", label: "Type", type: "select", options: [{ value: "percent", label: "Percentage %" }, { value: "fixed", label: "Fixed Amount (Rs.)" }], half: true },
      { name: "value", label: "Value (% or Rs.)", type: "number", half: true },
      { name: "minOrder", label: "Minimum Order (Rs.)", type: "number", half: true },
      { name: "maxDiscount", label: "Max Discount (Rs., optional)", type: "number", half: true },
      { name: "usageLimit", label: "Usage Limit (optional)", type: "number", half: true },
      { name: "expiresAt", label: "Expiry Date (optional)", type: "date", half: true },
      { name: "categoryId", label: "Restrict to Category (optional)", type: "select", optionsFrom: "categories", half: true },
      { name: "productId", label: "Restrict to Product ID (optional)", type: "number", half: true },
      { name: "isActive", label: "Active", type: "checkbox", half: true },
    ],
  },
  blog: {
    title: "Blog Posts", canCreate: true, canEdit: true, canDelete: true,
    columns: [
      { key: "title", label: "Title" },
      { key: "category", label: "Category" },
      { key: "publishedAt", label: "Published", render: (r) => formatDate(r.publishedAt) },
      { key: "isPublished", label: "Live", render: (r) => (r.isPublished ? "✓" : "Draft") },
    ],
    fields: [
      { name: "title", label: "Title" },
      { name: "slug", label: "URL Slug (auto if blank)", half: true },
      { name: "category", label: "Category", type: "select", options: BLOG_CATEGORIES.map((c) => ({ value: c, label: c })), half: true },
      { name: "excerpt", label: "Excerpt", type: "textarea" },
      { name: "content", label: "Content (use '## ' for headings, blank line between paragraphs)", type: "textarea" },
      { name: "image", label: "Featured Image URL" },
      { name: "imageAlt", label: "Image ALT text", half: true },
      { name: "author", label: "Author", half: true },
      { name: "tags", label: "Tags (comma separated)", type: "csv" },
      { name: "seoTitle", label: "SEO Title", half: true },
      { name: "seoDescription", label: "SEO Meta Description", half: true },
      { name: "isPublished", label: "Published", type: "checkbox" },
    ],
  },
  customers: {
    title: "Customers", canCreate: false, canEdit: false, canDelete: false, searchable: true,
    columns: [
      { key: "name", label: "Name" },
      { key: "email", label: "Email" },
      { key: "phone", label: "Phone" },
      { key: "orderCount", label: "Orders" },
      { key: "totalSpent", label: "Total Spent", render: (r) => formatPrice(r.totalSpent ?? 0) },
      { key: "createdAt", label: "Joined", render: (r) => formatDate(r.createdAt) },
    ],
  },
  messages: {
    title: "Contact Messages", canCreate: false, canEdit: false, canDelete: true,
    columns: [
      { key: "name", label: "Name" },
      { key: "email", label: "Email" },
      { key: "subject", label: "Subject" },
      { key: "message", label: "Message", render: (r) => <span className="line-clamp-2 max-w-xs block">{r.message}</span> },
      { key: "createdAt", label: "Date", render: (r) => formatDate(r.createdAt) },
    ],
  },
  subscribers: {
    title: "Newsletter Subscribers", canCreate: false, canEdit: false, canDelete: false,
    columns: [
      { key: "email", label: "Email" },
      { key: "createdAt", label: "Subscribed", render: (r) => formatDate(r.createdAt) },
    ],
  },
};

function AdminSectionInner() {
  const { section } = useParams<{ section: string }>();
  const sp = useSearchParams();
  const { toast } = useStore();
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState(sp.get("status") ?? "");
  const [editing, setEditing] = useState<Row | null>(null);
  const [creating, setCreating] = useState(false);
  const [deleting, setDeleting] = useState<Row | null>(null);
  const [categories, setCategories] = useState<{ id: number; name: string }[]>([]);
  const [orderDetail, setOrderDetail] = useState<{ order: Row; items: Row[] } | null>(null);
  const [settings, setSettings] = useState<Record<string, string>>({});

  const isOrders = section === "orders";
  const isReviews = section === "reviews";
  const isSettings = section === "settings";
  const config = CONFIG[section];

  const load = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    if (statusFilter) params.set("status", statusFilter);
    const res = await fetch(`/api/admin/${section}?${params}`);
    const data = await res.json();
    if (res.ok) {
      if (isSettings) setSettings(data.settings ?? {});
      else setRows(data.rows ?? []);
    } else toast(data.error ?? "Failed to load", "error");
    setLoading(false);
  }, [section, search, statusFilter, isSettings, toast]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (section === "products" || section === "coupons") {
      fetch("/api/admin/categories").then((r) => r.json()).then((d) => setCategories(d.rows ?? []));
    }
  }, [section]);

  const save = async (values: Row, id?: number) => {
    const res = await fetch(id ? `/api/admin/${section}/${id}` : `/api/admin/${section}`, {
      method: id ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    const data = await res.json();
    if (res.ok) {
      toast(id ? "Saved changes" : "Created successfully");
      setEditing(null); setCreating(false);
      load();
    } else toast(data.error ?? "Save failed", "error");
  };

  const remove = async (row: Row) => {
    const res = await fetch(`/api/admin/${section}/${row.id}`, { method: "DELETE" });
    if (res.ok) { toast("Deleted"); setDeleting(null); load(); }
    else toast("Delete failed", "error");
  };

  const patch = async (id: number, body: Row) => {
    const res = await fetch(`/api/admin/${section}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (res.ok) { toast("Updated"); load(); }
    else toast("Update failed", "error");
  };

  if (!config && !isOrders && !isReviews && !isSettings) {
    return <p className="text-slate-500">Unknown admin section.</p>;
  }

  // ---------- Settings ----------
  if (isSettings) return <SettingsForm settings={settings} loading={loading} onSave={async (vals) => {
    const res = await fetch("/api/admin/settings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(vals) });
    if (res.ok) toast("Settings saved"); else toast("Save failed", "error");
  }} />;

  // ---------- Orders ----------
  if (isOrders) {
    return (
      <div>
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 mb-4">Orders</h1>
        <div className="flex flex-wrap gap-3 mb-4">
          <form onSubmit={(e) => { e.preventDefault(); load(); }} className="flex gap-2">
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search order #, name, email…" className="input !w-64" aria-label="Search orders" />
            <button className="btn-primary btn-md">Search</button>
          </form>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="input !w-auto" aria-label="Filter by status">
            <option value="">All statuses</option>
            {ORDER_STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABELS[s]}</option>)}
          </select>
        </div>
        {loading ? <div className="py-16 flex justify-center"><Spinner className="h-8 w-8 text-brand-700" /></div> : (
          <div className="card overflow-x-auto">
            <table className="w-full text-sm min-w-[760px]">
              <thead>
                <tr className="border-b border-slate-100 text-left text-xs uppercase text-slate-400">
                  <th className="px-4 py-3">Order</th><th className="px-4 py-3">Customer</th><th className="px-4 py-3">Date</th>
                  <th className="px-4 py-3">Total</th><th className="px-4 py-3">Payment</th><th className="px-4 py-3">Status</th><th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody>
                {rows.map((o) => (
                  <tr key={o.id} className="border-b border-slate-50">
                    <td className="px-4 py-2.5 font-semibold">
                      {o.orderNumber}
                      {o.cancelRequested && <span className="block text-[10px] text-amber-600">cancel requested</span>}
                    </td>
                    <td className="px-4 py-2.5">
                      <p className="text-slate-700">{o.fullName}</p>
                      <p className="text-xs text-slate-400">{o.phone}</p>
                    </td>
                    <td className="px-4 py-2.5 text-slate-500">{formatDate(o.createdAt)}</td>
                    <td className="px-4 py-2.5 font-bold text-brand-800">{formatPrice(o.total)}</td>
                    <td className="px-4 py-2.5 text-slate-500">{o.paymentMethod === "cod" ? "COD" : "Bank"}</td>
                    <td className="px-4 py-2.5">
                      <select
                        value={o.status}
                        onChange={(e) => patch(o.id, { status: e.target.value })}
                        className={`rounded-lg text-xs font-bold px-2 py-1.5 border border-slate-200 ${STATUS_COLORS[o.status]}`}
                        aria-label={`Status for ${o.orderNumber}`}
                      >
                        {ORDER_STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABELS[s]}</option>)}
                      </select>
                    </td>
                    <td className="px-4 py-2.5">
                      <button onClick={async () => {
                        const res = await fetch(`/api/admin/orders/${o.id}`);
                        const d = await res.json();
                        if (res.ok) setOrderDetail(d);
                      }} className="text-brand-700 font-semibold hover:underline">View</button>
                    </td>
                  </tr>
                ))}
                {rows.length === 0 && <tr><td colSpan={7} className="px-4 py-10 text-center text-slate-400">No orders found.</td></tr>}
              </tbody>
            </table>
          </div>
        )}
        {orderDetail && <OrderModal detail={orderDetail} onClose={() => setOrderDetail(null)} />}
      </div>
    );
  }

  // ---------- Reviews ----------
  if (isReviews) {
    return (
      <div>
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 mb-4">Reviews Moderation</h1>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="input !w-auto mb-4" aria-label="Filter reviews">
          <option value="">All</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
        </select>
        {loading ? <div className="py-16 flex justify-center"><Spinner className="h-8 w-8 text-brand-700" /></div> : (
          <div className="space-y-3">
            {rows.length === 0 && <p className="card p-8 text-center text-slate-400">No reviews found.</p>}
            {rows.map((r) => (
              <div key={r.id} className="card p-5">
                <div className="flex flex-wrap justify-between gap-2">
                  <div>
                    <p className="font-bold text-slate-900">{"★".repeat(r.rating)}{"☆".repeat(5 - r.rating)} — {r.title || "(no title)"}</p>
                    <p className="text-sm text-slate-600 mt-1">{r.comment}</p>
                    <p className="text-xs text-slate-400 mt-2">{r.name} • on <strong>{r.productName}</strong> • {formatDate(r.createdAt)}</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${r.status === "approved" ? "bg-emerald-100 text-emerald-700" : r.status === "rejected" ? "bg-rose-100 text-rose-700" : "bg-amber-100 text-amber-700"}`}>{r.status}</span>
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  {r.status !== "approved" && <button onClick={() => patch(r.id, { status: "approved" })} className="btn btn-sm bg-emerald-600 text-white hover:bg-emerald-700">Approve</button>}
                  {r.status !== "rejected" && <button onClick={() => patch(r.id, { status: "rejected" })} className="btn btn-sm bg-amber-500 text-white hover:bg-amber-600">Reject</button>}
                  <button onClick={() => setDeleting(r)} className="btn-danger btn-sm">Delete</button>
                </div>
              </div>
            ))}
          </div>
        )}
        {deleting && <ConfirmDelete row={deleting} onCancel={() => setDeleting(null)} onConfirm={() => remove(deleting)} />}
      </div>
    );
  }

  // ---------- Generic CRUD ----------
  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900">{config.title}</h1>
        {config.canCreate && <button onClick={() => setCreating(true)} className="btn-primary btn-md">+ Add New</button>}
      </div>
      {config.searchable && (
        <form onSubmit={(e) => { e.preventDefault(); load(); }} className="flex gap-2 mb-4">
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search…" className="input !w-64" aria-label={`Search ${config.title}`} />
          <button className="btn-primary btn-md">Search</button>
        </form>
      )}
      {loading ? <div className="py-16 flex justify-center"><Spinner className="h-8 w-8 text-brand-700" /></div> : (
        <div className="card overflow-x-auto">
          <table className="w-full text-sm min-w-[640px]">
            <thead>
              <tr className="border-b border-slate-100 text-left text-xs uppercase text-slate-400">
                {config.columns.map((c) => <th key={c.key} className="px-4 py-3">{c.label}</th>)}
                {(config.canEdit || config.canDelete) && <th className="px-4 py-3"></th>}
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id} className="border-b border-slate-50">
                  {config.columns.map((c) => (
                    <td key={c.key} className="px-4 py-2.5 text-slate-700">{c.render ? c.render(r) : String(r[c.key] ?? "")}</td>
                  ))}
                  {(config.canEdit || config.canDelete) && (
                    <td className="px-4 py-2.5 whitespace-nowrap">
                      {config.canEdit && <button onClick={() => setEditing(r)} className="text-brand-700 font-semibold hover:underline mr-3">Edit</button>}
                      {config.canDelete && <button onClick={() => setDeleting(r)} className="text-rose-500 font-semibold hover:underline">Delete</button>}
                    </td>
                  )}
                </tr>
              ))}
              {rows.length === 0 && <tr><td colSpan={config.columns.length + 1} className="px-4 py-10 text-center text-slate-400">No records yet.</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {(creating || editing) && config.fields && (
        <FormModal
          title={editing ? `Edit ${config.title.slice(0, -1)}` : `New ${config.title.slice(0, -1)}`}
          fields={config.fields}
          categories={categories}
          initial={editing ?? {}}
          onClose={() => { setCreating(false); setEditing(null); }}
          onSave={(vals) => save(vals, editing?.id)}
        />
      )}
      {deleting && <ConfirmDelete row={deleting} onCancel={() => setDeleting(null)} onConfirm={() => remove(deleting)} />}
    </div>
  );
}

function FormModal({ title, fields, initial, categories, onClose, onSave }: {
  title: string; fields: Field[]; initial: Row; categories: { id: number; name: string }[];
  onClose: () => void; onSave: (vals: Row) => void;
}) {
  const init = useMemo(() => {
    const v: Row = {};
    for (const f of fields) {
      const raw = initial[f.name];
      if (f.type === "csv") v[f.name] = Array.isArray(raw) ? raw.join(", ") : "";
      else if (f.type === "lines") v[f.name] = Array.isArray(raw) ? raw.join("\n") : "";
      else if (f.type === "specs") v[f.name] = Array.isArray(raw) ? raw.map((s: Row) => `${s.label}: ${s.value}`).join("\n") : "";
      else if (f.type === "checkbox") v[f.name] = raw === undefined ? (f.name === "isActive" || f.name === "isPublished") : Boolean(raw);
      else if (f.type === "date") v[f.name] = raw ? String(raw).slice(0, 10) : "";
      else v[f.name] = raw ?? "";
    }
    return v;
  }, [fields, initial]);
  const [values, setValues] = useState<Row>(init);
  const [saving, setSaving] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const out: Row = {};
    for (const f of fields) {
      const raw = values[f.name];
      if (f.type === "csv") out[f.name] = String(raw).split(",").map((s: string) => s.trim()).filter(Boolean);
      else if (f.type === "lines") out[f.name] = String(raw).split("\n").map((s: string) => s.trim()).filter(Boolean);
      else if (f.type === "specs") out[f.name] = String(raw).split("\n").map((line: string) => {
        const idx = line.indexOf(":");
        return idx > 0 ? { label: line.slice(0, idx).trim(), value: line.slice(idx + 1).trim() } : null;
      }).filter(Boolean);
      else out[f.name] = raw === "" ? null : raw;
    }
    await onSave(out);
    setSaving(false);
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-start justify-center p-4 overflow-y-auto" role="dialog" aria-modal="true" aria-label={title}>
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <form onSubmit={submit} className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl my-8 p-6">
        <div className="flex justify-between items-center mb-5">
          <h2 className="font-display text-xl font-bold text-slate-900">{title}</h2>
          <button type="button" onClick={onClose} aria-label="Close" className="text-slate-400 hover:text-slate-700 text-xl">✕</button>
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          {fields.map((f) => {
            const id = `f-${f.name}`;
            const wrap = f.half ? "" : "sm:col-span-2";
            if (f.type === "checkbox") return (
              <label key={f.name} className={`${wrap} flex items-center gap-2 text-sm font-medium text-slate-700`}>
                <input type="checkbox" checked={Boolean(values[f.name])} onChange={(e) => setValues({ ...values, [f.name]: e.target.checked })} className="accent-brand-700" />
                {f.label}
              </label>
            );
            if (f.type === "textarea" || f.type === "lines" || f.type === "specs") return (
              <div key={f.name} className={wrap}>
                <label htmlFor={id} className="label">{f.label}</label>
                <textarea id={id} rows={f.name === "content" ? 10 : 3} value={values[f.name]} onChange={(e) => setValues({ ...values, [f.name]: e.target.value })} className="input font-mono text-xs" />
              </div>
            );
            if (f.type === "select") {
              const opts = f.optionsFrom === "categories"
                ? [{ value: "", label: "— None —" }, ...categories.map((c) => ({ value: String(c.id), label: c.name }))]
                : f.options ?? [];
              return (
                <div key={f.name} className={wrap}>
                  <label htmlFor={id} className="label">{f.label}</label>
                  <select id={id} value={values[f.name] ?? ""} onChange={(e) => setValues({ ...values, [f.name]: e.target.value })} className="input">
                    {opts.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </select>
                </div>
              );
            }
            return (
              <div key={f.name} className={wrap}>
                <label htmlFor={id} className="label">{f.label}</label>
                <input id={id} type={f.type === "number" ? "number" : f.type === "date" ? "date" : "text"} value={values[f.name] ?? ""} onChange={(e) => setValues({ ...values, [f.name]: e.target.value })} className="input" placeholder={f.placeholder} />
              </div>
            );
          })}
        </div>
        <div className="flex gap-3 mt-6">
          <button type="submit" disabled={saving} className="btn-primary btn-md flex-1">{saving ? <Spinner className="h-4 w-4" /> : "Save"}</button>
          <button type="button" onClick={onClose} className="btn-outline btn-md flex-1">Cancel</button>
        </div>
      </form>
    </div>
  );
}

function ConfirmDelete({ row, onCancel, onConfirm }: { row: Row; onCancel: () => void; onConfirm: () => void }) {
  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-label="Confirm delete">
      <div className="absolute inset-0 bg-black/60" onClick={onCancel} />
      <div className="relative bg-white rounded-2xl p-6 max-w-sm w-full shadow-2xl">
        <h2 className="font-display text-xl font-bold text-slate-900">Delete this record?</h2>
        <p className="text-sm text-slate-500 mt-2">
          &ldquo;{row.name ?? row.title ?? row.code ?? row.email ?? `#${row.id}`}&rdquo; will be permanently deleted. This cannot be undone.
        </p>
        <div className="mt-5 flex gap-3">
          <button onClick={onConfirm} className="btn-danger btn-md flex-1">Delete</button>
          <button onClick={onCancel} className="btn-outline btn-md flex-1">Cancel</button>
        </div>
      </div>
    </div>
  );
}

function OrderModal({ detail, onClose }: { detail: { order: Row; items: Row[] }; onClose: () => void }) {
  const { order, items } = detail;
  const printInvoice = () => {
    const win = window.open("", "_blank", "width=800,height=900");
    if (!win) return;
    win.document.write(`<!DOCTYPE html><html><head><title>Invoice ${order.orderNumber}</title>
      <style>body{font-family:Arial,sans-serif;padding:32px;color:#0f172a}h1{font-size:20px}table{width:100%;border-collapse:collapse;margin-top:16px}th,td{border:1px solid #e2e8f0;padding:8px;text-align:left;font-size:13px}.tot{text-align:right;margin-top:16px;font-size:14px}</style>
      </head><body>
      <h1>CS Digital Worker — Invoice</h1>
      <p><strong>Order:</strong> ${order.orderNumber}<br/><strong>Date:</strong> ${new Date(order.createdAt).toLocaleDateString()}<br/>
      <strong>Customer:</strong> ${order.fullName} • ${order.phone} • ${order.email}<br/>
      <strong>Address:</strong> ${order.address}, ${order.city} ${order.postalCode ?? ""}<br/>
      <strong>Payment:</strong> ${order.paymentMethod === "cod" ? "Cash on Delivery" : "Bank Transfer"}</p>
      <table><tr><th>Item</th><th>Variant</th><th>Qty</th><th>Price</th><th>Total</th></tr>
      ${items.map((i) => `<tr><td>${i.name}</td><td>${[i.size, i.color].filter(Boolean).join(", ")}</td><td>${i.quantity}</td><td>Rs. ${i.price.toLocaleString()}</td><td>Rs. ${i.total.toLocaleString()}</td></tr>`).join("")}
      </table>
      <p class="tot">Subtotal: Rs. ${order.subtotal.toLocaleString()}<br/>
      ${order.discount > 0 ? `Discount${order.couponCode ? ` (${order.couponCode})` : ""}: −Rs. ${order.discount.toLocaleString()}<br/>` : ""}
      Shipping: Rs. ${order.shipping.toLocaleString()}<br/>
      <strong>Grand Total: Rs. ${order.total.toLocaleString()}</strong></p>
      <p style="margin-top:24px;font-size:12px;color:#64748b">CS Digital Worker • Phone/WhatsApp: 03228586255 • sigmaboy25800@gmail.com</p>
      <script>window.print()</script></body></html>`);
    win.document.close();
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-start justify-center p-4 overflow-y-auto" role="dialog" aria-modal="true" aria-label={`Order ${order.orderNumber}`}>
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-xl my-8 p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-display text-xl font-bold text-slate-900">Order {order.orderNumber}</h2>
          <button onClick={onClose} aria-label="Close" className="text-slate-400 hover:text-slate-700 text-xl">✕</button>
        </div>
        <p className="text-sm text-slate-500">{formatDate(order.createdAt)} • {order.paymentMethod === "cod" ? "Cash on Delivery" : "Bank Transfer"} • <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${STATUS_COLORS[order.status]}`}>{STATUS_LABELS[order.status]}</span></p>
        <div className="bg-slate-50 rounded-lg p-4 text-sm mt-4">
          <p className="font-semibold">{order.fullName} • {order.phone} • {order.email}</p>
          <p className="text-slate-600">{order.address}, {order.city} {order.postalCode}</p>
          {order.notes && <p className="text-slate-500 mt-1">Notes: {order.notes}</p>}
        </div>
        <ul className="divide-y divide-slate-100 mt-4">
          {items.map((i) => (
            <li key={i.id} className="py-2.5 flex justify-between text-sm gap-3">
              <span>{i.name} {[i.size, i.color].filter(Boolean).length > 0 && `(${[i.size, i.color].filter(Boolean).join(", ")})`} × {i.quantity}</span>
              <span className="font-semibold">{formatPrice(i.total)}</span>
            </li>
          ))}
        </ul>
        <dl className="mt-3 space-y-1 text-sm border-t border-slate-100 pt-3">
          <div className="flex justify-between"><dt className="text-slate-500">Subtotal</dt><dd>{formatPrice(order.subtotal)}</dd></div>
          {order.discount > 0 && <div className="flex justify-between text-emerald-600"><dt>Discount {order.couponCode && `(${order.couponCode})`}</dt><dd>−{formatPrice(order.discount)}</dd></div>}
          <div className="flex justify-between"><dt className="text-slate-500">Shipping</dt><dd>{formatPrice(order.shipping)}</dd></div>
          <div className="flex justify-between font-bold"><dt>Total</dt><dd className="text-brand-800">{formatPrice(order.total)}</dd></div>
        </dl>
        <button onClick={printInvoice} className="btn-primary btn-md w-full mt-5">🖨 Print Invoice</button>
      </div>
    </div>
  );
}

const SETTINGS_GROUPS: { title: string; fields: { key: string; label: string; type?: "textarea" | "checkbox" }[] }[] = [
  {
    title: "Branding & Homepage",
    fields: [
      { key: "storeName", label: "Store Name" },
      { key: "tagline", label: "Tagline" },
      { key: "heroHeading", label: "Hero Heading" },
      { key: "heroSubheading", label: "Hero Subheading", type: "textarea" },
      { key: "footerText", label: "Footer Description", type: "textarea" },
    ],
  },
  {
    title: "Announcement Bar",
    fields: [
      { key: "announcementEnabled", label: "Show announcement bar", type: "checkbox" },
      { key: "announcement", label: "Announcement text (offers, discounts, new arrivals, promotions)", type: "textarea" },
    ],
  },
  {
    title: "Contact & Social Media",
    fields: [
      { key: "contactPhone", label: "Phone" },
      { key: "contactWhatsapp", label: "WhatsApp Number" },
      { key: "contactEmail", label: "Email" },
      { key: "facebook", label: "Facebook URL" },
      { key: "tiktok", label: "TikTok URL" },
      { key: "instagram", label: "Instagram URL" },
      { key: "youtube", label: "YouTube URL (optional — leave blank to hide)" },
      { key: "pinterest", label: "Pinterest URL (optional — leave blank to hide)" },
    ],
  },
  {
    title: "Shipping & Payments",
    fields: [
      { key: "shippingFlatRate", label: "Flat Shipping Rate (Rs.)" },
      { key: "freeShippingThreshold", label: "Free Shipping Threshold (Rs.)" },
      { key: "codEnabled", label: "Cash on Delivery enabled", type: "checkbox" },
      { key: "bankTransferEnabled", label: "Bank Transfer enabled", type: "checkbox" },
      { key: "bankDetails", label: "Bank Transfer Instructions", type: "textarea" },
    ],
  },
  {
    title: "SEO, Google & Analytics",
    fields: [
      { key: "seoTitle", label: "Default SEO Title" },
      { key: "seoDescription", label: "Default Meta Description", type: "textarea" },
      { key: "googleSiteVerification", label: "Google Search Console Verification Code" },
      { key: "ga4Id", label: "Google Analytics 4 ID (G-XXXX) — leave blank to disable" },
      { key: "gtmId", label: "Google Tag Manager ID (GTM-XXXX)" },
      { key: "metaPixelId", label: "Meta Pixel ID" },
      { key: "merchantCenterNote", label: "Google Merchant Center / Ads notes", type: "textarea" },
    ],
  },
];

function SettingsForm({ settings, loading, onSave }: { settings: Record<string, string>; loading: boolean; onSave: (v: Record<string, string>) => Promise<void> }) {
  const [values, setValues] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  useEffect(() => { setValues(settings); }, [settings]);

  if (loading) return <div className="py-16 flex justify-center"><Spinner className="h-8 w-8 text-brand-700" /></div>;

  const defaults: Record<string, string> = {
    storeName: "CS Digital Worker", contactPhone: "03228586255", contactWhatsapp: "03228586255",
    contactEmail: "sigmaboy25800@gmail.com",
    facebook: "https://www.facebook.com/CSDigitalWorker/",
    tiktok: "https://www.tiktok.com/@csdigitalworker",
    instagram: "https://www.instagram.com/sigma_boy25800/",
    shippingFlatRate: "250", freeShippingThreshold: "5000",
    announcementEnabled: "1", codEnabled: "1", bankTransferEnabled: "1",
  };
  const get = (k: string) => values[k] ?? defaults[k] ?? "";

  return (
    <form
      onSubmit={async (e) => { e.preventDefault(); setSaving(true); await onSave(values); setSaving(false); }}
    >
      <div className="flex justify-between items-center mb-6">
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900">Website Settings</h1>
        <button type="submit" disabled={saving} className="btn-primary btn-md">{saving ? <Spinner className="h-4 w-4" /> : "Save All Settings"}</button>
      </div>
      <div className="space-y-6">
        {SETTINGS_GROUPS.map((g) => (
          <section key={g.title} className="card p-6">
            <h2 className="font-display text-lg font-bold text-slate-900 mb-4">{g.title}</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              {g.fields.map((f) => {
                const id = `s-${f.key}`;
                if (f.type === "checkbox") return (
                  <label key={f.key} className="flex items-center gap-2 text-sm font-medium text-slate-700 sm:col-span-2">
                    <input type="checkbox" checked={get(f.key) === "1"} onChange={(e) => setValues({ ...values, [f.key]: e.target.checked ? "1" : "0" })} className="accent-brand-700" />
                    {f.label}
                  </label>
                );
                if (f.type === "textarea") return (
                  <div key={f.key} className="sm:col-span-2">
                    <label htmlFor={id} className="label">{f.label}</label>
                    <textarea id={id} rows={2} value={get(f.key)} onChange={(e) => setValues({ ...values, [f.key]: e.target.value })} className="input" />
                  </div>
                );
                return (
                  <div key={f.key}>
                    <label htmlFor={id} className="label">{f.label}</label>
                    <input id={id} value={get(f.key)} onChange={(e) => setValues({ ...values, [f.key]: e.target.value })} className="input" />
                  </div>
                );
              })}
            </div>
          </section>
        ))}
      </div>
      <p className="text-xs text-slate-400 mt-4">
        Analytics IDs are optional — tracking scripts only load when a real ID is saved. Never paste placeholder/fake IDs.
      </p>
    </form>
  );
}

export default function AdminSectionPage() {
  return (
    <Suspense fallback={<div className="py-16 flex justify-center"><Spinner className="h-8 w-8 text-brand-700" /></div>}>
      <AdminSectionInner />
    </Suspense>
  );
}
