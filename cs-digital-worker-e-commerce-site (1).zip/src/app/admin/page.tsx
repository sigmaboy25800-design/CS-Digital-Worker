import Link from "next/link";
import { and, desc, eq, lte, sql } from "drizzle-orm";
import { db } from "@/db";
import { orders, products, reviews, users } from "@/db/schema";
import { formatDate, formatPrice, STATUS_COLORS, STATUS_LABELS } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function AdminDashboard() {
  const [revenue] = await db.select({ v: sql<number>`COALESCE(SUM(total),0)::int` }).from(orders).where(sql`status NOT IN ('cancelled','returned')`);
  const [orderCount] = await db.select({ v: sql<number>`count(*)::int` }).from(orders);
  const [pendingCount] = await db.select({ v: sql<number>`count(*)::int` }).from(orders).where(eq(orders.status, "pending"));
  const [customerCount] = await db.select({ v: sql<number>`count(*)::int` }).from(users).where(eq(users.role, "customer"));
  const [productCount] = await db.select({ v: sql<number>`count(*)::int` }).from(products);
  const [lowStock] = await db.select({ v: sql<number>`count(*)::int` }).from(products).where(and(lte(products.stock, 5), sql`stock > 0`));
  const [outStock] = await db.select({ v: sql<number>`count(*)::int` }).from(products).where(eq(products.stock, 0));
  const [pendingReviews] = await db.select({ v: sql<number>`count(*)::int` }).from(reviews).where(eq(reviews.status, "pending"));
  const recentOrders = await db.select().from(orders).orderBy(desc(orders.createdAt)).limit(8);
  const bestSellers = await db.select().from(products).orderBy(desc(products.salesCount)).limit(5);

  const stats = [
    { label: "Total Revenue", value: formatPrice(revenue.v), href: "/admin/orders", accent: "text-emerald-600" },
    { label: "Total Orders", value: orderCount.v, href: "/admin/orders", accent: "text-brand-700" },
    { label: "Pending Orders", value: pendingCount.v, href: "/admin/orders?status=pending", accent: "text-amber-600" },
    { label: "Customers", value: customerCount.v, href: "/admin/customers", accent: "text-brand-700" },
    { label: "Products", value: productCount.v, href: "/admin/products", accent: "text-brand-700" },
    { label: "Low Stock (≤5)", value: lowStock.v, href: "/admin/products", accent: "text-amber-600" },
    { label: "Out of Stock", value: outStock.v, href: "/admin/products", accent: "text-rose-600" },
    { label: "Pending Reviews", value: pendingReviews.v, href: "/admin/reviews", accent: "text-amber-600" },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 mb-6">Dashboard</h1>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((s) => (
          <Link key={s.label} href={s.href} className="card card-hover p-5">
            <p className={`text-2xl font-bold ${s.accent}`}>{s.value}</p>
            <p className="text-sm text-slate-500 mt-1">{s.label}</p>
          </Link>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="flex justify-between items-center mb-3">
            <h2 className="font-display text-xl font-bold text-slate-900">Recent Orders</h2>
            <Link href="/admin/orders" className="text-sm font-semibold text-brand-700 hover:underline">View all →</Link>
          </div>
          <div className="card overflow-x-auto">
            {recentOrders.length === 0 ? (
              <p className="p-6 text-sm text-slate-500 text-center">No orders yet. They will appear here as customers check out.</p>
            ) : (
              <table className="w-full text-sm min-w-[560px]">
                <thead>
                  <tr className="border-b border-slate-100 text-left text-xs uppercase text-slate-400">
                    <th className="px-4 py-3">Order</th><th className="px-4 py-3">Customer</th>
                    <th className="px-4 py-3">Date</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {recentOrders.map((o) => (
                    <tr key={o.id} className="border-b border-slate-50">
                      <td className="px-4 py-2.5 font-semibold">{o.orderNumber}</td>
                      <td className="px-4 py-2.5 text-slate-600">{o.fullName}</td>
                      <td className="px-4 py-2.5 text-slate-500">{formatDate(o.createdAt)}</td>
                      <td className="px-4 py-2.5">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${STATUS_COLORS[o.status]}`}>{STATUS_LABELS[o.status]}</span>
                        {o.cancelRequested && <span className="block text-[10px] text-amber-600 mt-0.5">cancel requested</span>}
                      </td>
                      <td className="px-4 py-2.5 font-bold text-brand-800">{formatPrice(o.total)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        <div>
          <h2 className="font-display text-xl font-bold text-slate-900 mb-3">Best Sellers</h2>
          <div className="card divide-y divide-slate-50">
            {bestSellers.map((p) => (
              <div key={p.id} className="p-3 flex items-center gap-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={p.images?.[0]} alt={p.name} className="h-12 w-10 object-cover rounded" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-slate-800 line-clamp-1">{p.name}</p>
                  <p className="text-xs text-slate-400">{p.salesCount} sold • stock {p.stock}</p>
                </div>
                <span className="text-xs font-bold text-brand-800">{formatPrice(p.price)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
