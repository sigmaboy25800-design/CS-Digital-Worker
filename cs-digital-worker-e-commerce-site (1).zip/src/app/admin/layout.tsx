import Link from "next/link";
import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";

export const metadata: Metadata = { title: "Admin Dashboard", robots: { index: false } };
export const dynamic = "force-dynamic";

const LINKS = [
  { href: "/admin", label: "Dashboard", icon: "📊" },
  { href: "/admin/products", label: "Products", icon: "👗" },
  { href: "/admin/orders", label: "Orders", icon: "📦" },
  { href: "/admin/customers", label: "Customers", icon: "👥" },
  { href: "/admin/categories", label: "Categories", icon: "🗂️" },
  { href: "/admin/coupons", label: "Coupons", icon: "🎟️" },
  { href: "/admin/reviews", label: "Reviews", icon: "⭐" },
  { href: "/admin/blog", label: "Blog", icon: "📝" },
  { href: "/admin/messages", label: "Messages", icon: "✉️" },
  { href: "/admin/subscribers", label: "Subscribers", icon: "📧" },
  { href: "/admin/settings", label: "Settings", icon: "⚙️" },
];

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const admin = await requireAdmin();
  if (!admin) redirect("/login");

  return (
    <div className="container-x py-6">
      <div className="flex flex-col lg:flex-row gap-6">
        <aside className="lg:w-56 shrink-0" aria-label="Admin navigation">
          <div className="card p-3 lg:sticky lg:top-24">
            <p className="px-3 py-2 text-xs font-bold uppercase tracking-widest text-slate-400">Admin Panel</p>
            <nav className="flex lg:flex-col gap-1 overflow-x-auto">
              {LINKS.map((l) => (
                <Link key={l.href} href={l.href} className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-slate-700 hover:bg-brand-50 hover:text-brand-800 whitespace-nowrap">
                  <span aria-hidden>{l.icon}</span> {l.label}
                </Link>
              ))}
              <Link href="/" className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-brand-700 hover:bg-brand-50 whitespace-nowrap">
                <span aria-hidden>🏬</span> View Store
              </Link>
            </nav>
          </div>
        </aside>
        <div className="flex-1 min-w-0">{children}</div>
      </div>
    </div>
  );
}
