import "server-only";
import { and, asc, desc, eq, gte, ilike, lte, or, sql, inArray, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { categories, coupons, products, settings, type Product } from "@/db/schema";
import { CONTACT, SOCIALS } from "@/lib/utils";

// ---------------- Settings ----------------
export const DEFAULT_SETTINGS: Record<string, string> = {
  storeName: "CS Digital Worker",
  tagline: "Premium Fashion & Digital Commerce",
  announcement: "Free shipping on orders over Rs. 5,000 — Use code WELCOME10 for 10% off your first order!",
  announcementEnabled: "1",
  heroHeading: "Elevate Your Wardrobe with Premium Unstitched & Ready-to-Wear",
  heroSubheading: "Discover lawn, embroidered and printed collections crafted for elegance — delivered to your doorstep across Pakistan.",
  contactPhone: CONTACT.phone,
  contactEmail: CONTACT.email,
  contactWhatsapp: CONTACT.phone,
  address: "Pakistan",
  facebook: SOCIALS.facebook,
  tiktok: SOCIALS.tiktok,
  instagram: SOCIALS.instagram,
  youtube: "",
  pinterest: "",
  shippingFlatRate: "250",
  freeShippingThreshold: "5000",
  codEnabled: "1",
  bankTransferEnabled: "1",
  bankDetails: "Bank transfer details will be shared via WhatsApp/Email after order confirmation.",
  seoTitle: "CS Digital Worker — Premium Fashion & Digital Commerce Store",
  seoDescription: "Shop premium 2-piece & 3-piece suits, lawn, embroidered and printed collections at CS Digital Worker. Secure shopping, cash on delivery and fast nationwide delivery.",
  ga4Id: "",
  gtmId: "",
  metaPixelId: "",
  googleSiteVerification: "",
  merchantCenterNote: "",
  footerText: "CS Digital Worker is a premium e-commerce and digital business platform offering quality fashion products, secure shopping and dedicated customer support across Pakistan.",
};

export async function getSettings(): Promise<Record<string, string>> {
  try {
    const rows = await db.select().from(settings);
    const map: Record<string, string> = { ...DEFAULT_SETTINGS };
    for (const row of rows) map[row.key] = row.value;
    return map;
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

// ---------------- Categories ----------------
export async function getActiveCategories() {
  return db
    .select()
    .from(categories)
    .where(eq(categories.isActive, true))
    .orderBy(asc(categories.sortOrder), asc(categories.name));
}

// ---------------- Products ----------------
export type ProductQuery = {
  q?: string;
  category?: string;
  minPrice?: number;
  maxPrice?: number;
  sizes?: string[];
  colors?: string[];
  inStock?: boolean;
  minRating?: number;
  sort?: string;
  page?: number;
  perPage?: number;
  flag?: "featured" | "new" | "bestseller" | "sale";
};

export async function getProducts(query: ProductQuery) {
  const conditions: SQL[] = [eq(products.isActive, true)];

  if (query.q) {
    const term = `%${query.q}%`;
    const c = or(
      ilike(products.name, term),
      ilike(products.description, term),
      ilike(products.sku, term),
      sql`${products.tags}::text ILIKE ${term}`
    );
    if (c) conditions.push(c);
  }
  if (query.category) {
    const cat = await db
      .select()
      .from(categories)
      .where(eq(categories.slug, query.category))
      .limit(1);
    if (cat[0]) conditions.push(eq(products.categoryId, cat[0].id));
  }
  if (query.minPrice != null && query.minPrice > 0)
    conditions.push(gte(products.price, query.minPrice));
  if (query.maxPrice != null && query.maxPrice > 0)
    conditions.push(lte(products.price, query.maxPrice));
  if (query.sizes?.length) {
    const c = or(
      ...query.sizes.map((s) => sql`${products.sizes}::jsonb ? ${s}`)
    );
    if (c) conditions.push(c);
  }
  if (query.colors?.length) {
    const c = or(
      ...query.colors.map((s) => sql`${products.colors}::jsonb ? ${s}`)
    );
    if (c) conditions.push(c);
  }
  if (query.inStock) conditions.push(gte(products.stock, 1));
  if (query.minRating) conditions.push(gte(products.ratingAvg, query.minRating));
  if (query.flag === "featured") conditions.push(eq(products.isFeatured, true));
  if (query.flag === "new") conditions.push(eq(products.isNewArrival, true));
  if (query.flag === "bestseller") conditions.push(eq(products.isBestSeller, true));
  if (query.flag === "sale") conditions.push(eq(products.onSale, true));

  const where = and(...conditions);

  let orderBy;
  switch (query.sort) {
    case "price_asc":
      orderBy = [asc(products.price)];
      break;
    case "price_desc":
      orderBy = [desc(products.price)];
      break;
    case "popularity":
      orderBy = [desc(products.salesCount), desc(products.ratingCount)];
      break;
    case "rating":
      orderBy = [desc(products.ratingAvg), desc(products.ratingCount)];
      break;
    default:
      orderBy = [desc(products.createdAt)];
  }

  const perPage = query.perPage ?? 12;
  const page = Math.max(1, query.page ?? 1);

  const [items, countRows] = await Promise.all([
    db
      .select()
      .from(products)
      .where(where)
      .orderBy(...orderBy)
      .limit(perPage)
      .offset((page - 1) * perPage),
    db.select({ count: sql<number>`count(*)::int` }).from(products).where(where),
  ]);

  return {
    products: items,
    total: countRows[0]?.count ?? 0,
    page,
    perPage,
    totalPages: Math.max(1, Math.ceil((countRows[0]?.count ?? 0) / perPage)),
  };
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const rows = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  return rows[0] ?? null;
}

// ---------------- Coupons ----------------
export type CouponResult =
  | { ok: true; discount: number; code: string; description: string }
  | { ok: false; error: string };

export async function validateCoupon(
  code: string,
  items: { productId: number; price: number; qty: number }[]
): Promise<CouponResult> {
  const rows = await db
    .select()
    .from(coupons)
    .where(eq(coupons.code, code.trim().toUpperCase()))
    .limit(1);
  const coupon = rows[0];
  if (!coupon || !coupon.isActive) return { ok: false, error: "Invalid coupon code." };
  if (coupon.expiresAt && new Date(coupon.expiresAt) < new Date())
    return { ok: false, error: "This coupon has expired." };
  if (coupon.usageLimit != null && coupon.usedCount >= coupon.usageLimit)
    return { ok: false, error: "This coupon has reached its usage limit." };

  const subtotal = items.reduce((sum, i) => sum + i.price * i.qty, 0);
  if (subtotal < coupon.minOrder)
    return {
      ok: false,
      error: `Minimum order amount for this coupon is Rs. ${coupon.minOrder.toLocaleString()}.`,
    };

  // Eligible amount (product/category specific coupons)
  let eligible = subtotal;
  if (coupon.productId) {
    eligible = items
      .filter((i) => i.productId === coupon.productId)
      .reduce((s, i) => s + i.price * i.qty, 0);
    if (eligible === 0)
      return { ok: false, error: "This coupon applies to a specific product not in your cart." };
  } else if (coupon.categoryId) {
    const ids = items.map((i) => i.productId);
    const prods = ids.length
      ? await db.select().from(products).where(inArray(products.id, ids))
      : [];
    eligible = items
      .filter((i) => prods.find((p) => p.id === i.productId)?.categoryId === coupon.categoryId)
      .reduce((s, i) => s + i.price * i.qty, 0);
    if (eligible === 0)
      return { ok: false, error: "This coupon applies to a specific category not in your cart." };
  }

  let discount =
    coupon.type === "percent" ? Math.round((eligible * coupon.value) / 100) : coupon.value;
  if (coupon.maxDiscount != null && coupon.maxDiscount > 0)
    discount = Math.min(discount, coupon.maxDiscount);
  discount = Math.min(discount, subtotal);

  const description =
    coupon.type === "percent" ? `${coupon.value}% off` : `Rs. ${coupon.value} off`;
  return { ok: true, discount, code: coupon.code, description };
}
