export const BRAND = "CS Digital Worker";
export const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

export const CONTACT = {
  phone: "03228586255",
  phoneHref: "tel:03228586255",
  whatsappHref: "https://wa.me/923228586255",
  email: "sigmaboy25800@gmail.com",
  emailHref: "mailto:sigmaboy25800@gmail.com",
};

export const SOCIALS = {
  facebook: "https://www.facebook.com/CSDigitalWorker/",
  tiktok: "https://www.tiktok.com/@csdigitalworker",
  instagram: "https://www.instagram.com/sigma_boy25800/",
};

export const ORDER_STATUSES = [
  "pending",
  "confirmed",
  "processing",
  "shipped",
  "out_for_delivery",
  "delivered",
  "cancelled",
  "returned",
] as const;

export const STATUS_LABELS: Record<string, string> = {
  pending: "Pending",
  confirmed: "Confirmed",
  processing: "Processing",
  shipped: "Shipped",
  out_for_delivery: "Out for Delivery",
  delivered: "Delivered",
  cancelled: "Cancelled",
  returned: "Returned",
};

export const STATUS_COLORS: Record<string, string> = {
  pending: "bg-amber-100 text-amber-800",
  confirmed: "bg-sky-100 text-sky-800",
  processing: "bg-indigo-100 text-indigo-800",
  shipped: "bg-violet-100 text-violet-800",
  out_for_delivery: "bg-cyan-100 text-cyan-800",
  delivered: "bg-emerald-100 text-emerald-800",
  cancelled: "bg-rose-100 text-rose-800",
  returned: "bg-slate-200 text-slate-700",
};

export function formatPrice(amount: number): string {
  return "Rs. " + Math.round(amount).toLocaleString("en-PK");
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/[\s_]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

export function generateOrderNumber(): string {
  const ts = Date.now().toString(36).toUpperCase();
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `CSD-${ts}${rand}`;
}

export function discountPercent(price: number, oldPrice?: number | null): number {
  if (!oldPrice || oldPrice <= price) return 0;
  return Math.round(((oldPrice - price) / oldPrice) * 100);
}

export function formatDate(d: Date | string): string {
  return new Date(d).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export type CartLine = {
  productId: number;
  slug: string;
  name: string;
  image: string;
  price: number;
  oldPrice?: number | null;
  size?: string;
  color?: string;
  qty: number;
  stock: number;
};

export type WishItem = {
  productId: number;
  slug: string;
  name: string;
  image: string;
  price: number;
  oldPrice?: number | null;
};
