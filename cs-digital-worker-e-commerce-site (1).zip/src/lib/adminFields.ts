// Field whitelisting & coercion helpers for the admin API (prevents mass assignment).

type Body = Record<string, unknown>;

const s = (v: unknown, max = 5000) => (v == null ? null : String(v).slice(0, max));
const n = (v: unknown) => {
  const num = Number(v);
  return Number.isFinite(num) ? Math.round(num) : null;
};
const b = (v: unknown) => Boolean(v);
const arr = (v: unknown): string[] =>
  Array.isArray(v) ? v.map((x) => String(x).slice(0, 100)).filter(Boolean).slice(0, 30) : [];

export function buildProductValues(body: Body) {
  const specs = Array.isArray(body.specifications)
    ? (body.specifications as { label: unknown; value: unknown }[])
        .map((x) => ({ label: String(x.label ?? "").slice(0, 100), value: String(x.value ?? "").slice(0, 300) }))
        .filter((x) => x.label)
        .slice(0, 20)
    : [];
  return {
    name: s(body.name, 200) ?? "",
    slug: s(body.slug, 200) ?? "",
    sku: s(body.sku, 60) ?? "",
    description: s(body.description),
    fabric: s(body.fabric, 300),
    care: s(body.care, 500),
    specifications: specs,
    price: n(body.price) ?? 0,
    oldPrice: body.oldPrice ? n(body.oldPrice) : null,
    stock: n(body.stock) ?? 0,
    categoryId: body.categoryId ? n(body.categoryId) : null,
    sizes: arr(body.sizes),
    colors: arr(body.colors),
    tags: arr(body.tags),
    images: Array.isArray(body.images)
      ? (body.images as unknown[]).map((x) => String(x).slice(0, 600)).filter(Boolean).slice(0, 10)
      : [],
    imageAlt: s(body.imageAlt, 200),
    isFeatured: b(body.isFeatured),
    isNewArrival: b(body.isNewArrival),
    isBestSeller: b(body.isBestSeller),
    onSale: b(body.onSale),
    seoTitle: s(body.seoTitle, 200),
    seoDescription: s(body.seoDescription, 300),
    isActive: body.isActive === undefined ? true : b(body.isActive),
  };
}

export function buildCategoryValues(body: Body) {
  return {
    name: s(body.name, 100) ?? "",
    slug: s(body.slug, 120) ?? "",
    description: s(body.description, 500),
    image: s(body.image, 600),
    sortOrder: n(body.sortOrder) ?? 0,
    isActive: body.isActive === undefined ? true : b(body.isActive),
  };
}

export function buildCouponValues(body: Body) {
  return {
    code: (s(body.code, 40) ?? "").toUpperCase().replace(/\s/g, ""),
    type: body.type === "fixed" ? "fixed" : "percent",
    value: n(body.value) ?? 0,
    minOrder: n(body.minOrder) ?? 0,
    maxDiscount: body.maxDiscount ? n(body.maxDiscount) : null,
    expiresAt: body.expiresAt ? new Date(String(body.expiresAt)) : null,
    usageLimit: body.usageLimit ? n(body.usageLimit) : null,
    categoryId: body.categoryId ? n(body.categoryId) : null,
    productId: body.productId ? n(body.productId) : null,
    isActive: body.isActive === undefined ? true : b(body.isActive),
  };
}

export function buildBlogValues(body: Body) {
  return {
    title: s(body.title, 200) ?? "",
    slug: s(body.slug, 220) ?? "",
    excerpt: s(body.excerpt, 500),
    content: s(body.content, 100000) ?? "",
    image: s(body.image, 600),
    imageAlt: s(body.imageAlt, 200),
    category: s(body.category, 100) ?? "E-Commerce",
    tags: arr(body.tags),
    author: s(body.author, 100) ?? "CS Digital Worker",
    seoTitle: s(body.seoTitle, 200),
    seoDescription: s(body.seoDescription, 300),
    isPublished: body.isPublished === undefined ? true : b(body.isPublished),
  };
}
