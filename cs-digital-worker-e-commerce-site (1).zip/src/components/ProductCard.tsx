"use client";

import Link from "next/link";
import { useState } from "react";
import { useStore } from "@/components/Providers";
import { Stars, Price } from "@/components/ui";
import { discountPercent, formatPrice } from "@/lib/utils";

export type CardProduct = {
  id: number;
  slug: string;
  name: string;
  images: string[];
  imageAlt?: string | null;
  price: number;
  oldPrice?: number | null;
  stock: number;
  ratingAvg: number;
  ratingCount: number;
  sizes?: string[];
  colors?: string[];
  isNewArrival?: boolean;
};

export default function ProductCard({ product }: { product: CardProduct }) {
  const { addToCart, toggleWishlist, isWishlisted, hydrated } = useStore();
  const [quickView, setQuickView] = useState(false);
  const image = product.images?.[0] ?? "/images/hero.jpg";
  const pct = discountPercent(product.price, product.oldPrice);
  const wished = hydrated && isWishlisted(product.id);
  const out = product.stock <= 0;

  const quickAdd = (size?: string, color?: string, qty = 1) => {
    addToCart({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      image,
      price: product.price,
      oldPrice: product.oldPrice,
      size: size ?? product.sizes?.[0],
      color: color ?? product.colors?.[0],
      qty,
      stock: product.stock,
    });
  };

  return (
    <>
      <article className="card card-hover overflow-hidden group flex flex-col">
        <div className="relative aspect-[3/4] overflow-hidden bg-slate-100">
          <Link href={`/product/${product.slug}`} aria-label={product.name}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={image}
              alt={product.imageAlt ?? product.name}
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
          </Link>
          <div className="absolute top-2 left-2 flex flex-col gap-1">
            {pct > 0 && (
              <span className="bg-rose-600 text-white text-xs font-bold px-2 py-0.5 rounded">-{pct}%</span>
            )}
            {product.isNewArrival && (
              <span className="bg-brand-700 text-white text-xs font-bold px-2 py-0.5 rounded">New</span>
            )}
            {out && (
              <span className="bg-slate-800 text-white text-xs font-bold px-2 py-0.5 rounded">Out of Stock</span>
            )}
          </div>
          <button
            aria-label={wished ? "Remove from wishlist" : "Add to wishlist"}
            aria-pressed={wished}
            onClick={() =>
              toggleWishlist({
                productId: product.id, slug: product.slug, name: product.name,
                image, price: product.price, oldPrice: product.oldPrice,
              })
            }
            className={`absolute top-2 right-2 h-9 w-9 rounded-full inline-flex items-center justify-center shadow transition-colors ${
              wished ? "bg-rose-600 text-white" : "bg-white/90 text-slate-600 hover:text-rose-600"
            }`}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill={wished ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" strokeLinejoin="round">
              <path d="M12 21C7 16.5 3 13.3 3 9.3 3 6.4 5.2 4 8 4c1.6 0 3.1.8 4 2 .9-1.2 2.4-2 4-2 2.8 0 5 2.4 5 5.3 0 4-4 7.2-9 11.7z" />
            </svg>
          </button>
          <div className="absolute inset-x-2 bottom-2 opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300 flex gap-2">
            <button onClick={() => setQuickView(true)} className="btn bg-white/95 text-slate-800 hover:bg-white btn-sm flex-1 shadow">
              Quick View
            </button>
          </div>
        </div>
        <div className="p-3.5 flex flex-col gap-1.5 flex-1">
          <Link href={`/product/${product.slug}`} className="hover:text-brand-700">
            <h3 className="text-sm font-semibold text-slate-800 line-clamp-2 min-h-10">{product.name}</h3>
          </Link>
          <Stars rating={product.ratingAvg} count={product.ratingCount} size={14} />
          <Price price={product.price} oldPrice={product.oldPrice} />
          <button
            onClick={() => quickAdd()}
            disabled={out}
            className="btn-primary btn-sm mt-auto w-full"
            aria-label={`Add ${product.name} to cart`}
          >
            {out ? "Out of Stock" : "Add to Cart"}
          </button>
        </div>
      </article>

      {/* Quick view modal */}
      {quickView && (
        <QuickViewModal product={product} onClose={() => setQuickView(false)} onAdd={quickAdd} />
      )}
    </>
  );
}

function QuickViewModal({
  product, onClose, onAdd,
}: {
  product: CardProduct;
  onClose: () => void;
  onAdd: (size?: string, color?: string, qty?: number) => void;
}) {
  const [size, setSize] = useState(product.sizes?.[0]);
  const [color, setColor] = useState(product.colors?.[0]);
  const [qty, setQty] = useState(1);
  const [imgIdx, setImgIdx] = useState(0);
  const out = product.stock <= 0;

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-label={`Quick view: ${product.name}`}>
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-auto">
        <button onClick={onClose} aria-label="Close quick view" className="absolute top-3 right-3 z-10 h-9 w-9 rounded-full bg-white shadow inline-flex items-center justify-center text-slate-600 hover:text-slate-900">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18" /></svg>
        </button>
        <div className="grid sm:grid-cols-2">
          <div className="relative aspect-[3/4] bg-slate-100">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={product.images[imgIdx] ?? product.images[0]} alt={product.imageAlt ?? product.name} className="h-full w-full object-cover sm:rounded-l-2xl" />
            {product.images.length > 1 && (
              <div className="absolute bottom-2 inset-x-0 flex justify-center gap-1.5">
                {product.images.map((_, i) => (
                  <button key={i} aria-label={`Image ${i + 1}`} onClick={() => setImgIdx(i)} className={`h-2 w-2 rounded-full ${i === imgIdx ? "bg-white" : "bg-white/50"}`} />
                ))}
              </div>
            )}
          </div>
          <div className="p-6 flex flex-col gap-3">
            <h2 className="font-display text-xl font-bold text-slate-900">{product.name}</h2>
            <Stars rating={product.ratingAvg} count={product.ratingCount} />
            <Price price={product.price} oldPrice={product.oldPrice} large />
            {product.sizes && product.sizes.length > 0 && (
              <div>
                <p className="label">Size</p>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((s) => (
                    <button key={s} onClick={() => setSize(s)} aria-pressed={size === s} className={`px-3 py-1.5 rounded-md border text-sm font-medium ${size === s ? "border-brand-800 bg-brand-800 text-white" : "border-slate-300 text-slate-700 hover:border-brand-600"}`}>
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {product.colors && product.colors.length > 0 && (
              <div>
                <p className="label">Color</p>
                <div className="flex flex-wrap gap-2">
                  {product.colors.map((c) => (
                    <button key={c} onClick={() => setColor(c)} aria-pressed={color === c} className={`px-3 py-1.5 rounded-md border text-sm font-medium ${color === c ? "border-brand-800 bg-brand-800 text-white" : "border-slate-300 text-slate-700 hover:border-brand-600"}`}>
                      {c}
                    </button>
                  ))}
                </div>
              </div>
            )}
            <div className="flex items-center gap-3">
              <div className="inline-flex items-center border border-slate-300 rounded-lg">
                <button aria-label="Decrease quantity" onClick={() => setQty((q) => Math.max(1, q - 1))} className="px-3 py-2 text-slate-600 hover:text-brand-800">−</button>
                <span className="px-3 font-semibold text-sm" aria-live="polite">{qty}</span>
                <button aria-label="Increase quantity" onClick={() => setQty((q) => Math.min(product.stock, q + 1))} className="px-3 py-2 text-slate-600 hover:text-brand-800">+</button>
              </div>
              <span className="text-xs text-slate-500">{out ? "Out of stock" : `${product.stock} in stock`}</span>
            </div>
            <div className="flex gap-2 mt-2">
              <button
                disabled={out}
                onClick={() => { onAdd(size, color, qty); onClose(); }}
                className="btn-primary btn-md flex-1"
              >
                Add to Cart — {formatPrice(product.price * qty)}
              </button>
            </div>
            <Link href={`/product/${product.slug}`} className="text-sm font-semibold text-brand-700 hover:text-brand-900 text-center">
              View Full Details →
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
