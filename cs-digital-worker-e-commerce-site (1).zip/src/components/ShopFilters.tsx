"use client";

import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { useState } from "react";

type Cat = { name: string; slug: string };

const SIZES = ["Unstitched", "S", "M", "L", "XL", "One Size"];
const COLORS = ["Emerald", "Teal", "Blue", "Navy", "Lavender", "Purple", "Plum", "Grey", "Olive", "Green", "Sage", "Ivory", "Gold", "Yellow", "Multi", "White", "Black", "Beige", "Pink", "Blush", "Rosewood", "Red", "Silver"];

export function SortSelect() {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const sort = params.get("sort") ?? "newest";

  const change = (value: string) => {
    const next = new URLSearchParams(params.toString());
    next.set("sort", value);
    next.delete("page");
    router.push(`${pathname}?${next.toString()}`);
  };

  return (
    <label className="inline-flex items-center gap-2 text-sm text-slate-600">
      <span className="whitespace-nowrap">Sort by</span>
      <select value={sort} onChange={(e) => change(e.target.value)} className="input !w-auto py-2" aria-label="Sort products">
        <option value="newest">Newest</option>
        <option value="price_asc">Price: Low to High</option>
        <option value="price_desc">Price: High to Low</option>
        <option value="popularity">Popularity</option>
        <option value="rating">Rating</option>
      </select>
    </label>
  );
}

export default function ShopFilters({ categories, hideCategory = false }: { categories: Cat[]; hideCategory?: boolean }) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const [open, setOpen] = useState(false);

  const [minPrice, setMinPrice] = useState(params.get("min") ?? "");
  const [maxPrice, setMaxPrice] = useState(params.get("max") ?? "");
  const selectedSizes = params.get("sizes")?.split(",").filter(Boolean) ?? [];
  const selectedColors = params.get("colors")?.split(",").filter(Boolean) ?? [];
  const inStock = params.get("stock") === "1";
  const minRating = params.get("rating") ?? "";
  const category = params.get("category") ?? "";

  const update = (mutate: (p: URLSearchParams) => void) => {
    const next = new URLSearchParams(params.toString());
    mutate(next);
    next.delete("page");
    router.push(`${pathname}?${next.toString()}`);
  };

  const toggleList = (key: string, value: string, current: string[]) => {
    const set = new Set(current);
    if (set.has(value)) set.delete(value); else set.add(value);
    update((p) => {
      const joined = Array.from(set).join(",");
      if (joined) p.set(key, joined); else p.delete(key);
    });
  };

  const applyPrice = (e: React.FormEvent) => {
    e.preventDefault();
    update((p) => {
      if (minPrice) p.set("min", minPrice); else p.delete("min");
      if (maxPrice) p.set("max", maxPrice); else p.delete("max");
    });
  };

  const clearAll = () => router.push(pathname);

  const body = (
    <div className="space-y-6">
      {!hideCategory && (
        <fieldset>
          <legend className="font-bold text-sm text-slate-900 mb-2">Category</legend>
          <div className="space-y-1.5">
            <label className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
              <input type="radio" name="category" checked={!category} onChange={() => update((p) => p.delete("category"))} className="accent-brand-700" />
              All Categories
            </label>
            {categories.map((c) => (
              <label key={c.slug} className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
                <input type="radio" name="category" checked={category === c.slug} onChange={() => update((p) => p.set("category", c.slug))} className="accent-brand-700" />
                {c.name}
              </label>
            ))}
          </div>
        </fieldset>
      )}

      <form onSubmit={applyPrice}>
        <p className="font-bold text-sm text-slate-900 mb-2">Price Range (Rs.)</p>
        <div className="flex items-center gap-2">
          <label className="sr-only" htmlFor="min-price">Minimum price</label>
          <input id="min-price" type="number" min="0" placeholder="Min" value={minPrice} onChange={(e) => setMinPrice(e.target.value)} className="input !py-2" />
          <span className="text-slate-400">–</span>
          <label className="sr-only" htmlFor="max-price">Maximum price</label>
          <input id="max-price" type="number" min="0" placeholder="Max" value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} className="input !py-2" />
        </div>
        <button type="submit" className="btn-outline btn-sm mt-2 w-full">Apply Price</button>
      </form>

      <fieldset>
        <legend className="font-bold text-sm text-slate-900 mb-2">Size</legend>
        <div className="flex flex-wrap gap-1.5">
          {SIZES.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => toggleList("sizes", s, selectedSizes)}
              aria-pressed={selectedSizes.includes(s)}
              className={`px-2.5 py-1 rounded-md border text-xs font-medium ${selectedSizes.includes(s) ? "border-brand-800 bg-brand-800 text-white" : "border-slate-300 text-slate-600 hover:border-brand-600"}`}
            >
              {s}
            </button>
          ))}
        </div>
      </fieldset>

      <fieldset>
        <legend className="font-bold text-sm text-slate-900 mb-2">Color</legend>
        <div className="flex flex-wrap gap-1.5 max-h-40 overflow-auto">
          {COLORS.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => toggleList("colors", c, selectedColors)}
              aria-pressed={selectedColors.includes(c)}
              className={`px-2.5 py-1 rounded-md border text-xs font-medium ${selectedColors.includes(c) ? "border-brand-800 bg-brand-800 text-white" : "border-slate-300 text-slate-600 hover:border-brand-600"}`}
            >
              {c}
            </button>
          ))}
        </div>
      </fieldset>

      <div>
        <p className="font-bold text-sm text-slate-900 mb-2">Availability & Rating</p>
        <label className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer mb-2">
          <input type="checkbox" checked={inStock} onChange={() => update((p) => { if (inStock) p.delete("stock"); else p.set("stock", "1"); })} className="accent-brand-700" />
          In stock only
        </label>
        <label className="block text-sm text-slate-600">
          <span className="sr-only">Minimum rating</span>
          <select value={minRating} onChange={(e) => update((p) => { if (e.target.value) p.set("rating", e.target.value); else p.delete("rating"); })} className="input !py-2" aria-label="Minimum rating">
            <option value="">Any rating</option>
            <option value="4">4★ & above</option>
            <option value="3">3★ & above</option>
            <option value="2">2★ & above</option>
          </select>
        </label>
      </div>

      <button onClick={clearAll} className="btn-ghost btn-sm w-full border border-slate-200">Clear All Filters</button>
    </div>
  );

  return (
    <>
      {/* Mobile toggle */}
      <div className="lg:hidden mb-4">
        <button onClick={() => setOpen((o) => !o)} className="btn-outline btn-md w-full" aria-expanded={open}>
          {open ? "Hide Filters" : "Show Filters"} ⚙
        </button>
        {open && <div className="card p-4 mt-3">{body}</div>}
      </div>
      {/* Desktop sidebar */}
      <aside className="hidden lg:block w-64 shrink-0" aria-label="Product filters">
        <div className="card p-5 sticky top-24">{body}</div>
      </aside>
    </>
  );
}
