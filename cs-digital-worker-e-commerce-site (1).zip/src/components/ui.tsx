import Link from "next/link";
import type { ReactNode } from "react";
import { formatPrice, discountPercent } from "@/lib/utils";

export function LogoMark({ dark = false, size = "md" }: { dark?: boolean; size?: "sm" | "md" | "lg" }) {
  const box = size === "lg" ? "h-11 w-11 text-xl" : size === "sm" ? "h-8 w-8 text-sm" : "h-9 w-9 text-base";
  const text = size === "lg" ? "text-2xl" : size === "sm" ? "text-base" : "text-lg";
  return (
    <span className="inline-flex items-center gap-2.5">
      <span
        className={`${box} rounded-xl bg-gradient-to-br from-brand-700 to-brand-950 text-gold-400 font-display font-bold inline-flex items-center justify-center shadow-sm`}
        aria-hidden="true"
      >
        CS
      </span>
      <span className={`font-display font-bold leading-tight ${text} ${dark ? "text-white" : "text-slate-900"}`}>
        CS Digital{" "}
        <span className={dark ? "text-gold-400" : "text-brand-700"}>Worker</span>
      </span>
    </span>
  );
}

export function Stars({ rating, count, size = 16 }: { rating: number; count?: number; size?: number }) {
  return (
    <span className="inline-flex items-center gap-1" aria-label={`Rated ${rating.toFixed(1)} out of 5`}>
      <span className="inline-flex" aria-hidden="true">
        {[1, 2, 3, 4, 5].map((i) => (
          <svg
            key={i}
            width={size}
            height={size}
            viewBox="0 0 24 24"
            fill={i <= Math.round(rating) ? "#f59e0b" : "#e2e8f0"}
          >
            <path d="M12 2l2.9 6.3 6.9.8-5.1 4.7 1.4 6.8L12 17l-6.1 3.6 1.4-6.8L2.2 9.1l6.9-.8L12 2z" />
          </svg>
        ))}
      </span>
      {count !== undefined && (
        <span className="text-xs text-slate-500">
          {rating > 0 ? rating.toFixed(1) : "New"} {count > 0 ? `(${count})` : ""}
        </span>
      )}
    </span>
  );
}

export function Price({ price, oldPrice, large = false }: { price: number; oldPrice?: number | null; large?: boolean }) {
  const pct = discountPercent(price, oldPrice);
  return (
    <span className="inline-flex items-baseline gap-2 flex-wrap">
      <span className={`font-bold text-brand-800 ${large ? "text-3xl" : "text-base"}`}>
        {formatPrice(price)}
      </span>
      {oldPrice && oldPrice > price ? (
        <>
          <span className={`text-slate-400 line-through ${large ? "text-lg" : "text-sm"}`}>
            {formatPrice(oldPrice)}
          </span>
          <span className="text-xs font-bold text-rose-600 bg-rose-50 rounded px-1.5 py-0.5">
            -{pct}%
          </span>
        </>
      ) : null}
    </span>
  );
}

export function SectionHeading({
  title, subtitle, href, linkLabel,
}: { title: string; subtitle?: string; href?: string; linkLabel?: string }) {
  return (
    <div className="flex items-end justify-between gap-4 mb-6">
      <div>
        <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-900">{title}</h2>
        {subtitle && <p className="text-slate-500 mt-1 text-sm sm:text-base">{subtitle}</p>}
      </div>
      {href && (
        <Link href={href} className="text-sm font-semibold text-brand-700 hover:text-brand-900 whitespace-nowrap inline-flex items-center gap-1">
          {linkLabel ?? "View all"} <span aria-hidden>→</span>
        </Link>
      )}
    </div>
  );
}

export function EmptyState({
  icon, title, text, children,
}: { icon: string; title: string; text: string; children?: ReactNode }) {
  return (
    <div className="text-center py-16 px-4">
      <div className="text-6xl mb-4" aria-hidden="true">{icon}</div>
      <h2 className="font-display text-2xl font-bold text-slate-900 mb-2">{title}</h2>
      <p className="text-slate-500 max-w-md mx-auto mb-6">{text}</p>
      <div className="flex flex-wrap justify-center gap-3">{children}</div>
    </div>
  );
}

export function Breadcrumbs({ items }: { items: { label: string; href?: string }[] }) {
  return (
    <nav aria-label="Breadcrumb" className="text-sm text-slate-500 mb-4">
      <ol className="flex flex-wrap items-center gap-1.5">
        <li>
          <Link href="/" className="hover:text-brand-700">Home</Link>
        </li>
        {items.map((item, i) => (
          <li key={i} className="flex items-center gap-1.5">
            <span aria-hidden="true">/</span>
            {item.href ? (
              <Link href={item.href} className="hover:text-brand-700">{item.label}</Link>
            ) : (
              <span className="text-slate-800 font-medium" aria-current="page">{item.label}</span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}

export function Spinner({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg className={`animate-spin ${className}`} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
    </svg>
  );
}
