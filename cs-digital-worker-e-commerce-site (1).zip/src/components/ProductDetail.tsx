"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/components/Providers";
import { Stars, Price } from "@/components/ui";
import { CONTACT } from "@/lib/utils";

export type DetailProduct = {
  id: number;
  slug: string;
  name: string;
  sku: string;
  images: string[];
  imageAlt?: string | null;
  price: number;
  oldPrice?: number | null;
  stock: number;
  ratingAvg: number;
  ratingCount: number;
  sizes: string[];
  colors: string[];
  tags: string[];
  categoryName?: string | null;
};

export default function ProductDetail({ product }: { product: DetailProduct }) {
  const router = useRouter();
  const { addToCart, toggleWishlist, isWishlisted, hydrated, toast } = useStore();
  const [imgIdx, setImgIdx] = useState(0);
  const [size, setSize] = useState<string | undefined>(product.sizes[0]);
  const [color, setColor] = useState<string | undefined>(product.colors[0]);
  const [qty, setQty] = useState(1);
  const [zoomed, setZoomed] = useState(false);
  const out = product.stock <= 0;
  const low = !out && product.stock <= 5;
  const wished = hydrated && isWishlisted(product.id);
  const image = product.images[imgIdx] ?? product.images[0];

  const line = () => ({
    productId: product.id, slug: product.slug, name: product.name,
    image: product.images[0], price: product.price, oldPrice: product.oldPrice,
    size, color, qty, stock: product.stock,
  });

  const share = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) {
        await navigator.share({ title: product.name, url });
      } else {
        await navigator.clipboard.writeText(url);
        toast("Product link copied to clipboard", "info");
      }
    } catch {
      /* user cancelled */
    }
  };

  return (
    <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
      {/* Gallery */}
      <div>
        <div
          className="relative aspect-[3/4] rounded-2xl overflow-hidden bg-slate-100 cursor-zoom-in group"
          onClick={() => setZoomed(true)}
          role="button"
          tabIndex={0}
          aria-label="Open image zoom"
          onKeyDown={(e) => e.key === "Enter" && setZoomed(true)}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={image}
            alt={product.imageAlt ?? product.name}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          <span className="absolute bottom-3 right-3 bg-white/90 text-slate-700 text-xs font-semibold px-2.5 py-1 rounded-full shadow">🔍 Click to zoom</span>
        </div>
        {product.images.length > 1 && (
          <div className="mt-3 flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label="Product images">
            {product.images.map((img, i) => (
              <button
                key={i}
                role="tab"
                aria-selected={i === imgIdx}
                aria-label={`View image ${i + 1}`}
                onClick={() => setImgIdx(i)}
                className={`shrink-0 h-24 w-20 rounded-lg overflow-hidden border-2 ${i === imgIdx ? "border-brand-700" : "border-transparent opacity-70 hover:opacity-100"}`}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={img} alt="" className="h-full w-full object-cover" loading="lazy" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Info */}
      <div>
        {product.categoryName && (
          <p className="text-xs font-bold uppercase tracking-widest text-brand-700">{product.categoryName}</p>
        )}
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900 mt-1.5">{product.name}</h1>
        <div className="mt-3 flex items-center gap-4 flex-wrap">
          <Stars rating={product.ratingAvg} count={product.ratingCount} />
          <span className="text-xs text-slate-400">SKU: {product.sku}</span>
        </div>
        <div className="mt-4">
          <Price price={product.price} oldPrice={product.oldPrice} large />
        </div>
        <p className={`mt-2 text-sm font-semibold ${out ? "text-rose-600" : low ? "text-amber-600" : "text-emerald-600"}`}>
          {out ? "● Out of stock" : low ? `● Low stock — only ${product.stock} left!` : `● In stock (${product.stock} available)`}
        </p>

        {product.sizes.length > 0 && (
          <div className="mt-5">
            <p className="label">Size</p>
            <div className="flex flex-wrap gap-2">
              {product.sizes.map((s) => (
                <button key={s} onClick={() => setSize(s)} aria-pressed={size === s} className={`px-4 py-2 rounded-lg border text-sm font-semibold ${size === s ? "border-brand-800 bg-brand-800 text-white" : "border-slate-300 text-slate-700 hover:border-brand-600"}`}>
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {product.colors.length > 0 && (
          <div className="mt-4">
            <p className="label">Color</p>
            <div className="flex flex-wrap gap-2">
              {product.colors.map((c) => (
                <button key={c} onClick={() => setColor(c)} aria-pressed={color === c} className={`px-4 py-2 rounded-lg border text-sm font-semibold ${color === c ? "border-brand-800 bg-brand-800 text-white" : "border-slate-300 text-slate-700 hover:border-brand-600"}`}>
                  {c}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="mt-5 flex items-center gap-4">
          <div className="inline-flex items-center border border-slate-300 rounded-lg">
            <button aria-label="Decrease quantity" onClick={() => setQty((q) => Math.max(1, q - 1))} className="px-4 py-2.5 text-lg text-slate-600 hover:text-brand-800">−</button>
            <span className="px-4 font-bold" aria-live="polite">{qty}</span>
            <button aria-label="Increase quantity" onClick={() => setQty((q) => Math.min(Math.max(1, product.stock), q + 1))} className="px-4 py-2.5 text-lg text-slate-600 hover:text-brand-800">+</button>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-3">
          <button disabled={out} onClick={() => addToCart(line())} className="btn-primary btn-lg">
            Add to Cart
          </button>
          <button
            disabled={out}
            onClick={() => { addToCart(line()); router.push("/checkout"); }}
            className="btn-gold btn-lg"
          >
            Buy Now
          </button>
        </div>

        <div className="mt-3 flex gap-3">
          <button
            onClick={() => toggleWishlist({ productId: product.id, slug: product.slug, name: product.name, image: product.images[0], price: product.price, oldPrice: product.oldPrice })}
            aria-pressed={wished}
            className={`btn btn-md flex-1 border ${wished ? "border-rose-300 bg-rose-50 text-rose-600" : "border-slate-300 text-slate-700 hover:border-rose-400 hover:text-rose-600"}`}
          >
            {wished ? "♥ In Wishlist" : "♡ Add to Wishlist"}
          </button>
          <button onClick={share} className="btn btn-md flex-1 border border-slate-300 text-slate-700 hover:border-brand-600 hover:text-brand-800">
            ↗ Share
          </button>
        </div>

        <div className="mt-6 card divide-y divide-slate-100">
          <div className="p-4 flex gap-3 text-sm">
            <span aria-hidden>🚚</span>
            <div>
              <p className="font-semibold text-slate-800">Delivery Information</p>
              <p className="text-slate-500">Nationwide delivery in 3–7 working days. Free shipping on orders over Rs. 5,000.</p>
            </div>
          </div>
          <div className="p-4 flex gap-3 text-sm">
            <span aria-hidden>↩️</span>
            <div>
              <p className="font-semibold text-slate-800">Returns & Exchanges</p>
              <p className="text-slate-500">7-day easy returns on unused items. See our <a href="/return-policy" className="text-brand-700 underline">Return Policy</a>.</p>
            </div>
          </div>
          <div className="p-4 flex gap-3 text-sm">
            <span aria-hidden>💬</span>
            <div>
              <p className="font-semibold text-slate-800">Questions?</p>
              <p className="text-slate-500">
                <a href={CONTACT.whatsappHref} target="_blank" rel="noopener noreferrer" className="text-brand-700 underline">WhatsApp us</a>{" "}
                or call <a href={CONTACT.phoneHref} className="text-brand-700 underline">{CONTACT.phone}</a>.
              </p>
            </div>
          </div>
        </div>

        {product.tags.length > 0 && (
          <p className="mt-4 text-xs text-slate-400">
            Tags: {product.tags.map((t, i) => (
              <span key={t}>
                {i > 0 && " • "}
                <a href={`/search?q=${encodeURIComponent(t)}`} className="hover:text-brand-700 underline">{t}</a>
              </span>
            ))}
          </p>
        )}
      </div>

      {/* Zoom modal */}
      {zoomed && (
        <div className="fixed inset-0 z-[90] bg-black/90 flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-label="Zoomed product image" onClick={() => setZoomed(false)}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={image} alt={product.imageAlt ?? product.name} className="max-h-full max-w-full object-contain" />
          <button aria-label="Close zoom" className="absolute top-4 right-4 h-10 w-10 rounded-full bg-white/20 text-white inline-flex items-center justify-center hover:bg-white/30">✕</button>
        </div>
      )}
    </div>
  );
}
