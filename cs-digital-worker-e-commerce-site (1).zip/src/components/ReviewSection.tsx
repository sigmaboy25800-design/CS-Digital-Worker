"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Stars, Spinner } from "@/components/ui";
import { formatDate } from "@/lib/utils";

type ReviewData = {
  id: number;
  name: string;
  rating: number;
  title: string | null;
  comment: string;
  createdAt: string;
};

export default function ReviewSection({
  productId,
  initialReviews,
}: {
  productId: number;
  initialReviews: ReviewData[];
}) {
  const [loggedIn, setLoggedIn] = useState<boolean | null>(null);
  const [rating, setRating] = useState(5);
  const [title, setTitle] = useState("");
  const [comment, setComment] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => setLoggedIn(Boolean(d.user)))
      .catch(() => setLoggedIn(false));
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("loading");
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId, rating, title, comment }),
      });
      const data = await res.json();
      if (res.ok) {
        setStatus("done");
        setMessage("Thank you! Your review has been submitted and will appear after moderation.");
        setTitle("");
        setComment("");
      } else {
        setStatus("error");
        setMessage(data.error ?? "Could not submit review.");
      }
    } catch {
      setStatus("error");
      setMessage("Network error. Please try again.");
    }
  };

  return (
    <div className="grid lg:grid-cols-2 gap-8">
      <div>
        <h3 className="font-display text-xl font-bold text-slate-900 mb-4">Customer Reviews</h3>
        {initialReviews.length === 0 ? (
          <div className="card p-6 text-center">
            <p className="text-4xl mb-2" aria-hidden>⭐</p>
            <p className="text-slate-500 text-sm">No reviews yet for this product. Be the first to share your experience after your purchase!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {initialReviews.map((r) => (
              <div key={r.id} className="card p-5">
                <div className="flex items-center justify-between gap-2">
                  <Stars rating={r.rating} />
                  <span className="text-xs text-slate-400">{formatDate(r.createdAt)}</span>
                </div>
                {r.title && <p className="font-bold text-slate-900 mt-2">{r.title}</p>}
                <p className="text-sm text-slate-600 mt-1">{r.comment}</p>
                <p className="text-xs text-slate-400 mt-2">— {r.name}, verified customer</p>
              </div>
            ))}
          </div>
        )}
      </div>

      <div>
        <h3 className="font-display text-xl font-bold text-slate-900 mb-4">Write a Review</h3>
        {loggedIn === null ? (
          <div className="card p-6 flex justify-center"><Spinner /></div>
        ) : !loggedIn ? (
          <div className="card p-6 text-center">
            <p className="text-slate-600 text-sm mb-4">Please sign in to write a review. Reviews are moderated to keep them genuine.</p>
            <div className="flex justify-center gap-3">
              <Link href="/login" className="btn-primary btn-md">Sign In</Link>
              <Link href="/signup" className="btn-outline btn-md">Create Account</Link>
            </div>
          </div>
        ) : status === "done" ? (
          <div className="card p-6 bg-emerald-50 border-emerald-200">
            <p className="text-emerald-700 font-medium">{message}</p>
          </div>
        ) : (
          <form onSubmit={submit} className="card p-6 space-y-4">
            <div>
              <p className="label">Your Rating</p>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((i) => (
                  <button key={i} type="button" onClick={() => setRating(i)} aria-label={`Rate ${i} star${i > 1 ? "s" : ""}`} aria-pressed={rating === i} className="text-2xl">
                    <span className={i <= rating ? "text-gold-500" : "text-slate-300"}>★</span>
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label htmlFor="review-title" className="label">Title (optional)</label>
              <input id="review-title" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={100} className="input" placeholder="Summarize your experience" />
            </div>
            <div>
              <label htmlFor="review-comment" className="label">Your Review</label>
              <textarea id="review-comment" required value={comment} onChange={(e) => setComment(e.target.value)} rows={4} maxLength={2000} className="input" placeholder="What did you like or dislike?" />
            </div>
            {status === "error" && <p className="text-sm text-rose-600" role="alert">{message}</p>}
            <button type="submit" disabled={status === "loading"} className="btn-primary btn-md w-full">
              {status === "loading" ? <Spinner className="h-4 w-4" /> : "Submit Review"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
