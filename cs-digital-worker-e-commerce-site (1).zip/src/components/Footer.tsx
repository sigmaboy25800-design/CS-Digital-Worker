import Link from "next/link";
import { LogoMark } from "@/components/ui";
import NewsletterForm from "@/components/NewsletterForm";
import { CONTACT } from "@/lib/utils";

type Cat = { name: string; slug: string };

const SOCIAL_ICONS: Record<string, { label: string; path: string }> = {
  facebook: { label: "Facebook", path: "M13.5 22v-8h2.7l.4-3.2h-3.1V8.7c0-.9.3-1.6 1.6-1.6h1.7V4.2c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3v2.4H7.4V14h2.7v8h3.4z" },
  tiktok: { label: "TikTok", path: "M16.6 3c.4 2 1.7 3.4 3.9 3.6v3c-1.5 0-2.8-.4-3.9-1.2v6.3c0 3.9-3 6.4-6.5 5.9-2.6-.4-4.6-2.6-4.8-5.2-.3-3.5 2.5-6.4 6-6.4.3 0 .7 0 1 .1v3.1c-.3-.1-.7-.2-1-.2-1.6 0-2.9 1.4-2.8 3 .1 1.4 1.3 2.6 2.7 2.6 1.6.1 2.9-1.2 2.9-2.8V3h2.5z" },
  instagram: { label: "Instagram", path: "M12 2.2c3.2 0 3.6 0 4.9.1 3.3.1 4.8 1.7 4.9 4.9.1 1.3.1 1.6.1 4.8s0 3.6-.1 4.8c-.1 3.2-1.7 4.8-4.9 4.9-1.3.1-1.6.1-4.9.1-3.2 0-3.6 0-4.8-.1-3.3-.1-4.8-1.7-4.9-4.9-.1-1.3-.1-1.6-.1-4.8s0-3.6.1-4.8C2.4 4 4 2.4 7.2 2.3c1.2-.1 1.6-.1 4.8-.1zm0 2.2c-3.1 0-3.5 0-4.7.1-2.2.1-3.2 1.1-3.3 3.3-.1 1.2-.1 1.6-.1 4.7s0 3.5.1 4.7c.1 2.2 1.1 3.2 3.3 3.3 1.2.1 1.6.1 4.7.1 3.2 0 3.5 0 4.7-.1 2.2-.1 3.2-1.1 3.3-3.3.1-1.2.1-1.6.1-4.7s0-3.5-.1-4.7c-.1-2.2-1.1-3.2-3.3-3.3-1.2-.1-1.5-.1-4.7-.1zm0 3.7a5 5 0 110 10 5 5 0 010-10zm0 2.2a2.8 2.8 0 100 5.6 2.8 2.8 0 000-5.6zm5.2-3.9a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z" },
  youtube: { label: "YouTube", path: "M22 12s0-3.3-.4-4.8c-.2-.9-.9-1.5-1.8-1.8C18.3 5 12 5 12 5s-6.3 0-7.8.4c-.9.3-1.6.9-1.8 1.8C2 8.7 2 12 2 12s0 3.3.4 4.8c.2.9.9 1.5 1.8 1.8C5.7 19 12 19 12 19s6.3 0 7.8-.4c.9-.3 1.6-.9 1.8-1.8.4-1.5.4-4.8.4-4.8zM10 15.2V8.8L15.5 12 10 15.2z" },
  pinterest: { label: "Pinterest", path: "M12 2a10 10 0 00-3.6 19.3c-.1-.8-.2-2 0-2.9l1.3-5.4s-.3-.6-.3-1.6c0-1.5.9-2.6 1.9-2.6.9 0 1.4.7 1.4 1.5 0 .9-.6 2.3-.9 3.5-.3 1.1.5 1.9 1.6 1.9 1.9 0 3.3-2 3.3-4.9 0-2.6-1.8-4.4-4.5-4.4-3 0-4.8 2.3-4.8 4.6 0 .9.3 1.9.8 2.4.1.1.1.2.1.3l-.3 1.2c0 .2-.2.2-.4.1-1.2-.6-2-2.4-2-3.9 0-3.4 2.4-6.4 7-6.4 3.7 0 6.5 2.6 6.5 6.1 0 3.7-2.3 6.6-5.5 6.6-1.1 0-2.1-.6-2.4-1.2l-.7 2.5c-.2.9-.9 2.1-1.3 2.8A10 10 0 1012 2z" },
};

export default function Footer({
  categories,
  settings,
}: {
  categories: Cat[];
  settings: Record<string, string>;
}) {
  const socials = [
    ["facebook", settings.facebook],
    ["tiktok", settings.tiktok],
    ["instagram", settings.instagram],
    ["youtube", settings.youtube],
    ["pinterest", settings.pinterest],
  ].filter(([, url]) => url && url.trim().length > 0) as [string, string][];

  return (
    <footer className="bg-brand-950 text-slate-300 mt-16">
      <div className="container-x py-12 grid gap-10 md:grid-cols-2 lg:grid-cols-4">
        {/* Brand */}
        <div>
          <LogoMark dark />
          <p className="mt-4 text-sm leading-relaxed text-slate-400">
            {settings.footerText}
          </p>
          <div className="mt-4 flex gap-2">
            {socials.map(([key, url]) => (
              <a
                key={key}
                href={url}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={`Visit our ${SOCIAL_ICONS[key].label} page`}
                className="h-9 w-9 rounded-lg bg-white/10 hover:bg-gold-500 hover:text-brand-950 text-white inline-flex items-center justify-center transition-colors"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d={SOCIAL_ICONS[key].path} />
                </svg>
              </a>
            ))}
          </div>
        </div>

        {/* Quick links */}
        <nav aria-label="Quick links">
          <h3 className="font-display text-white font-bold mb-4">Quick Links</h3>
          <ul className="space-y-2 text-sm">
            {[
              ["Shop", "/shop"],
              ["Categories", "/categories"],
              ["New Arrivals", "/shop?flag=new"],
              ["Best Sellers", "/shop?flag=bestseller"],
              ["Sale", "/shop?flag=sale"],
              ["Blog", "/blog"],
              ["Customer Reviews", "/reviews"],
              ["About Us", "/about"],
            ].map(([label, href]) => (
              <li key={href}>
                <Link href={href} className="hover:text-gold-400 transition-colors">{label}</Link>
              </li>
            ))}
          </ul>
        </nav>

        {/* Customer service */}
        <nav aria-label="Customer service">
          <h3 className="font-display text-white font-bold mb-4">Customer Service</h3>
          <ul className="space-y-2 text-sm">
            {[
              ["My Account", "/account"],
              ["Track Order", "/track-order"],
              ["FAQ", "/faq"],
              ["Contact Us", "/contact"],
              ["Shipping Policy", "/shipping-policy"],
              ["Return & Refund Policy", "/return-policy"],
              ["Privacy Policy", "/privacy-policy"],
              ["Terms & Conditions", "/terms"],
            ].map(([label, href]) => (
              <li key={href}>
                <Link href={href} className="hover:text-gold-400 transition-colors">{label}</Link>
              </li>
            ))}
          </ul>
        </nav>

        {/* Contact + newsletter */}
        <div>
          <h3 className="font-display text-white font-bold mb-4">Get in Touch</h3>
          <ul className="space-y-2.5 text-sm">
            <li>
              <a href={CONTACT.phoneHref} className="hover:text-gold-400 inline-flex items-center gap-2">
                <span aria-hidden>📞</span> Call Us: {CONTACT.phone}
              </a>
            </li>
            <li>
              <a href={CONTACT.whatsappHref} target="_blank" rel="noopener noreferrer" className="hover:text-gold-400 inline-flex items-center gap-2">
                <span aria-hidden>💬</span> WhatsApp: {CONTACT.phone}
              </a>
            </li>
            <li>
              <a href={CONTACT.emailHref} className="hover:text-gold-400 inline-flex items-center gap-2 break-all">
                <span aria-hidden>✉️</span> {CONTACT.email}
              </a>
            </li>
          </ul>
          <h3 className="font-display text-white font-bold mt-6 mb-3">Newsletter</h3>
          <NewsletterForm compact />
          <p className="mt-2 text-xs text-slate-500">We respect your privacy. Unsubscribe anytime.</p>
        </div>
      </div>

      {/* Categories row */}
      <div className="border-t border-white/10">
        <div className="container-x py-4 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-400">
          <span className="font-semibold text-slate-300">Categories:</span>
          {categories.map((c) => (
            <Link key={c.slug} href={`/category/${c.slug}`} className="hover:text-gold-400">
              {c.name}
            </Link>
          ))}
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="container-x py-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} CS Digital Worker. All rights reserved.</p>
          <p>Secure Shopping • Cash on Delivery • Nationwide Delivery</p>
        </div>
      </div>
    </footer>
  );
}
