"use client";

import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { useStore } from "@/components/Providers";
import { LogoMark } from "@/components/ui";
import { formatPrice } from "@/lib/utils";

type Cat = { name: string; slug: string };
type Suggestion = { name: string; slug: string; image: string; price: number };

const NAV = [
  { label: "Home", href: "/" },
  { label: "Shop", href: "/shop" },
  { label: "New Arrivals", href: "/shop?flag=new" },
  { label: "Best Sellers", href: "/shop?flag=bestseller" },
  { label: "Sale", href: "/shop?flag=sale", accent: true },
  { label: "Blog", href: "/blog" },
  { label: "About", href: "/about" },
  { label: "Contact", href: "/contact" },
];

export default function Header({
  categories,
  announcement,
}: {
  categories: Cat[];
  announcement: string | null;
}) {
  const { cartCount, wishlist, hydrated } = useStore();
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [catOpen, setCatOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const router = useRouter();
  const pathname = usePathname();
  const searchRef = useRef<HTMLInputElement>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    setMenuOpen(false);
    setSearchOpen(false);
    setCatOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (searchOpen) searchRef.current?.focus();
  }, [searchOpen]);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (query.trim().length < 2) {
      setSuggestions([]);
      return;
    }
    debounceRef.current = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(query.trim())}`);
        const data = await res.json();
        setSuggestions(data.results ?? []);
      } catch {
        setSuggestions([]);
      }
    }, 250);
  }, [query]);

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      router.push(`/search?q=${encodeURIComponent(query.trim())}`);
      setSearchOpen(false);
      setSuggestions([]);
    }
  };

  return (
    <>
      {announcement && (
        <div className="bg-brand-950 text-brand-100 text-center text-xs sm:text-sm px-4 py-2 font-medium">
          {announcement}
        </div>
      )}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur border-b border-slate-200 shadow-sm">
        <div className="container-x flex items-center justify-between gap-3 h-16">
          {/* Mobile hamburger */}
          <button
            className="lg:hidden p-2 -ml-2 text-slate-700 hover:text-brand-800"
            aria-label="Open menu"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen(true)}
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M4 6h16M4 12h16M4 18h16" /></svg>
          </button>

          <Link href="/" aria-label="CS Digital Worker — Home" className="shrink-0">
            <LogoMark />
          </Link>

          {/* Desktop nav */}
          <nav aria-label="Main navigation" className="hidden lg:flex items-center gap-1">
            {NAV.slice(0, 2).map((n) => (
              <Link key={n.href} href={n.href} className="px-3 py-2 text-sm font-medium text-slate-700 hover:text-brand-800 rounded-md hover:bg-slate-50">
                {n.label}
              </Link>
            ))}
            <div
              className="relative"
              onMouseEnter={() => setCatOpen(true)}
              onMouseLeave={() => setCatOpen(false)}
            >
              <button
                className="px-3 py-2 text-sm font-medium text-slate-700 hover:text-brand-800 rounded-md hover:bg-slate-50 inline-flex items-center gap-1"
                aria-expanded={catOpen}
                onClick={() => setCatOpen((o) => !o)}
              >
                Categories
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 9l6 6 6-6" /></svg>
              </button>
              {catOpen && (
                <div className="absolute left-0 top-full pt-1 w-56">
                  <div className="card p-2 shadow-lg">
                    {categories.map((c) => (
                      <Link key={c.slug} href={`/category/${c.slug}`} className="block px-3 py-2 text-sm text-slate-700 hover:bg-brand-50 hover:text-brand-800 rounded-md">
                        {c.name}
                      </Link>
                    ))}
                    <Link href="/categories" className="block px-3 py-2 text-sm font-semibold text-brand-700 hover:bg-brand-50 rounded-md">
                      All Categories →
                    </Link>
                  </div>
                </div>
              )}
            </div>
            {NAV.slice(2).map((n) => (
              <Link
                key={n.href}
                href={n.href}
                className={`px-3 py-2 text-sm font-medium rounded-md hover:bg-slate-50 ${n.accent ? "text-rose-600 hover:text-rose-700" : "text-slate-700 hover:text-brand-800"}`}
              >
                {n.label}
              </Link>
            ))}
          </nav>

          {/* Icons */}
          <div className="flex items-center gap-0.5 sm:gap-1">
            <button aria-label="Search" onClick={() => setSearchOpen((o) => !o)} className="p-2 text-slate-700 hover:text-brand-800">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.35-4.35" /></svg>
            </button>
            <Link href="/account" aria-label="My account" className="hidden sm:block p-2 text-slate-700 hover:text-brand-800">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6" /></svg>
            </Link>
            <Link href="/wishlist" aria-label={`Wishlist (${hydrated ? wishlist.length : 0} items)`} className="relative p-2 text-slate-700 hover:text-brand-800">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"><path d="M12 21C7 16.5 3 13.3 3 9.3 3 6.4 5.2 4 8 4c1.6 0 3.1.8 4 2 .9-1.2 2.4-2 4-2 2.8 0 5 2.4 5 5.3 0 4-4 7.2-9 11.7z" /></svg>
              {hydrated && wishlist.length > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-rose-600 text-white text-[10px] font-bold rounded-full h-4.5 min-w-4.5 px-1 inline-flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </Link>
            <Link href="/cart" aria-label={`Cart (${hydrated ? cartCount : 0} items)`} className="relative p-2 text-slate-700 hover:text-brand-800">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 6h15l-1.5 9h-12z" /><path d="M6 6L5 3H2" /><circle cx="9" cy="20" r="1.5" /><circle cx="18" cy="20" r="1.5" /></svg>
              {hydrated && cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-gold-500 text-brand-950 text-[10px] font-bold rounded-full h-4.5 min-w-4.5 px-1 inline-flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>
          </div>
        </div>

        {/* Search bar */}
        {searchOpen && (
          <div className="border-t border-slate-100 bg-white">
            <div className="container-x py-3 relative">
              <form onSubmit={submitSearch} role="search" className="flex gap-2">
                <input
                  ref={searchRef}
                  type="search"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search products, categories, fabrics…"
                  aria-label="Search products"
                  className="input"
                />
                <button type="submit" className="btn-primary btn-md">Search</button>
              </form>
              {suggestions.length > 0 && (
                <div className="absolute left-4 right-4 sm:left-6 sm:right-6 lg:left-8 lg:right-8 top-full card shadow-xl z-50 max-h-96 overflow-auto">
                  {suggestions.map((s) => (
                    <Link
                      key={s.slug}
                      href={`/product/${s.slug}`}
                      className="flex items-center gap-3 px-4 py-2.5 hover:bg-brand-50"
                      onClick={() => { setSearchOpen(false); setSuggestions([]); }}
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={s.image} alt="" className="h-10 w-8 object-cover rounded" loading="lazy" />
                      <span className="text-sm text-slate-800 flex-1">{s.name}</span>
                      <span className="text-sm font-semibold text-brand-800">{formatPrice(s.price)}</span>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Mobile drawer */}
      {menuOpen && (
        <div className="fixed inset-0 z-[60] lg:hidden" role="dialog" aria-modal="true" aria-label="Mobile navigation">
          <div className="absolute inset-0 bg-black/50" onClick={() => setMenuOpen(false)} />
          <div className="absolute left-0 top-0 bottom-0 w-80 max-w-[85vw] bg-white shadow-xl overflow-y-auto">
            <div className="flex items-center justify-between p-4 border-b border-slate-100">
              <LogoMark size="sm" />
              <button aria-label="Close menu" onClick={() => setMenuOpen(false)} className="p-2 text-slate-500 hover:text-slate-900">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18" /></svg>
              </button>
            </div>
            <nav className="p-3" aria-label="Mobile navigation">
              {NAV.map((n) => (
                <Link key={n.href} href={n.href} className={`block px-3 py-2.5 rounded-md font-medium ${n.accent ? "text-rose-600" : "text-slate-800"} hover:bg-brand-50`}>
                  {n.label}
                </Link>
              ))}
              <p className="px-3 pt-4 pb-1 text-xs font-bold uppercase tracking-wide text-slate-400">Categories</p>
              {categories.map((c) => (
                <Link key={c.slug} href={`/category/${c.slug}`} className="block px-3 py-2 text-sm text-slate-700 hover:bg-brand-50 rounded-md">
                  {c.name}
                </Link>
              ))}
              <div className="border-t border-slate-100 mt-3 pt-3">
                <Link href="/account" className="block px-3 py-2.5 font-medium text-slate-800 hover:bg-brand-50 rounded-md">My Account</Link>
                <Link href="/track-order" className="block px-3 py-2.5 font-medium text-slate-800 hover:bg-brand-50 rounded-md">Track Order</Link>
                <a href="https://wa.me/923228586255" target="_blank" rel="noopener noreferrer" className="block px-3 py-2.5 font-medium text-emerald-700 hover:bg-emerald-50 rounded-md">
                  WhatsApp Us: 03228586255
                </a>
              </div>
            </nav>
          </div>
        </div>
      )}
    </>
  );
}
