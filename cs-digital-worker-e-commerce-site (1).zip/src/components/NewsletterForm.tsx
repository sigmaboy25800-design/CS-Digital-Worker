"use client";

import { useState } from "react";
import { Spinner } from "@/components/ui";

export default function NewsletterForm({ compact = false }: { compact?: boolean }) {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [message, setMessage] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("loading");
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (res.ok) {
        setStatus("done");
        setMessage(data.message ?? "Subscribed successfully!");
        setEmail("");
      } else {
        setStatus("error");
        setMessage(data.error ?? "Something went wrong.");
      }
    } catch {
      setStatus("error");
      setMessage("Network error. Please try again.");
    }
  };

  return (
    <form onSubmit={submit} className="w-full">
      <div className="flex flex-col sm:flex-row gap-2">
        <label htmlFor={compact ? "newsletter-footer" : "newsletter-main"} className="sr-only">
          Email address
        </label>
        <input
          id={compact ? "newsletter-footer" : "newsletter-main"}
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter your email address"
          className="input flex-1"
        />
        <button type="submit" disabled={status === "loading"} className="btn-gold btn-md whitespace-nowrap">
          {status === "loading" ? <Spinner className="h-4 w-4" /> : "Subscribe"}
        </button>
      </div>
      {message && (
        <p className={`mt-2 text-sm ${status === "error" ? "text-rose-500" : "text-emerald-600"}`} role="status">
          {message}
        </p>
      )}
      {!compact && (
        <p className="mt-2 text-xs text-slate-400">
          By subscribing you agree to receive marketing emails and accept our{" "}
          <a href="/privacy-policy" className="underline hover:text-slate-300">Privacy Policy</a>. Unsubscribe anytime.
        </p>
      )}
    </form>
  );
}
