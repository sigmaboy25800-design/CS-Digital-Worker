"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { formatPrice, type WishItem } from "@/lib/utils";

export default function RecentlyViewed({
  current,
}: {
  current?: WishItem;
}) {
  const [items, setItems] = useState<WishItem[]>([]);

  useEffect(() => {
    let list: WishItem[] = [];
    try {
      list = JSON.parse(localStorage.getItem("csdw_recent") ?? "[]");
    } catch {
      list = [];
    }
    if (current) {
      const next = [current, ...list.filter((i) => i.productId !== current.productId)].slice(0, 8);
      localStorage.setItem("csdw_recent", JSON.stringify(next));
      setItems(next.filter((i) => i.productId !== current.productId).slice(0, 6));
    } else {
      setItems(list.slice(0, 6));
    }
  }, [current]);

  if (items.length === 0) return null;

  return (
    <section className="mt-14" aria-labelledby="recently-viewed">
      <h2 id="recently-viewed" className="font-display text-2xl font-bold text-slate-900 mb-5">Recently Viewed</h2>
      <div className="flex gap-4 overflow-x-auto pb-2">
        {items.map((i) => (
          <Link key={i.productId} href={`/product/${i.slug}`} className="card card-hover shrink-0 w-40 overflow-hidden">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={i.image} alt={i.name} loading="lazy" className="h-44 w-full object-cover" />
            <div className="p-3">
              <p className="text-xs font-semibold text-slate-800 line-clamp-2">{i.name}</p>
              <p className="text-sm font-bold text-brand-800 mt-1">{formatPrice(i.price)}</p>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
