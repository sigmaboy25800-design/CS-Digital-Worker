import Link from "next/link";
import { getActiveCategories, getProducts, type ProductQuery } from "@/lib/shop";
import ProductCard, { type CardProduct } from "@/components/ProductCard";
import ShopFilters, { SortSelect } from "@/components/ShopFilters";
import { EmptyState } from "@/components/ui";
import type { Product } from "@/db/schema";

export type ShopSearchParams = { [key: string]: string | string[] | undefined };

function toCard(p: Product): CardProduct {
  return {
    id: p.id, slug: p.slug, name: p.name, images: p.images ?? [],
    imageAlt: p.imageAlt, price: p.price, oldPrice: p.oldPrice, stock: p.stock,
    ratingAvg: p.ratingAvg, ratingCount: p.ratingCount,
    sizes: p.sizes ?? [], colors: p.colors ?? [], isNewArrival: p.isNewArrival,
  };
}

function str(v: string | string[] | undefined): string | undefined {
  return typeof v === "string" && v.length > 0 ? v : undefined;
}

export function parseQuery(sp: ShopSearchParams, fixedCategory?: string): ProductQuery {
  const flag = str(sp.flag);
  return {
    q: str(sp.q),
    category: fixedCategory ?? str(sp.category),
    minPrice: str(sp.min) ? Number(sp.min) : undefined,
    maxPrice: str(sp.max) ? Number(sp.max) : undefined,
    sizes: str(sp.sizes)?.split(",").filter(Boolean),
    colors: str(sp.colors)?.split(",").filter(Boolean),
    inStock: sp.stock === "1",
    minRating: str(sp.rating) ? Number(sp.rating) : undefined,
    sort: str(sp.sort),
    page: str(sp.page) ? Number(sp.page) : 1,
    flag: flag === "featured" || flag === "new" || flag === "bestseller" || flag === "sale" ? flag : undefined,
  };
}

export default async function ShopListing({
  searchParams,
  basePath,
  fixedCategory,
}: {
  searchParams: ShopSearchParams;
  basePath: string;
  fixedCategory?: string;
}) {
  const query = parseQuery(searchParams, fixedCategory);
  const [result, categories] = await Promise.all([getProducts(query), getActiveCategories()]);

  const buildPageHref = (page: number) => {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries(searchParams)) {
      if (typeof v === "string" && v) p.set(k, v);
    }
    p.set("page", String(page));
    return `${basePath}?${p.toString()}`;
  };

  return (
    <div className="flex flex-col lg:flex-row gap-8">
      <ShopFilters
        categories={categories.map((c) => ({ name: c.name, slug: c.slug }))}
        hideCategory={Boolean(fixedCategory)}
      />
      <div className="flex-1 min-w-0">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
          <p className="text-sm text-slate-500" aria-live="polite">
            Showing <strong className="text-slate-800">{result.products.length}</strong> of{" "}
            <strong className="text-slate-800">{result.total}</strong> products
          </p>
          <SortSelect />
        </div>

        {result.products.length === 0 ? (
          <EmptyState
            icon="🔍"
            title="No products found"
            text="We couldn't find any products matching your filters. Try adjusting your search or explore our full collection."
          >
            <Link href="/shop" className="btn-primary btn-md">Browse All Products</Link>
            <Link href="/" className="btn-outline btn-md">Go Home</Link>
          </EmptyState>
        ) : (
          <>
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5">
              {result.products.map((p) => <ProductCard key={p.id} product={toCard(p)} />)}
            </div>

            {result.totalPages > 1 && (
              <nav aria-label="Pagination" className="mt-10 flex justify-center gap-2 flex-wrap">
                {Array.from({ length: result.totalPages }, (_, i) => i + 1).map((page) => (
                  <Link
                    key={page}
                    href={buildPageHref(page)}
                    aria-current={page === result.page ? "page" : undefined}
                    className={`h-10 min-w-10 px-3 inline-flex items-center justify-center rounded-lg text-sm font-semibold ${
                      page === result.page
                        ? "bg-brand-800 text-white"
                        : "bg-white border border-slate-200 text-slate-700 hover:border-brand-600"
                    }`}
                  >
                    {page}
                  </Link>
                ))}
              </nav>
            )}
          </>
        )}
      </div>
    </div>
  );
}
