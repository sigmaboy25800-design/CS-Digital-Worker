"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { CartLine, WishItem } from "@/lib/utils";

type Toast = { id: number; message: string; type: "success" | "error" | "info" };

type StoreContextType = {
  hydrated: boolean;
  cart: CartLine[];
  saved: CartLine[];
  wishlist: WishItem[];
  cartCount: number;
  cartSubtotal: number;
  addToCart: (line: CartLine) => void;
  updateQty: (key: string, qty: number) => void;
  removeFromCart: (key: string) => void;
  clearCart: () => void;
  saveForLater: (key: string) => void;
  moveToCart: (key: string) => void;
  removeSaved: (key: string) => void;
  toggleWishlist: (item: WishItem) => void;
  isWishlisted: (productId: number) => boolean;
  toast: (message: string, type?: Toast["type"]) => void;
};

const StoreContext = createContext<StoreContextType | null>(null);

export const lineKey = (l: { productId: number; size?: string; color?: string }) =>
  `${l.productId}|${l.size ?? ""}|${l.color ?? ""}`;

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within Providers");
  return ctx;
}

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export default function Providers({ children }: { children: ReactNode }) {
  const [hydrated, setHydrated] = useState(false);
  const [cart, setCart] = useState<CartLine[]>([]);
  const [saved, setSaved] = useState<CartLine[]>([]);
  const [wishlist, setWishlist] = useState<WishItem[]>([]);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const idRef = useRef(0);

  useEffect(() => {
    setCart(load("csdw_cart", []));
    setSaved(load("csdw_saved", []));
    setWishlist(load("csdw_wishlist", []));
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) localStorage.setItem("csdw_cart", JSON.stringify(cart));
  }, [cart, hydrated]);
  useEffect(() => {
    if (hydrated) localStorage.setItem("csdw_saved", JSON.stringify(saved));
  }, [saved, hydrated]);
  useEffect(() => {
    if (hydrated) localStorage.setItem("csdw_wishlist", JSON.stringify(wishlist));
  }, [wishlist, hydrated]);

  const toast = useCallback((message: string, type: Toast["type"] = "success") => {
    const id = ++idRef.current;
    setToasts((t) => [...t, { id, message, type }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3500);
  }, []);

  const addToCart = useCallback(
    (line: CartLine) => {
      setCart((prev) => {
        const key = lineKey(line);
        const existing = prev.find((l) => lineKey(l) === key);
        if (existing) {
          return prev.map((l) =>
            lineKey(l) === key
              ? { ...l, qty: Math.min(l.qty + line.qty, Math.max(1, l.stock)) }
              : l
          );
        }
        return [...prev, line];
      });
      toast(`${line.name} added to cart`);
    },
    [toast]
  );

  const updateQty = useCallback((key: string, qty: number) => {
    setCart((prev) =>
      prev.map((l) =>
        lineKey(l) === key ? { ...l, qty: Math.max(1, Math.min(qty, Math.max(1, l.stock))) } : l
      )
    );
  }, []);

  const removeFromCart = useCallback((key: string) => {
    setCart((prev) => prev.filter((l) => lineKey(l) !== key));
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const saveForLater = useCallback((key: string) => {
    setCart((prev) => {
      const line = prev.find((l) => lineKey(l) === key);
      if (line) setSaved((s) => (s.find((x) => lineKey(x) === key) ? s : [...s, line]));
      return prev.filter((l) => lineKey(l) !== key);
    });
  }, []);

  const moveToCart = useCallback((key: string) => {
    setSaved((prev) => {
      const line = prev.find((l) => lineKey(l) === key);
      if (line)
        setCart((c) => (c.find((x) => lineKey(x) === key) ? c : [...c, line]));
      return prev.filter((l) => lineKey(l) !== key);
    });
  }, []);

  const removeSaved = useCallback((key: string) => {
    setSaved((prev) => prev.filter((l) => lineKey(l) !== key));
  }, []);

  const toggleWishlist = useCallback(
    (item: WishItem) => {
      setWishlist((prev) => {
        const exists = prev.find((w) => w.productId === item.productId);
        if (exists) {
          toast(`${item.name} removed from wishlist`, "info");
          return prev.filter((w) => w.productId !== item.productId);
        }
        toast(`${item.name} added to wishlist`);
        return [...prev, item];
      });
    },
    [toast]
  );

  const isWishlisted = useCallback(
    (productId: number) => wishlist.some((w) => w.productId === productId),
    [wishlist]
  );

  const cartCount = cart.reduce((s, l) => s + l.qty, 0);
  const cartSubtotal = cart.reduce((s, l) => s + l.qty * l.price, 0);

  return (
    <StoreContext.Provider
      value={{
        hydrated, cart, saved, wishlist, cartCount, cartSubtotal,
        addToCart, updateQty, removeFromCart, clearCart,
        saveForLater, moveToCart, removeSaved,
        toggleWishlist, isWishlisted, toast,
      }}
    >
      {children}
      {/* Toasts */}
      <div
        aria-live="polite"
        className="fixed bottom-4 left-1/2 -translate-x-1/2 z-[100] flex flex-col gap-2 w-[92vw] max-w-sm"
      >
        {toasts.map((t) => (
          <div
            key={t.id}
            role="status"
            className={`rounded-lg px-4 py-3 text-sm font-medium shadow-lg text-white ${
              t.type === "success"
                ? "bg-brand-800"
                : t.type === "error"
                ? "bg-rose-600"
                : "bg-slate-800"
            }`}
          >
            {t.message}
          </div>
        ))}
      </div>
    </StoreContext.Provider>
  );
}
